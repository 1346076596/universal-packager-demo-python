# 逐日追踪 PLC 程序（TIA Portal V15）

本目录包含按《逐日追踪系统开发文档 v1.2》生成的 Siemens S7-1200 SCL。仓库内原 v1.2 源码已经在本机 TIA Portal V15 中导入 CPU 1214C AC/DC/RLY（`6ES7214-1BG40-0XB0`，固件 V4.2）离线工程并完成全项目编译；当前 `scl/` 中的数据契约 v3 与安全增强需导入新的离线工作副本重新编译，不能沿用旧工程的编译结论。

## 验证结果

- TIA Portal：V15
- PLC 软件：`SolarTrackerStation`
- 原 v1.2 工程编译错误：0
- 原 v1.2 工程编译警告：0
- 当前 v3 安全增强源码：等待按离线工作副本流程重新导入和编译
- 未执行：下载 PLC、转在线、强制 I/O、修改 CPU 运行状态
- 未覆盖任何已有工程
- 修复工程：`tia_project/SolarTracker_V1_2_Main/SolarTracker_V1_2.ap15`
- 原工程保留：`tia_project/SolarTracker_V1_2/SolarTracker_V1_2.ap15`

## 源码与块

权威源文件：

- `scl/SolarTracker_V15.scl`：类型、轴控制、主控制器和通信/状态 DB。
- `scl/SolarTracker_Main_V15.scl`：循环组织块 `Main (OB1)`，固定调用主控制器。

生成内容：

- `UDT_ST_Command`：Python 写入 PLC 的语义命令。
- `UDT_ST_AxisConfig`、`UDT_ST_Config`：轴、热像和通信参数。
- `UDT_ST_AxisIO`、`UDT_ST_FieldIO`：现场输入的逻辑接口。
- `UDT_ST_AxisStatus`、`UDT_ST_Status`：PLC 返回 Python 的遥测与确认。
- `FB_ST_Axis (FB1)`：单轴滞回、限位、持续复核的换向等待、手动方向锁存、有界动作和超时。
- `FB_ST_Controller (FB2)`：命令整包锁存、安全优先级、全局手动序号去重、模式确认/撤销、一次性故障复位、夜间回位、太阳/热像控制和唯一输出仲裁。
- `DB_ST_Command`：唯一允许 Python 写入的非保持命令缓冲区。
- `DB_ST_Status`：PLC 只写、Python 只读的状态区。
- `DB_ST_FieldIO`：非保持现场输入与 PLC 时钟脉冲；不得开放给 Python 写入。
- `DB_ST_Config`：现场标定与安全参数保持区；不得开放给 Python 写入。
- `DB_ST_FaultMemory`：仅保持锁存故障和故障码；首次下载默认锁定。
- `DB_ST_Controller`：主控制器实例 DB。
- `Main (OB1)`：每一扫描周期调用 `DB_ST_Controller`；`Pulse1s` 从语义 DB 接入，不猜测现场时钟地址。

## OB1 与绝对 I/O 的安全边界

原开发文档没有冻结现场 I/O 地址、位置反馈量程、机械范围和输出接触器映射。为避免把未经确认的地址写进真实设备，本代码：

- 生成 `Main (OB1)`，但只做内部 DB 调用；
- 不使用 `%I`、`%Q` 或绝对外围地址；
- 四个继电器“请求”在 OB1 中只接到临时变量，同时复制到 `Status.*Request`，不直接作为推杆功率输出；
- `DB_ST_FieldIO.Pulse1s` 必须在最终通信映射或已确认的 PLC 时钟源中提供 1 秒脉冲；
- `FieldIO.SafetyChainOk`、两轴 `PositionValid` 和 `DriveReady` 默认均为 `FALSE`，因此未完成现场接线时控制器保持故障停机。

## 导入顺序

1. 先导入并生成 `scl/SolarTracker_V15.scl` 中的类型、FB 和 DB。
2. 再导入并生成 `scl/SolarTracker_Main_V15.scl`，以写入 `Main (OB1)`。
3. 全项目编译；只有在冻结硬件映射并通过隔离测试后，才新增真实 I/O 映射。

投运前必须把真实急停、安全链、四个硬限位、两轴位置、驱动反馈和 `MotionStopped` 停稳确认写入 `FieldIO`，并在标定完成后显式设置 `ParkingCalibrated`。最终硬件输出应经过独立的电气/机械互锁，并从 `Status.*Request` 进行受控映射；当前 OB1 不执行该映射。

## 现场投运前

1. 按 `docs/semantic_mapping.md` 冻结 Python/PLC 数据映射。
2. 用真实机构数据替换 DB 中的示例角度、死区、停放点和超时。
3. 完成急停、硬限位、接触器/继电器互锁和过流保护。
4. 校准实际位置到角度的换算；确认反馈断线诊断。
5. 确认热像仪太阳观测许可、滤光、饱和/过温保护和方向标定。
6. 在 PLCSIM、测试 FB 或隔离台架完成异常注入，再进行 FAT/SAT。

通信实现必须在每次网关进程启动时生成新的非零 `SessionEpoch`，先读取 `Status.LastCommandSequence`，并为基线包选择不同的 `CommandSequence`。网关维护完整命令影子区：先写 `SessionEpoch` 和除 `CommandSequence` 外的全部字段，最后才写入新的 `CommandSequence`；它是唯一原子提交标记，PLC 只在该序号改变时锁存整包。PLC/网关重启或通信恢复后的第一个有效包只同步 `ManualSequence`、模式请求和复位请求基线，同时强制手动停机，绝不执行一次性动作；上位机必须先提交 `ModeChangeRequest=FALSE`、`FaultResetRequest=FALSE` 的基线包，再用新序号提交真实请求。`ModeChangeRequest` 和 `FaultResetRequest` 必须各只在一个已提交包中为 `TRUE`，后续包恢复为 `FALSE`。

TIA 导入后必须确认 `DB_ST_Config` 和 `DB_ST_FaultMemory` 的 `VAR RETAIN` 属性已生效，并给通信用户配置最小权限：只可写 `DB_ST_Command.Command`，只可读 `DB_ST_Status.Status`，不可写 `DB_ST_FieldIO`、`DB_ST_Config` 或 `DB_ST_FaultMemory`。MRES、恢复出厂或重新初始化 DB 会清除保持值，执行后必须重新标定并按首次投运流程解除故障锁定。

权威 `.scl` 以 UTF-8 保存；TIA Portal V15 直接导入中文外部源时需使用 CP936/ANSI。发布时应走 TIA MCP 的源码生成/转码流程，或生成单独的 CP936 导入副本，不要直接改变权威源文件编码。当前仍须在离线副本中实际生成并全编译确认语法与保持属性。
