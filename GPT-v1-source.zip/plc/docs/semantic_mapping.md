# Python ↔ PLC 语义映射

具体 DB 偏移、S7/Modbus 访问方式和字节序尚未冻结。本表只冻结语义；生产通信映射必须在优化访问策略和现场协议确定后单独导出。

## Python 写入 `DB_ST_Command.Command`

| PLC 字段 | 含义 | 约束 |
|---|---|---|
| `DataVersion` | 数据契约版本 | 当前为 `3`；不一致时禁止控制 |
| `SessionEpoch` | Python 网关会话号 | 每次网关进程启动生成新的非零 `DInt`；作为完整包字段随 `CommandSequence` 提交，变化或通信恢复后的首个有效包只同步基线并强制手动停机 |
| `CommandSequence` | 完整命令包提交序号 | Python 每次提交完整影子包时递增并最后写；PLC 仅在新序号到达时原子锁存整包 |
| `Heartbeat` | Python 心跳 | 必须持续变化；超时全停 |
| `CommandFresh` | Python 对命令时间的初筛 | PLC 心跳看门狗仍独立裁决 |
| `FaultResetRequest` | 故障复位单次脉冲 | 仅在一个新提交包中为真；条件未恢复时本次请求作废，不能延迟自动复位 |
| `RequestedMode` | 0 手动、1 太阳、2 热像 | `ConfirmedMode` 才是实际模式 |
| `ModeChangeRequest` | 模式切换单次脉冲 | 仅在一个新提交包中为真；PLC 先停稳，再更新确认模式；等待期间安全条件失效即拒绝 |
| `IsDay` | 昼夜状态 | 夜间优先自动回安全停放点 |
| `CalculationTimeValid` | 真实控制时间有效 | 为假时全局禁止夜间回位、手动、太阳和热像运动，仅允许界面预览 |
| `ManualSequence` | 单次微调序号 | 控制器全局消费一次；跨轴复用或运动期间的新序号均不排队、不重复动作；重启首包只同步、不动作 |
| `ManualAxis` | 1 方位、2 高度 | 其他值不动作 |
| `ManualDirection` | -1 负向、1 正向 | 仍受限位和安全裁决 |
| `ManualStepDeg` | 最大步进角 | PLC 再按配置上限裁剪 |
| `ManualMaxTime` | 最大动作时间 | PLC 再按配置上限裁剪 |
| `SolarTargetValid` | 太阳目标有效 | 无效立即停止太阳闭环 |
| `SolarAzimuth` / `SolarElevation` | 太阳目标角 | PLC 使用本地实际角闭环 |
| `SolarAzimuthError` / `SolarElevationError` | Python 计算的 `目标角 − PLC 反馈角` | 诊断值；PLC 用本地反馈复算 |
| `SolarAzimuthDirection` / `SolarElevationDirection` | Python 请求方向，`-1/0/1` | PLC 必须验证方向与本地偏差一致，再进入目标闭环 |
| `SolarFeedbackFresh` | Python 侧 PLC 反馈新鲜度检查 | 为假立即撤销太阳目标，不替代 PLC 本地诊断 |
| `ThermalImageValid` | 图像有效 | 任一热像有效性失败即停止 |
| `ThermalHotspotValid` | 热点有效 | 同上 |
| `ThermalAligned` | Python 判定已对齐 | 为真时两轴停止 |
| `ThermalDx` / `ThermalDy` | Python 按相机标定方向转换后的归一化中心偏移 | PLC 不再次翻转，只移动绝对偏差较大的轴 |
| `ThermalConfidence` | 热点置信度 | 低于 PLC 阈值停止 |
| `ThermalFrameSequence` | 图像帧序号 | PLC 独立看门狗检测冻结 |
| `ThermalFrameFresh` | Python 帧新鲜度初筛 | 不替代 PLC 帧序号看门狗 |

## 现场输入 `DB_ST_FieldIO.FieldIO`

| 字段 | 来源 |
|---|---|
| `EmergencyStop` | 急停状态；硬件回路仍须直接切动力 |
| `SafetyChainOk` | 安全继电器/动力许可反馈 |
| `MaintenanceKey` | 物理维护钥匙，仅用于故障复位授权 |
| `Azimuth/Elevation.ActualAngle` | PLC 本地位置采集和标定结果 |
| `*.PositionValid` | 反馈范围、断线和诊断综合结果 |
| `*.NegativeLimit` / `*.PositiveLimit` | 两端硬限位 |
| `*.DriveReady` / `*.DriveFault` | 驱动器或接触器反馈 |
| `*.MotionStopped` | 驱动速度为零且接触器已释放；模式确认必须等待此反馈 |

## PLC 返回 `DB_ST_Status.Status`

| 字段 | 含义 |
|---|---|
| `PlcHeartbeat` | PLC 每秒心跳 |
| `LastCommandSessionEpoch` / `LastCommandSequence` | PLC 最近原子锁存的完整包键；新网关据此选择不同的基线提交序号 |
| `AckCommandSessionEpoch` / `AckCommandSequence` / `AckResult` | 模式命令的会话、序号及确认/拒绝结果 |
| `AckManualSessionEpoch` / `AckManualSequence` / `AckManualResult` | 已消费点动的会话、序号及结果：0 无结果、1 已接受、2 已安全拒绝 |
| `ConfirmedMode` / `ModeSwitchPending` | PLC 已确认模式和切换等待 |
| `RunState` / `NightParked` | 当前优先级状态和夜间停放结果 |
| `CommunicationFault` | Python 心跳或命令新鲜度失败 |
| `GlobalFault` / `GlobalFaultCode` | 锁存故障及原因 |
| `ModeRejectionCode` | 模式拒绝原因：201 模式值非法；202 热像帧无效；203 通信/安全/位置/驱动条件不满足；204 时间预览禁止自动模式 |
| `Azimuth` / `Elevation` | 实际角、限位、方向、到位、`ManualBusy` 点动占用、`MotionStopped` 物理停稳、超时和故障 |
| `*Request` | 经过软件仲裁的四个方向请求；仍须硬件互锁 |

## 一致性规则

1. Python 网关启动时生成新的非零 `SessionEpoch` 并维护完整命令影子区；任何心跳、时间、目标、模式或手动更新都先合并影子区，再最后递增写入 `CommandSequence`。
2. `CommandSequence` 是唯一提交标记；PLC 只有在完整新序号最后写入后才原子锁存整包，不能因 `SessionEpoch` 或其他字段先变化而提前锁存。
3. 前端只显示 `ConfirmedMode`，不把 `RequestedMode` 误显示为当前模式。
4. PLC 心跳和热像帧序号长时间不变时立即撤销运动请求。
5. 浮点字节序、DB 优化访问方式和访问权限必须在最终协议表中冻结。
6. 历史或未来计算时间只用于界面预览；`CalculationTimeValid=FALSE`，不得进入真实运动链。
7. Python 请求方向只是一致性授权，PLC 仍以本地实际角、死区、软硬限位和安全链作最终仲裁。
8. 未确认 `ParkingCalibrated` 时夜间回位保持停止并锁存故障，不使用示例停放角。
9. 锁存故障会取消待切模式并强制回到手动；复位成功后必须重新提交模式命令。
10. PLC/网关会话重启或通信恢复后的首个有效包只建立一次性命令基线并强制回手动停机；网关先读取 `LastCommandSequence`，再以非零新 `SessionEpoch`、不同提交序号和请求位全假的完整包建立基线，之后才发模式、复位或手动请求。
11. 通信账户只允许写 `DB_ST_Command.Command`，只允许读 `DB_ST_Status.Status`；`DB_ST_FieldIO`、`DB_ST_Config` 和 `DB_ST_FaultMemory` 必须由 PLC/现场工程维护并禁止远程写。
12. `DB_ST_FaultMemory` 只保持故障锁存和故障码；模式边沿、手动序号边沿、活动方向和待处理命令均为非保持。MRES 后必须重新标定并按首次投运处理。
