# 逐日追踪系统 v1.2

按《逐日追踪系统开发文档 v1.2》实现的 Vue 3 + FastAPI + Siemens S7-1200 工程。

## 已完成

- Python 模块化服务：太阳位置、Open-Meteo 实时/历史天气、跨日太阳重现预测、热像处理、PLC 语义网关、统一快照、REST、WebSocket 和 MJPEG。
- Vue 工业仪表盘：三种模式、PLC 模式确认、Python 目标角、PLC 实际反馈、跟踪偏差、可拖动球面太阳轨迹、预测、报警及站点/时间预览。
- TIA Portal V15 SCL：命令整包原子锁存、重启首包握手、命令/状态/现场配置 DB 隔离、跨重启故障保持、双轴控制、安全优先级、通信/帧看门狗、方向一致性复核、物理停稳确认、一次性复位、已标定夜间回位、手动有界动作、太阳闭环、热像对齐和输出互锁。
- 历史/未来计算时间与真实控制时间已分离；时间覆盖只用于天气和太阳预览，不会授权真实运动。
- 后端每次启动先撤销遗留自动指令；只有 PLC 已确认手动、两轴物理停稳后，操作员才能重新选择太阳轨迹。
- 现有 TIA 离线工程：`plc/tia_project/SolarTracker_V1_2_Main/SolarTracker_V1_2.ap15`；当前数据契约 v3 源码尚未写入该工程。

## 目录

```text
backend/     FastAPI 服务和 73 项 pytest
frontend/    Vue 3/Pinia 页面和 63 项 Vitest
plc/         SCL、语义映射、TIA V15 工程
docs/        工程假设与现场待确认项
```

## 本地运行

### VS Code 一键启动（推荐）

1. 用 VS Code 打开本项目根目录。
2. 打开“运行和调试”，选择 `▶ 一键启动：前后端并打开界面`。
3. 在任意文件或界面按 `F5`，或点击绿色运行按钮。

启动器会同时启动 FastAPI 和 Vite，分别确认健康检查与页面已就绪后，自动用默认浏览器打开 `http://127.0.0.1:5173`。点击 VS Code 停止按钮或在启动终端按 `Ctrl+C`，会同时关闭本次启动的前后端进程。

如果当前打开的是 `backend/app/main.py`，编辑器右上角的“运行 Python 文件”按钮也会自动进入同一个全栈启动流程。

### 手动启动

Python 3.11+：

```powershell
python -m pip install -e "backend[test]"
python -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8188
```

Node.js 20+ 与 pnpm：

```powershell
cd frontend
pnpm install
pnpm dev
```

浏览器打开 `http://127.0.0.1:5173`。Vite 会把 `/api`、`/ws` 和 `/media` 转发到 `127.0.0.1:8188`。

## 验证

```powershell
python -m pytest -p no:cacheprovider backend/tests
python -m ruff check --no-cache backend/app backend/tests
cd frontend
pnpm test
pnpm build
```

当前结果：

- Python：73 passed，Ruff 通过。
- Vue：63 passed，TypeScript/生产构建通过。
- TIA V15：仓库内原 v1.2 工程上次编译为 0 errors / 0 warnings；当前数据契约 v3 与安全增强源码需重新导入离线工作副本并编译后方可发布。

## 安全默认

- `.env.example` 默认 PLC/相机未配置，控制与媒体访问均拒绝。
- 生产环境禁止开发模拟和断线后自动回退模拟。
- 未确认热像仪太阳观测许可与标定时，热像追踪不可启用。
- TIA 工程没有下载到 PLC，没有转在线或强制 I/O；OB1 只调用符号 DB，不映射真实物理输出。
- 选择历史/未来时间时，自动模式与手动动作均被控制链禁止；恢复实时时间后还需重新选择太阳轨迹模式。
- 通信包由 `CommandSequence` 最后提交并在 PLC 内整包锁存；模式/复位是单次脉冲，断线或安全条件失效会取消待确认模式。
- PLC 示例角度、停放点和超时只是占位值，必须按 [工程假设与待确认项](docs/工程假设与待确认项.md) 完成现场冻结。
- Python/PLC 字段见 [语义映射](plc/docs/semantic_mapping.md)。
