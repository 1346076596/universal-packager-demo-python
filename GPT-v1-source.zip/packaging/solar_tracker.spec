from pathlib import Path

from PyInstaller.utils.hooks import collect_all, collect_submodules

# The workflow and the documented local command invoke PyInstaller from the
# repository root.  PyInstaller's SPECPATH value varies between releases, so
# using the working directory keeps source and CI builds deterministic.
PROJECT_ROOT = Path.cwd().resolve()
FRONTEND_DIST = PROJECT_ROOT / "frontend" / "dist"
BACKEND_DIR = PROJECT_ROOT / "backend"

if not (FRONTEND_DIST / "index.html").is_file():
    raise SystemExit(
        "frontend/dist/index.html 不存在，请先执行：pnpm --dir frontend build"
    )

datas = [(str(FRONTEND_DIST), "frontend_dist")]
binaries = []
hiddenimports = collect_submodules("uvicorn")

for package_name in ("numpy", "PIL", "pydantic", "tzdata"):
    package_datas, package_binaries, package_hiddenimports = collect_all(package_name)
    datas += package_datas
    binaries += package_binaries
    hiddenimports += package_hiddenimports

analysis = Analysis(
    [str(PROJECT_ROOT / "packaging" / "desktop_entry.py")],
    pathex=[str(PROJECT_ROOT), str(BACKEND_DIR)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "ruff", "tkinter"],
    noarchive=False,
    optimize=1,
)

python_archive = PYZ(analysis.pure)

executable = EXE(
    python_archive,
    analysis.scripts,
    analysis.binaries,
    analysis.datas,
    [],
    name="SolarTracker",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
