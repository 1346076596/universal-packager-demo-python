from __future__ import annotations

import argparse
import os
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

APP_FOLDER_NAME = "SolarTracker"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8188


def frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def bundle_root() -> Path:
    if frozen():
        return Path(sys._MEIPASS).resolve()  # type: ignore[attr-defined]
    return Path(__file__).resolve().parents[1]


def executable_root() -> Path:
    if frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def frontend_dist() -> Path:
    candidates = (
        bundle_root() / "frontend_dist",
        bundle_root() / "frontend" / "dist",
    )
    for candidate in candidates:
        if (candidate / "index.html").is_file():
            return candidate
    searched = "、".join(str(path) for path in candidates)
    raise RuntimeError(f"找不到前端构建产物 index.html；已检查：{searched}")


def default_data_dir() -> Path:
    local_app_data = os.getenv("LOCALAPPDATA")
    base = Path(local_app_data) if local_app_data else Path.home() / "AppData" / "Local"
    return base / APP_FOLDER_NAME / "data"


def load_external_env(path: Path) -> None:
    if not path.is_file():
        return
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if key:
            os.environ.setdefault(key, value)


def configure_runtime(data_dir: Path) -> None:
    load_external_env(executable_root() / ".env")
    data_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault(
        "SOLAR_TRACKER_SITE_CONFIG_PATH",
        str(data_dir / "site_config.json"),
    )
    os.environ.setdefault(
        "SOLAR_TRACKER_AUDIT_LOG_PATH",
        str(data_dir / "audit.jsonl"),
    )
    os.environ.setdefault("PYTHONUTF8", "1")


def build_application(static_dir: Path) -> FastAPI:
    from app.main import create_app

    application = create_app()
    # API/WebSocket/media routes are registered first. The final root mount serves
    # the compiled Vue app and its /assets files from the same origin.
    application.mount(
        "/",
        StaticFiles(directory=str(static_dir), html=True),
        name="frontend",
    )
    return application


def port_available(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            probe.bind((host, port))
        except OSError:
            return False
    return True


def wait_for_ready(base_url: str, *, open_browser: bool) -> None:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    health_url = f"{base_url}/api/v1/health"
    for _ in range(360):
        try:
            with opener.open(health_url, timeout=1.0) as response:
                if 200 <= response.status < 300:
                    print(f"[就绪] 逐日追踪系统：{base_url}", flush=True)
                    if open_browser:
                        webbrowser.open_new_tab(base_url)
                    return
        except (OSError, TimeoutError, urllib.error.URLError):
            pass
        time.sleep(0.25)
    print(f"[警告] 启动超时，请手动打开或检查：{base_url}", flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="逐日追踪系统 Windows 桌面启动器")
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--data-dir", type=Path, default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not 1 <= args.port <= 65535:
        print(f"[失败] 端口超出范围：{args.port}", file=sys.stderr, flush=True)
        return 2
    if not port_available(args.host, args.port):
        print(
            f"[失败] {args.host}:{args.port} 已被占用，请关闭旧实例后重试，"
            "或使用 --port 指定其他端口。",
            file=sys.stderr,
            flush=True,
        )
        return 2

    try:
        static_dir = frontend_dist()
        data_dir = (args.data_dir or default_data_dir()).resolve()
        configure_runtime(data_dir)
        application = build_application(static_dir)
    except (ImportError, OSError, RuntimeError, ValueError) as exc:
        print(f"[失败] 初始化逐日追踪系统失败：{exc}", file=sys.stderr, flush=True)
        return 1

    base_url = f"http://{args.host}:{args.port}"
    print("=" * 58)
    print("逐日追踪系统 v1.2")
    print(f"界面地址：{base_url}")
    print(f"运行数据：{data_dir}")
    print("关闭本窗口或按 Ctrl+C 可停止服务。")
    print("=" * 58, flush=True)

    threading.Thread(
        target=wait_for_ready,
        kwargs={"base_url": base_url, "open_browser": not args.no_browser},
        name="open-browser-after-ready",
        daemon=True,
    ).start()

    uvicorn.run(
        application,
        host=args.host,
        port=args.port,
        log_level="info",
        access_log=False,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
