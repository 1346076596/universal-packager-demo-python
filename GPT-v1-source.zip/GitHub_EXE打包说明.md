# GPT v1 使用 GitHub Actions 打包 Windows EXE

## 当前已完成的 GitHub 构建

- 仓库：`1346076596/universal-packager-demo-python`
- 提交：`77387a425891e2dcd485b22ea30fe5a631ebdab2`
- Actions：`Universal Auto Package #10`
- 构建记录：<https://github.com/1346076596/universal-packager-demo-python/actions/runs/31457158883>
- Release：<https://github.com/1346076596/universal-packager-demo-python/releases/tag/auto-build-10>
- Actions Artifact：`package-windows-x64`，大小 `42,891,493` 字节，到期时间 `2026-09-10`
- Artifact 内层包：`SolarTracker-windows-x64.zip`
- 内层 EXE：`custom/output/SolarTracker.exe`，大小 `43,328,343` 字节
- EXE SHA-256：`A09AAEC72E67D93FC837421E8D7696749534839E0A9AA2A5B499EAE86C8C8BF6`

已下载到本机：

```text
build/github-artifacts/package-windows-x64-run10.zip
build/github-artifacts/SolarTracker-windows-x64-run10.zip
release/SolarTracker-github-windows-x64.exe
```

本次使用现有通用工作流打包时，`packaging.json` 中必须同时满足：

```json
{
  "run": "python -m PyInstaller --noconfirm --clean --distpath output packaging/solar_tracker.spec"
}
```

```json
"artifacts": {
  "windows-x64": [
    "output/SolarTracker.exe",
    "GitHub_EXE打包说明.md",
    ".env.example"
  ]
}
```

本说明对应工作流：`.github/workflows/build-windows-exe.yml`。

本机已经完成一次实际构建和启动检查，当前可直接试运行：

```powershell
Set-Location -LiteralPath 'D:\work\项目\逐日\程序\python\GPT v1\release'
.\SolarTracker-local-windows-x64.exe
```

本机版本只是构建验证产物；上传源码并触发工作流后，GitHub 会重新生成可下载的版本化 EXE。当前目录还没有有效的 Git 仓库配置或 GitHub 远程地址，因此首次使用时必须先完成下面的“首次上传”步骤。

生成文件为单个 `SolarTracker.exe`，其中包含：

- FastAPI 后端；
- Vue 生产构建页面；
- Python、Uvicorn、Pydantic、NumPy、Pillow 和时区数据等运行依赖；
- 启动后自动打开默认浏览器的桌面启动器。

PLC/TIA 离线工程、源码、测试、`node_modules`、本机 `.env`、运行日志以及误复制目录 `11/` 不会放入 EXE。

## 一、首次上传到 GitHub

在 PowerShell 中执行。请先把 `<GitHub用户名>` 和 `<仓库名>` 替换为真实值。

```powershell
Set-Location -LiteralPath 'D:\work\项目\逐日\程序\python\GPT v1'

git init
git branch -M main
git add .
git status
git commit -m "Add Windows EXE packaging workflow"

git remote add origin 'https://github.com/<GitHub用户名>/<仓库名>.git'
git push -u origin main
```

如果已经存在名为 `origin` 的远程地址，使用下面的命令更新：

```powershell
git remote set-url origin 'https://github.com/<GitHub用户名>/<仓库名>.git'
git push -u origin main
```

检查远程地址：

```powershell
git remote -v
```

注意：`.env` 已被 `.gitignore` 排除，不要用 `git add -f .env` 上传现场配置、令牌或密码。

## 二、在 GitHub 网页上手动打包

1. 打开 GitHub 仓库。
2. 点击 `Actions`。
3. 左侧选择 `Build Windows EXE`。
4. 点击 `Run workflow`。
5. 选择 `main` 分支，再次点击绿色 `Run workflow`。
6. 等待 `Test and package Windows x64` 全部变绿。
7. 打开该次运行记录，在页面下方 `Artifacts` 下载 `SolarTracker-windows-x64`。
8. 解压后得到版本化 EXE 和 `SHA256SUMS.txt`。

工作流会自动执行：

```text
安装 pnpm 和 Node.js 24
安装并测试 Vue
构建 frontend/dist
安装 Python 3.12、后端依赖和 PyInstaller
运行后端测试与 Ruff
生成单文件 SolarTracker.exe
启动 EXE 并检查 API 与 Vue 页面
计算 SHA-256
上传 GitHub Actions Artifact
```

## 三、使用 GitHub CLI 触发并下载

安装并登录 GitHub CLI 后执行：

```powershell
winget install --id GitHub.cli
```

安装完成后重新打开 PowerShell，再执行：

```powershell
Set-Location -LiteralPath 'D:\work\项目\逐日\程序\python\GPT v1'

gh auth login
gh workflow run build-windows-exe.yml --ref main
gh run list --workflow build-windows-exe.yml --limit 5
```

从上一条输出中复制运行编号，替换 `<运行编号>`：

```powershell
gh run watch <运行编号> --exit-status

New-Item -ItemType Directory -Path release -Force | Out-Null
gh run download <运行编号> --name SolarTracker-windows-x64 --dir release
Get-ChildItem -LiteralPath release
```

## 四、通过版本标签自动创建 Release

工作流监听 `v*` 标签。下面的命令会构建 EXE，并在 GitHub Releases 中发布：

```powershell
Set-Location -LiteralPath 'D:\work\项目\逐日\程序\python\GPT v1'

git add .
git commit -m "Release Windows EXE workflow"
git push origin main

git tag v1.2.0
git push origin v1.2.0
```

查看构建和 Release：

```powershell
gh run list --workflow build-windows-exe.yml --limit 5
gh release view v1.2.0 --web
```

如果标签写错，先在确认没有用户依赖该版本后再处理；不要直接覆盖已发布版本。

## 五、运行 EXE

双击 `SolarTracker-<版本>-windows-x64.exe`，或在 PowerShell 中运行：

```powershell
Set-Location -LiteralPath 'D:\下载EXE所在目录'
.\SolarTracker-v1.2.0-windows-x64.exe
```

默认行为：

- 监听 `127.0.0.1:8188`；
- 后端就绪后打开 `http://127.0.0.1:8188`；
- 关闭 EXE 控制台窗口或按 `Ctrl+C` 停止系统；
- 运行数据写入 `%LOCALAPPDATA%\SolarTracker\data`。

不自动打开浏览器：

```powershell
.\SolarTracker-v1.2.0-windows-x64.exe --no-browser
```

指定其他端口：

```powershell
.\SolarTracker-v1.2.0-windows-x64.exe --port 8288
```

指定运行数据目录：

```powershell
.\SolarTracker-v1.2.0-windows-x64.exe --data-dir 'D:\SolarTrackerData'
```

如果提示 `127.0.0.1:8188 已被占用`，先关闭旧的 EXE 或后端服务，或者使用 `--port 8288`。

## 六、EXE 旁边的现场配置

出于安全原因，工作流绝不会把根目录 `.env` 打进 EXE。下载的 Artifact/Release 中会带有不含密钥的 `SolarTracker.env.example`。需要现场配置时，把它复制到 EXE 同目录并改名为 `.env`：

```powershell
Copy-Item -LiteralPath '.\SolarTracker.env.example' -Destination '.\.env'
notepad '.\.env'
```

配置完成后运行 EXE。真实 PLC、相机、机械限位、热像标定与控制权限仍遵守工程中的安全默认值；未完成现场标定时不要启用真实运动输出。

## 七、本机复现 GitHub 打包过程

需要 Python 3.11+、Node.js 和 pnpm。建议用 Python 3.12，与 GitHub 工作流一致。

```powershell
Set-Location -LiteralPath 'D:\work\项目\逐日\程序\python\GPT v1'

pnpm --dir frontend install --frozen-lockfile
pnpm --dir frontend test
pnpm --dir frontend build

python -m pip install --upgrade pip
python -m pip install -e "backend[test,build]" ruff
python -m pytest -p no:cacheprovider backend/tests
python -m ruff check --no-cache backend/app packaging/desktop_entry.py

python -m PyInstaller --noconfirm --clean packaging/solar_tracker.spec
.\dist\SolarTracker.exe
```

本机不打开浏览器的冒烟测试：

```powershell
$exe = (Resolve-Path -LiteralPath '.\dist\SolarTracker.exe').Path
$port = 8199
$process = Start-Process -FilePath $exe -ArgumentList @(
  '--no-browser',
  '--port', "$port",
  '--data-dir', "$env:TEMP\solar-tracker-smoke-data"
) -PassThru

try {
  Start-Sleep -Seconds 15
  Invoke-RestMethod "http://127.0.0.1:$port/api/v1/health"
  Invoke-WebRequest "http://127.0.0.1:$port/"
} finally {
  # PyInstaller 单文件程序会派生服务子进程，需要同时清理监听进程。
  $listeners = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
  foreach ($listener in $listeners) {
    $listenerProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $($listener.OwningProcess)"
    if ($listenerProcess.ExecutablePath -eq $exe) {
      Stop-Process -Id $listener.OwningProcess -Force -ErrorAction SilentlyContinue
    }
  }
  if (-not $process.HasExited) {
    Stop-Process -Id $process.Id -Force
  }
}
```

## 八、校验下载文件

```powershell
Set-Location -LiteralPath 'D:\下载EXE所在目录'
Get-FileHash '.\SolarTracker-v1.2.0-windows-x64.exe' -Algorithm SHA256
Get-Content '.\SHA256SUMS.txt'
```

两处 SHA-256 必须一致。GitHub 云端生成的 EXE目前没有代码签名；正式分发前应使用企业代码签名证书签名，不要绕过 Windows 安全警告。

## 九、相关文件

```text
.github/workflows/build-windows-exe.yml  GitHub Actions 工作流
packaging/desktop_entry.py               EXE 运行入口
packaging/solar_tracker.spec             PyInstaller 单文件配置
backend/pyproject.toml                   Python 运行与打包依赖
.gitignore                               排除密钥、缓存、构建物和 11/ 目录
```

GitHub Actions 产物说明：<https://docs.github.com/actions/concepts/workflows-and-actions/workflow-artifacts>
