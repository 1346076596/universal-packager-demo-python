from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
import webbrowser
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BACKEND_DIR = ROOT / "backend"
FRONTEND_DIR = ROOT / "frontend"
HOST = "127.0.0.1"
BACKEND_PORT = 8188
FRONTEND_PORT = 5173
BACKEND_HEALTH_URL = f"http://{HOST}:{BACKEND_PORT}/api/v1/health"
BACKEND_OPENAPI_URL = f"http://{HOST}:{BACKEND_PORT}/openapi.json"
FRONTEND_URL = f"http://{HOST}:{FRONTEND_PORT}"
HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class StartupError(RuntimeError):
    pass


@dataclass
class ManagedService:
    name: str
    process: subprocess.Popen[bytes]


stop_requested = False


def handle_stop_signal(_signum: int, _frame: object) -> None:
    global stop_requested
    stop_requested = True


def read_url(url: str) -> bytes | None:
    try:
        with HTTP.open(url, timeout=1.2) as response:
            if 200 <= response.status < 300:
                return response.read(256_000)
    except (OSError, TimeoutError, urllib.error.URLError):
        return None
    return None


def backend_is_ready() -> bool:
    body = read_url(BACKEND_HEALTH_URL)
    if body is None:
        return False
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return False
    health_ready = (
        isinstance(payload, dict)
        and payload.get("status") in {"ok", "degraded"}
        and isinstance(payload.get("services"), dict)
    )
    if not health_ready:
        return False

    # 不要把仍占用 8188 端口的旧后端误判为当前版本。历史曲线依赖此
    # 契约；静默复用旧进程会让页面只有空白图表而没有真实数据。
    contract = read_url(BACKEND_OPENAPI_URL)
    if contract is None:
        return False
    try:
        specification = json.loads(contract.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return False
    paths = specification.get("paths") if isinstance(specification, dict) else None
    return isinstance(paths, dict) and "/api/v1/weather/history" in paths


def frontend_is_ready() -> bool:
    body = read_url(FRONTEND_URL)
    if body is None:
        return False
    page = body.decode("utf-8", errors="replace")
    return '<div id="app"></div>' in page and "/src/main.ts" in page


def process_options() -> dict[str, object]:
    if os.name == "nt":
        return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP}
    return {"start_new_session": True}


def verify_backend_runtime() -> None:
    check = subprocess.run(
        [sys.executable, "-c", "import fastapi, uvicorn"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=15,
        check=False,
    )
    if check.returncode != 0:
        raise StartupError(
            "当前 VS Code Python 解释器缺少后端依赖。请先执行："
            'python -m pip install -e "backend[test]"'
        )


def start_backend() -> ManagedService:
    verify_backend_runtime()
    command = [
        sys.executable,
        "-m",
        "uvicorn",
        "app.main:app",
        "--app-dir",
        str(BACKEND_DIR),
        "--host",
        HOST,
        "--port",
        str(BACKEND_PORT),
    ]
    environment = os.environ.copy()
    environment["PYTHONUNBUFFERED"] = "1"
    environment.setdefault("PYTHONUTF8", "1")
    print(f"[启动] 后端 API：http://{HOST}:{BACKEND_PORT}", flush=True)
    return ManagedService(
        "后端",
        subprocess.Popen(
            command,
            cwd=ROOT,
            env=environment,
            **process_options(),
        ),
    )


def start_frontend() -> ManagedService:
    node = shutil.which("node")
    vite = FRONTEND_DIR / "node_modules" / "vite" / "bin" / "vite.js"
    if node is None:
        raise StartupError("未找到 Node.js，请安装 Node.js 20 或更高版本。")
    if not vite.is_file():
        raise StartupError("前端依赖未安装。请先执行：cd frontend；pnpm install")
    command = [
        node,
        str(vite),
        "--host",
        HOST,
        "--port",
        str(FRONTEND_PORT),
        "--strictPort",
    ]
    print(f"[启动] 前端 Vite：{FRONTEND_URL}", flush=True)
    return ManagedService(
        "前端",
        subprocess.Popen(
            command,
            cwd=FRONTEND_DIR,
            env=os.environ.copy(),
            **process_options(),
        ),
    )


def wait_until_ready(
    services: list[ManagedService], timeout_seconds: float
) -> None:
    deadline = time.monotonic() + timeout_seconds
    backend_reported = False
    frontend_reported = False

    while time.monotonic() < deadline and not stop_requested:
        for service in services:
            code = service.process.poll()
            if code is not None:
                raise StartupError(
                    f"{service.name}进程提前退出（退出码 {code}），请查看上方日志。"
                )

        backend_ready = backend_is_ready()
        frontend_ready = frontend_is_ready()
        if backend_ready and not backend_reported:
            print(f"[就绪] 后端健康检查通过：{BACKEND_HEALTH_URL}", flush=True)
            backend_reported = True
        if frontend_ready and not frontend_reported:
            print(f"[就绪] 前端页面可访问：{FRONTEND_URL}", flush=True)
            frontend_reported = True
        if backend_ready and frontend_ready:
            return
        time.sleep(0.3)

    if stop_requested:
        raise KeyboardInterrupt
    missing = []
    if not backend_is_ready():
        missing.append("后端")
    if not frontend_is_ready():
        missing.append("前端")
    raise StartupError(
        f"等待 {'、'.join(missing)} 就绪超时（{timeout_seconds:.0f} 秒）。"
    )


def stop_service(service: ManagedService) -> None:
    process = service.process
    if process.poll() is not None:
        return
    print(f"[停止] 正在关闭{service.name}……", flush=True)
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=8,
            check=False,
        )
    else:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)


def monitor_services(services: list[ManagedService]) -> None:
    while not stop_requested:
        for service in services:
            code = service.process.poll()
            if code is not None:
                raise StartupError(
                    f"{service.name}已停止（退出码 {code}），其余服务将一起关闭。"
                )
        time.sleep(0.5)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="启动逐日追踪系统前后端")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--exit-after-ready", action="store_true")
    parser.add_argument("--startup-timeout", type=float, default=75.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    services: list[ManagedService] = []
    signal.signal(signal.SIGINT, handle_stop_signal)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, handle_stop_signal)

    print("=" * 58)
    print("逐日追踪系统：前后端一键启动")
    print("按 Ctrl+C 或点击 VS Code 停止按钮可同时关闭服务。")
    print("=" * 58, flush=True)

    try:
        if backend_is_ready():
            print("[复用] 后端已经正常运行。", flush=True)
        elif read_url(BACKEND_HEALTH_URL) is not None:
            raise StartupError(
                f"端口 {BACKEND_PORT} 上运行的是旧版或不兼容的 Python 后端。"
                "请先停止旧的运行终端，再重新点击运行；否则历史天气曲线接口"
                "不会生效。"
            )
        else:
            services.append(start_backend())

        if frontend_is_ready():
            print("[复用] 前端已经正常运行。", flush=True)
        else:
            services.append(start_frontend())

        wait_until_ready(services, args.startup_timeout)
        print("[完成] 前后端均已正常启动。", flush=True)

        if not args.no_browser:
            opened = webbrowser.open_new_tab(FRONTEND_URL)
            print(
                "[界面] 已请求打开默认浏览器。"
                if opened
                else f"[界面] 请手动打开：{FRONTEND_URL}",
                flush=True,
            )

        if args.exit_after_ready or not services:
            return 0
        monitor_services(services)
        return 0
    except KeyboardInterrupt:
        print("\n[停止] 收到停止请求。", flush=True)
        return 0
    except StartupError as exc:
        print(f"\n[失败] {exc}", file=sys.stderr, flush=True)
        return 1
    finally:
        for service in reversed(services):
            stop_service(service)


if __name__ == "__main__":
    raise SystemExit(main())
