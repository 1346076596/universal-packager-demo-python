from __future__ import annotations

import argparse
import json
import time
import urllib.error
import urllib.request

DEFAULT_URL = "http://127.0.0.1:8188/api/v1/health"
HTTP = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def backend_is_ready(url: str) -> bool:
    try:
        with HTTP.open(url, timeout=1.2) as response:
            if not 200 <= response.status < 300:
                return False
            payload = json.loads(response.read(256_000).decode("utf-8"))
    except (
        OSError,
        TimeoutError,
        UnicodeDecodeError,
        json.JSONDecodeError,
        urllib.error.URLError,
    ):
        return False

    # 安全默认配置下 PLC 未接入，健康状态会是 degraded；这仍表示 API 已就绪。
    return (
        isinstance(payload, dict)
        and payload.get("status") in {"ok", "degraded"}
        and isinstance(payload.get("services"), dict)
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="等待逐日追踪后端健康检查")
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--timeout", type=float, default=75.0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    deadline = time.monotonic() + args.timeout
    print(f"等待后端就绪：{args.url}", flush=True)

    while time.monotonic() < deadline:
        if backend_is_ready(args.url):
            print("后端健康检查通过，继续启动前端。", flush=True)
            return 0
        time.sleep(0.3)

    print(f"后端在 {args.timeout:.0f} 秒内未就绪。", flush=True)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
