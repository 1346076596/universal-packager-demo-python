from __future__ import annotations

import json
from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from app.application.permission_service import PermissionService
from app.config import AppSettings, MechanicalLimits
from app.domain.settings import SiteConfig
from app.infrastructure.config_repository import ConfigRepository


def test_safe_defaults_leave_motion_and_media_uncommissioned() -> None:
    settings = AppSettings()
    assert settings.mechanics.configured is False
    assert settings.thermal.configured is False
    assert settings.thermal_hardware_approved is False
    assert settings.plc_gateway_kind == "unconfigured"
    assert settings.camera_gateway_kind == "unconfigured"
    assert settings.media_access_mode == "deny"
    assert settings.control_access_mode == "deny"


def test_production_rejects_any_development_simulation() -> None:
    with pytest.raises(ValueError, match="forbidden in production"):
        AppSettings(
            environment="production",
            enable_development_simulation=True,
            plc_gateway_kind="development_simulation",
        )


def test_simulation_gateway_requires_explicit_opt_in() -> None:
    with pytest.raises(ValueError, match="explicit"):
        AppSettings(plc_gateway_kind="development_simulation")


def test_configured_mechanics_require_real_ranges() -> None:
    with pytest.raises(ValueError, match="azimuth"):
        MechanicalLimits(configured=True)


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("latitude", 91.0),
        ("latitude", -91.0),
        ("longitude", 181.0),
        ("longitude", -181.0),
        ("timezone", "Mars/Olympus"),
    ],
)
def test_site_config_validation(field: str, value: object) -> None:
    payload = {
        "latitude": 30.25,
        "longitude": 120.15,
        "timezone": "Asia/Shanghai",
    }
    payload[field] = value
    with pytest.raises(ValidationError):
        SiteConfig.model_validate(payload)


def test_calculation_override_must_be_timezone_aware() -> None:
    with pytest.raises(ValidationError, match="timezone"):
        SiteConfig(calculation_time_override=datetime(2026, 1, 1))


def test_repository_persists_and_audits_old_and_new_values(tmp_path) -> None:
    config_path = tmp_path / "nested" / "site.json"
    audit_path = tmp_path / "audit" / "events.jsonl"
    default = SiteConfig()
    repository = ConfigRepository(config_path, audit_path, default)
    updated = SiteConfig(latitude=31.0, longitude=121.0, timezone="Asia/Shanghai")

    repository.save(
        updated,
        operator="tester",
        session_id="session-1",
        changed_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
    )

    assert repository.load() == updated
    record = json.loads(audit_path.read_text(encoding="utf-8").strip())
    assert record["operator"] == "tester"
    assert record["session_id"] == "session-1"
    assert record["old"]["latitude"] == default.latitude
    assert record["new"]["latitude"] == 31.0


def test_control_permissions_are_deny_by_default_and_support_allowlist() -> None:
    denied = PermissionService(AppSettings()).denial_reason(
        operator="alice",
        session_id="session",
        action="manual_jog",
    )
    assert denied and "safe default" in denied

    settings = AppSettings(
        control_access_mode="operator_allowlist",
        allowed_control_operators=("alice",),
    )
    permissions = PermissionService(settings)
    assert (
        permissions.denial_reason(
            operator="alice", session_id="session", action="manual_jog"
        )
        is None
    )
    assert "not authorized" in (
        permissions.denial_reason(
            operator="bob", session_id="session", action="manual_jog"
        )
        or ""
    )
