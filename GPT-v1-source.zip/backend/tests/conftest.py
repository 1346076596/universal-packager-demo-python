from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pytest

from app.config import (
    AppSettings,
    ControlSettings,
    MechanicalLimits,
    WeatherSettings,
)
from app.domain.settings import SiteConfig
from app.domain.thermal import ThermalCalibration


class FakeWeatherClient:
    def __init__(self) -> None:
        self.calls = 0
        self.closed = False
        self.fail = False

    async def fetch_hourly(
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str,
        start_date: date,
        end_date: date,
        source: str,
    ) -> dict[str, Any]:
        self.calls += 1
        if self.fail:
            raise TimeoutError("synthetic timeout")
        start = datetime.combine(start_date, datetime.min.time())
        hours = int((end_date - start_date).days * 24) + 24
        times = [
            (start + timedelta(hours=index)).isoformat(timespec="minutes")
            for index in range(hours)
        ]
        count = len(times)
        return {
            "hourly": {
                "time": times,
                "temperature_2m": [21.5] * count,
                "weather_code": [1] * count,
                "cloud_cover": [25.0] * count,
                "cloud_cover_low": [15.0] * count,
                "cloud_cover_mid": [10.0] * count,
                "cloud_cover_high": [5.0] * count,
                "visibility": [20_000.0] * count,
                "wind_speed_10m": [3.5] * count,
                "wind_direction_10m": [350.0] * count,
                "wind_gusts_10m": [5.5] * count,
                "shortwave_radiation": [500.0] * count,
                "direct_normal_irradiance": [450.0] * count,
                "is_day": [1] * count,
            }
        }

    async def close(self) -> None:
        self.closed = True


@pytest.fixture
def commissioned_settings(tmp_path: Path) -> AppSettings:
    return AppSettings(
        environment="test",
        enable_development_simulation=True,
        plc_gateway_kind="development_simulation",
        camera_gateway_kind="development_simulation",
        thermal_hardware_approved=True,
        media_access_mode="trusted_network",
        control_access_mode="trusted_network",
        site_config_path=tmp_path / "site.json",
        audit_log_path=tmp_path / "audit.jsonl",
        default_site=SiteConfig(
            latitude=30.25,
            longitude=120.15,
            timezone="Asia/Shanghai",
            calculation_time_override=datetime(
                2026, 6, 21, 12, 0, tzinfo=timezone(timedelta(hours=8))
            ),
        ),
        mechanics=MechanicalLimits(
            configured=True,
            azimuth_min=0.0,
            azimuth_max=360.0,
            elevation_min=0.0,
            elevation_max=90.0,
            parking_calibrated=True,
            parking_azimuth=180.0,
            parking_elevation=10.0,
        ),
        control=ControlSettings(
            command_ttl_seconds=10.0,
            max_manual_step_degrees=2.0,
            max_manual_duration_seconds=2.0,
            plc_poll_seconds=0.05,
            snapshot_publish_seconds=0.05,
            solar_update_seconds=0.05,
            thermal_analysis_seconds=0.05,
            weather_update_seconds=60.0,
            websocket_heartbeat_seconds=0.1,
        ),
        weather=WeatherSettings(
            timeout_seconds=0.5,
            cache_ttl_seconds=60.0,
            stale_max_age_seconds=600.0,
            forecast_days=2,
        ),
        thermal=ThermalCalibration(
            configured=True,
            hot_threshold=50.0,
            min_hot_pixels=4,
            max_frame_age_seconds=2.0,
        ),
    )


@pytest.fixture
def fake_weather_client() -> FakeWeatherClient:
    return FakeWeatherClient()
