from __future__ import annotations

import io
from datetime import datetime, timedelta, timezone

import numpy as np
import pytest
from PIL import Image

from app.domain.thermal import (
    AxisPriority,
    HorizontalDirection,
    ThermalCalibration,
    ThermalGuidance,
    VerticalDirection,
)
from app.infrastructure.frame_store import FrameRecord, FrameStore
from app.services.thermal_tracker import ThermalTracker


def _jpeg() -> bytes:
    image = Image.new("RGB", (160, 120), color=(30, 30, 30))
    output = io.BytesIO()
    image.save(output, format="JPEG")
    return output.getvalue()


def _matrix(x: int, y: int) -> np.ndarray:
    matrix = np.full((20, 20), 20.0)
    matrix[max(0, y - 1) : y + 2, max(0, x - 1) : x + 2] = 100.0
    return matrix


def test_center_hotspot_is_aligned_and_annotation_preserves_raw() -> None:
    tracker = ThermalTracker(ThermalCalibration(configured=True, hot_threshold=50.0))
    captured = datetime.now(timezone.utc)
    guidance = tracker.analyze(
        _matrix(10, 10),
        frame_id=1,
        captured_at=captured,
        now=captured,
    )
    raw = _jpeg()
    annotated = tracker.annotate_jpeg(
        raw, guidance, thermal_width=20, thermal_height=20
    )

    assert guidance.valid is True
    assert guidance.aligned is True
    assert guidance.horizontal_direction is HorizontalDirection.NONE
    assert guidance.vertical_direction is VerticalDirection.NONE
    assert raw == _jpeg()
    assert annotated.startswith(b"\xff\xd8")
    assert annotated != raw


def test_offset_and_installation_signs_produce_semantic_directions() -> None:
    tracker = ThermalTracker(
        ThermalCalibration(
            configured=True,
            hot_threshold=50.0,
            horizontal_sign=-1,
            vertical_sign=-1,
        )
    )
    captured = datetime.now(timezone.utc)
    guidance = tracker.analyze(
        _matrix(17, 3),
        frame_id=2,
        captured_at=captured,
        now=captured,
    )

    assert guidance.valid is True
    assert guidance.horizontal_direction is HorizontalDirection.LEFT
    assert guidance.vertical_direction is VerticalDirection.DOWN
    assert guidance.priority_axis in {
        AxisPriority.AZIMUTH,
        AxisPriority.ELEVATION,
    }


def test_stale_missing_and_saturated_frames_are_invalid() -> None:
    calibration = ThermalCalibration(
        configured=True,
        hot_threshold=50.0,
        saturation_temperature=120.0,
        max_saturation_ratio=0.1,
        max_frame_age_seconds=1.0,
    )
    tracker = ThermalTracker(calibration)
    now = datetime.now(timezone.utc)
    stale = tracker.analyze(
        _matrix(10, 10),
        frame_id=1,
        captured_at=now - timedelta(seconds=2),
        now=now,
    )
    missing = tracker.analyze(
        np.full((20, 20), 20.0),
        frame_id=2,
        captured_at=now,
        now=now,
    )
    saturated = tracker.analyze(
        np.full((20, 20), 130.0),
        frame_id=3,
        captured_at=now,
        now=now,
    )

    assert stale.invalid_reason == "frame_stale"
    assert missing.invalid_reason == "hotspot_not_found"
    assert saturated.invalid_reason == "frame_saturated"


def test_uncommissioned_calibration_is_safe_invalid() -> None:
    now = datetime.now(timezone.utc)
    guidance = ThermalTracker(ThermalCalibration()).analyze(
        _matrix(10, 10),
        frame_id=1,
        captured_at=now,
        now=now,
    )
    assert guidance.valid is False
    assert guidance.invalid_reason == "thermal_calibration_not_commissioned"


def test_frame_store_enforces_same_and_monotonic_frame_ids() -> None:
    store = FrameStore()
    now = datetime.now(timezone.utc)
    guidance = ThermalGuidance.invalid("test", frame_id=1, captured_at=now, now=now)
    record = FrameRecord(1, now, _jpeg(), _jpeg(), guidance)
    store.publish(record)
    assert store.latest() is record

    with pytest.raises(ValueError, match="monotonically"):
        store.publish(record)
    with pytest.raises(ValueError, match="same frame_id"):
        FrameRecord(
            2,
            now,
            _jpeg(),
            _jpeg(),
            guidance,
        )
