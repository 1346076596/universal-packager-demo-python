from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import pytest

import app.services.weather_service as weather_service_module
from app.config import MechanicalLimits, WeatherSettings
from app.domain.settings import SiteConfig
from app.domain.thermal import ThermalGuidance
from app.domain.weather import WeatherSample, WeatherState
from app.services.reappearance_predictor import ReappearancePredictor
from app.services.solar_position import SolarPositionService
from app.services.weather_service import WeatherService


class MutableClock:
    def __init__(self, value: datetime) -> None:
        self.value = value

    def __call__(self) -> datetime:
        return self.value


class InterpolationClient:
    def __init__(self) -> None:
        self.calls = 0
        self.fail = False
        self.requests: list[dict[str, object]] = []

    async def fetch_hourly(self, **kwargs):
        self.calls += 1
        self.requests.append(kwargs)
        if self.fail:
            raise TimeoutError
        return {
            "hourly": {
                "time": ["2026-06-01T00:00", "2026-06-01T01:00"],
                "weather_code": [61, 3],
                "cloud_cover": [10.0, 20.0],
                "cloud_cover_low": [10.0, 20.0],
                "cloud_cover_mid": [10.0, 20.0],
                "cloud_cover_high": [10.0, 20.0],
                "visibility": [1000.0, 2000.0],
                "wind_speed_10m": [2.0, 4.0],
                "wind_direction_10m": [350.0, 10.0],
                "wind_gusts_10m": [3.0, 5.0],
                "shortwave_radiation": [100.0, 300.0],
                "direct_normal_irradiance": [100.0, 300.0],
                "is_day": [0, 1],
            }
        }

    async def close(self) -> None:
        return None


class CurrentClient(InterpolationClient):
    async def fetch_hourly(self, **kwargs):
        payload = await super().fetch_hourly(**kwargs)
        payload["current"] = {
            "time": "2026-06-01T00:25",
            "weather_code": 63,
            "cloud_cover": 77.0,
            "cloud_cover_low": 70.0,
            "cloud_cover_mid": 20.0,
            "cloud_cover_high": 10.0,
            "visibility": 800.0,
            "wind_speed_10m": 5.0,
            "wind_direction_10m": 45.0,
            "wind_gusts_10m": 8.0,
            "shortwave_radiation": 50.0,
            "direct_normal_irradiance": 20.0,
            "is_day": 1,
        }
        return payload


class BlockingInterpolationClient(InterpolationClient):
    def __init__(self) -> None:
        super().__init__()
        self.block_started = asyncio.Event()
        self.release_block = asyncio.Event()

    async def fetch_hourly(self, **kwargs):
        if kwargs["longitude"] == 0:
            self.block_started.set()
            await self.release_block.wait()
        return await super().fetch_hourly(**kwargs)


class HistoricalHorizonClient:
    def __init__(self, *, clear_times: set[datetime]) -> None:
        self.clear_times = clear_times
        self.requests: list[dict[str, object]] = []

    async def fetch_hourly(self, **kwargs):
        self.requests.append(kwargs)
        start = datetime.combine(kwargs["start_date"], datetime.min.time())
        end = datetime.combine(kwargs["end_date"], datetime.max.time())
        count = int((end.date() - start.date()).days * 24) + 24
        timestamps = [start + timedelta(hours=index) for index in range(count)]
        clear = [timestamp in self.clear_times for timestamp in timestamps]
        return {
            "hourly": {
                "time": [
                    timestamp.isoformat(timespec="minutes") for timestamp in timestamps
                ],
                "weather_code": [1 if item else 3 for item in clear],
                "cloud_cover": [20.0 if item else 100.0 for item in clear],
                "cloud_cover_low": [10.0 if item else 100.0 for item in clear],
                "cloud_cover_mid": [5.0 if item else 100.0 for item in clear],
                "cloud_cover_high": [5.0 if item else 100.0 for item in clear],
                "visibility": [20_000.0] * count,
                "wind_speed_10m": [4.0] * count,
                "wind_direction_10m": [90.0] * count,
                "wind_gusts_10m": [6.0] * count,
                "shortwave_radiation": [500.0 if item else 10.0 for item in clear],
                "direct_normal_irradiance": [
                    500.0 if item else 10.0 for item in clear
                ],
                "is_day": [1 if item else 0 for item in clear],
            }
        }

    async def close(self) -> None:
        return None


class HistoryClient:
    def __init__(self, *, fail_sources: set[str] | None = None) -> None:
        self.fail_sources = fail_sources or set()
        self.requests: list[dict[str, object]] = []

    async def fetch_hourly(self, **kwargs):
        self.requests.append(kwargs)
        if kwargs["source"] in self.fail_sources:
            raise TimeoutError
        start = datetime.combine(kwargs["start_date"], datetime.min.time())
        count = int((kwargs["end_date"] - kwargs["start_date"]).days * 24) + 24
        timestamps = [start + timedelta(hours=index) for index in range(count)]
        return {
            "hourly": {
                "time": [
                    timestamp.isoformat(timespec="minutes")
                    for timestamp in timestamps
                ],
                "temperature_2m": [
                    float(timestamp.day + timestamp.hour) for timestamp in timestamps
                ],
                "weather_code": [1] * count,
                "cloud_cover": [float(timestamp.hour) for timestamp in timestamps],
                "cloud_cover_low": [10.0] * count,
                "cloud_cover_mid": [20.0] * count,
                "cloud_cover_high": [30.0] * count,
                "visibility": [20_000.0] * count,
                "wind_speed_10m": [float(timestamp.hour) for timestamp in timestamps],
                "wind_direction_10m": [90.0] * count,
                "wind_gusts_10m": [20.0] * count,
                "shortwave_radiation": [500.0] * count,
                "direct_normal_irradiance": [450.0] * count,
                "is_day": [1] * count,
            }
        }

    async def close(self) -> None:
        return None


class MissingTemperatureHistoryClient(HistoryClient):
    async def fetch_hourly(self, **kwargs):
        payload = await super().fetch_hourly(**kwargs)
        del payload["hourly"]["temperature_2m"]
        return payload


@pytest.mark.asyncio
async def test_weather_interpolates_wind_circularly_and_uses_shared_cache() -> None:
    clock = MutableClock(datetime(2026, 6, 1, 0, 0, tzinfo=timezone.utc))
    client = InterpolationClient()
    service = WeatherService(
        client,
        WeatherSettings(
            cache_ttl_seconds=10.0,
            stale_max_age_seconds=60.0,
            forecast_days=1,
        ),
        clock=clock,
    )
    site = SiteConfig(latitude=0, longitude=0, timezone="UTC")
    target = datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc)

    first = await service.get_weather(site, target)
    second = await service.get_weather(site, target)

    assert first.valid is True
    assert first.selected is not None
    assert first.hourly[0].weather_code == 61
    assert first.selected.weather_code == 3
    assert first.selected.cloud_cover == pytest.approx(15.0)
    assert first.selected.wind_direction == pytest.approx(0.0)
    assert second.valid is True
    assert client.calls == 1


@pytest.mark.asyncio
async def test_current_nearby_time_prefers_open_meteo_current_values() -> None:
    clock = MutableClock(datetime(2026, 6, 1, 0, 0, tzinfo=timezone.utc))
    client = CurrentClient()
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=1),
        clock=clock,
    )
    state = await service.get_weather(
        SiteConfig(latitude=0, longitude=0, timezone="UTC"),
        datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc),
    )
    assert state.valid is True
    assert state.selection_method == "current"
    assert state.selected is not None
    assert state.selected.weather_code == 63
    assert state.selected.cloud_cover == 77.0


@pytest.mark.asyncio
async def test_manual_time_override_does_not_substitute_live_current_values() -> None:
    clock = MutableClock(datetime(2026, 6, 1, 0, 0, tzinfo=timezone.utc))
    client = CurrentClient()
    target = datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc)
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=1),
        clock=clock,
    )

    state = await service.get_weather(
        SiteConfig(
            latitude=0,
            longitude=0,
            timezone="UTC",
            calculation_time_override=target,
        ),
        target,
    )

    assert state.valid is True
    assert state.selection_method == "hourly_interpolated"
    assert state.selected is not None
    assert state.selected.weather_code == 3
    assert state.selected.cloud_cover == pytest.approx(15.0)


@pytest.mark.asyncio
async def test_last_hour_sample_covers_the_remainder_of_the_selected_day() -> None:
    clock = MutableClock(datetime(2026, 6, 3, 12, 0, tzinfo=timezone.utc))
    last_hour = datetime(2026, 6, 1, 23, 0)
    target = datetime(2026, 6, 1, 23, 45, tzinfo=timezone.utc)
    client = HistoricalHorizonClient(clear_times={last_hour})
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=1),
        clock=clock,
    )

    state = await service.get_weather(
        SiteConfig(
            latitude=0,
            longitude=0,
            timezone="UTC",
            calculation_time_override=target,
        ),
        target,
    )

    assert state.valid is True
    assert state.selection_method == "hourly_nearest_boundary"
    assert state.selected is not None
    assert state.selected.valid_time == target
    assert state.selected.weather_code == 1
    assert state.selected.cloud_cover == 20.0
    assert state.error is None


def test_nearest_hour_boundary_is_bounded_and_supports_both_edges() -> None:
    fetched_at = datetime(2026, 6, 1, 12, 0, tzinfo=timezone.utc)
    only_sample = WeatherSample(
        valid_time=datetime(2026, 6, 1, 23, 0, tzinfo=timezone.utc),
        weather_code=61,
        cloud_cover=80.0,
        source_fetched_at=fetched_at,
    )
    just_before = datetime(2026, 6, 1, 22, 30, tzinfo=timezone.utc)
    just_after = datetime(2026, 6, 1, 23, 59, 59, tzinfo=timezone.utc)
    too_early = datetime(2026, 6, 1, 21, 59, 59, tzinfo=timezone.utc)
    too_late = datetime(2026, 6, 2, 0, 0, 1, tzinfo=timezone.utc)

    before = WeatherService._interpolate((only_sample,), just_before)
    after = WeatherService._interpolate((only_sample,), just_after)

    assert before is not None
    assert before.valid_time == just_before
    assert after is not None
    assert after.valid_time == just_after
    assert WeatherService._interpolate((only_sample,), too_early) is None
    assert WeatherService._interpolate((only_sample,), too_late) is None


@pytest.mark.asyncio
async def test_weather_cache_and_idle_lock_maps_use_bounded_lru_eviction(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(weather_service_module, "WEATHER_CACHE_MAX_ENTRIES", 3)
    monkeypatch.setattr(weather_service_module, "WEATHER_LOCK_MAX_ENTRIES", 3)
    client = InterpolationClient()
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=1),
        clock=MutableClock(datetime(2026, 6, 1, tzinfo=timezone.utc)),
    )
    target = datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc)

    for longitude in range(6):
        state = await service.get_weather(
            SiteConfig(latitude=0, longitude=longitude, timezone="UTC"),
            target,
        )
        assert state.valid is True

    assert len(service._cache) == 3
    assert {key[1] for key in service._cache} == {3, 4, 5}
    assert len(service._locks) == 3
    assert {key[1] for key in service._locks} == {3, 4, 5}
    assert all(
        entry.users == 0 and not entry.lock.locked()
        for entry in service._locks.values()
    )


@pytest.mark.asyncio
async def test_lock_eviction_preserves_active_and_waiting_requests(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(weather_service_module, "WEATHER_CACHE_MAX_ENTRIES", 2)
    monkeypatch.setattr(weather_service_module, "WEATHER_LOCK_MAX_ENTRIES", 1)
    client = BlockingInterpolationClient()
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=1),
        clock=MutableClock(datetime(2026, 6, 1, tzinfo=timezone.utc)),
    )
    target = datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc)
    blocked_site = SiteConfig(latitude=0, longitude=0, timezone="UTC")
    first = asyncio.create_task(service.get_weather(blocked_site, target))
    await asyncio.wait_for(client.block_started.wait(), timeout=1)
    waiter = asyncio.create_task(service.get_weather(blocked_site, target))
    await asyncio.sleep(0)

    retained_while_locked = False
    active_users = 0
    try:
        for longitude in (1, 2):
            state = await service.get_weather(
                SiteConfig(latitude=0, longitude=longitude, timezone="UTC"),
                target,
            )
            assert state.valid is True

        blocked_entries = [
            entry for key, entry in service._locks.items() if key[1] == 0
        ]
        retained_while_locked = bool(
            blocked_entries and blocked_entries[0].lock.locked()
        )
        active_users = blocked_entries[0].users if blocked_entries else 0
        assert len(service._locks) == 1
    finally:
        client.release_block.set()
        first_state, waiter_state = await asyncio.wait_for(
            asyncio.gather(first, waiter), timeout=1
        )

    assert retained_while_locked is True
    assert active_users == 2
    assert first_state.valid is True
    assert waiter_state.valid is True
    assert client.calls == 3
    assert len(service._locks) <= 1


@pytest.mark.asyncio
async def test_refresh_failure_returns_marked_stale_cache() -> None:
    clock = MutableClock(datetime(2026, 6, 1, 0, 0, tzinfo=timezone.utc))
    client = InterpolationClient()
    service = WeatherService(
        client,
        WeatherSettings(
            cache_ttl_seconds=10.0,
            stale_max_age_seconds=60.0,
            forecast_days=1,
        ),
        clock=clock,
    )
    site = SiteConfig(latitude=0, longitude=0, timezone="UTC")
    target = datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc)
    await service.get_weather(site, target)
    clock.value += timedelta(seconds=20)
    client.fail = True

    stale = await service.get_weather(site, target)

    assert stale.valid is True
    assert stale.stale is True
    assert stale.cache_age_seconds == pytest.approx(20.0)
    assert stale.error and stale.error.startswith("refresh_failed")


@pytest.mark.asyncio
async def test_out_of_forecast_range_is_invalid_without_fabrication() -> None:
    clock = MutableClock(datetime(2026, 6, 1, tzinfo=timezone.utc))
    client = InterpolationClient()
    service = WeatherService(
        client,
        WeatherSettings(maximum_future_days=3),
        clock=clock,
    )
    state = await service.get_weather(
        SiteConfig(latitude=0, longitude=0, timezone="UTC"),
        datetime(2026, 6, 10, tzinfo=timezone.utc),
    )
    assert state.valid is False
    assert state.error == "calculation_time_outside_forecast_range"
    assert client.calls == 0


@pytest.mark.asyncio
async def test_open_meteo_future_window_is_hard_limited_to_today_plus_15() -> None:
    clock = MutableClock(datetime(2026, 6, 1, 12, 0, tzinfo=timezone.utc))
    last_supported_date = datetime(2026, 6, 16, 12, 0)
    client = HistoricalHorizonClient(clear_times={last_supported_date})
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=7, maximum_future_days=99),
        clock=clock,
    )
    site = SiteConfig(latitude=0, longitude=0, timezone="UTC")

    supported = await service.get_weather(
        site,
        last_supported_date.replace(tzinfo=timezone.utc),
    )
    unsupported = await service.get_weather(
        site,
        datetime(2026, 6, 17, 12, 0, tzinfo=timezone.utc),
    )

    assert WeatherSettings().maximum_future_days == 15
    assert supported.valid is True
    assert client.requests[0]["start_date"] == date(2026, 6, 1)
    assert client.requests[0]["end_date"] == date(2026, 6, 16)
    assert unsupported.valid is False
    assert unsupported.error == "calculation_time_outside_forecast_range"
    assert len(client.requests) == 1


@pytest.mark.asyncio
async def test_weather_rejects_dates_before_open_meteo_archive_start_locally() -> None:
    clock = MutableClock(datetime(2026, 6, 1, 12, 0, tzinfo=timezone.utc))
    first_supported = datetime(1940, 1, 1, 12, 0)
    client = HistoricalHorizonClient(clear_times={first_supported})
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=1),
        clock=clock,
    )
    site = SiteConfig(latitude=0, longitude=0, timezone="UTC")

    unsupported = await service.get_weather(
        site,
        datetime(1939, 12, 31, 12, 0, tzinfo=timezone.utc),
    )
    supported = await service.get_weather(
        site,
        first_supported.replace(tzinfo=timezone.utc),
    )

    assert unsupported.valid is False
    assert unsupported.error == "calculation_time_before_historical_weather_range"
    assert supported.valid is True
    assert client.requests[0]["source"] == "archive"
    assert client.requests[0]["start_date"] == date(1940, 1, 1)
    assert client.requests[0]["end_date"] == date(1940, 1, 1)
    assert len(client.requests) == 1


@pytest.mark.asyncio
async def test_yesterday_is_included_in_forecast_request_window() -> None:
    clock = MutableClock(datetime(2026, 6, 2, 12, 0, tzinfo=timezone.utc))
    client = InterpolationClient()
    service = WeatherService(
        client,
        WeatherSettings(forecast_days=7),
        clock=clock,
    )

    state = await service.get_weather(
        SiteConfig(latitude=0, longitude=0, timezone="UTC"),
        datetime(2026, 6, 1, 0, 30, tzinfo=timezone.utc),
    )

    assert state.valid is True
    assert state.source == "forecast"
    assert client.calls == 1
    assert client.requests[0]["start_date"] == date(2026, 6, 1)
    assert client.requests[0]["end_date"] == date(2026, 6, 2)


@pytest.mark.asyncio
async def test_historical_weather_horizon_drives_prediction_from_selected_time(
) -> None:
    actual_now = datetime(2026, 8, 3, 12, 0, tzinfo=timezone.utc)
    selected_time = datetime(
        2026, 7, 17, 13, 3, tzinfo=timezone(timedelta(hours=8))
    )
    clear_before_selection = datetime(2026, 7, 17, 10, 0)
    first_clear_after_selection = datetime(2026, 7, 19, 4, 0)
    client = HistoricalHorizonClient(
        clear_times={clear_before_selection, first_clear_after_selection}
    )
    settings = WeatherSettings(forecast_days=7, minimum_prediction_confidence=0.2)
    weather_service = WeatherService(
        client,
        settings,
        clock=MutableClock(actual_now),
    )
    site = SiteConfig(
        latitude=30.25,
        longitude=169.0,
        timezone="Asia/Shanghai",
        calculation_time_override=selected_time,
    )

    weather = await weather_service.get_weather(site, selected_time)

    assert weather.valid is True
    assert weather.source == "archive"
    assert client.requests[0]["start_date"] == date(2026, 7, 17)
    assert client.requests[0]["end_date"] == date(2026, 7, 23)
    assert all(
        sample.valid_time.date() <= date(2026, 7, 23)
        for sample in weather.hourly
    )

    solar_service = SolarPositionService(
        MechanicalLimits(
            configured=True,
            azimuth_min=0,
            azimuth_max=360,
            elevation_min=0,
            elevation_max=90,
        )
    )
    result = ReappearancePredictor(solar_service, settings).predict(
        site=site,
        now=selected_time,
        solar=solar_service.calculate(site, selected_time),
        weather=weather,
        thermal=ThermalGuidance.invalid("camera_unavailable", now=selected_time),
    )

    assert result.valid is True
    assert result.best_estimate == first_clear_after_selection.replace(
        tzinfo=timezone(timedelta(hours=8))
    )
    assert result.best_estimate > selected_time
    assert result.input_weather_time == selected_time


@pytest.mark.asyncio
async def test_historical_prediction_without_clear_time_stays_invalid(
) -> None:
    actual_now = datetime(2026, 8, 3, 12, 0, tzinfo=timezone.utc)
    selected_time = datetime(
        2026, 7, 17, 13, 3, tzinfo=timezone(timedelta(hours=8))
    )
    client = HistoricalHorizonClient(clear_times=set())
    settings = WeatherSettings(forecast_days=3, minimum_prediction_confidence=0.2)
    weather_service = WeatherService(
        client,
        settings,
        clock=MutableClock(actual_now),
    )
    site = SiteConfig(
        latitude=30.25,
        longitude=169.0,
        timezone="Asia/Shanghai",
    )
    weather = await weather_service.get_weather(site, selected_time)
    solar_service = SolarPositionService(
        MechanicalLimits(
            configured=True,
            azimuth_min=0,
            azimuth_max=360,
            elevation_min=0,
            elevation_max=90,
        )
    )

    result = ReappearancePredictor(solar_service, settings).predict(
        site=site,
        now=selected_time,
        solar=solar_service.calculate(site, selected_time),
        weather=weather,
        thermal=ThermalGuidance.invalid("camera_unavailable", now=selected_time),
    )

    assert client.requests[0]["start_date"] == date(2026, 7, 17)
    assert client.requests[0]["end_date"] == date(2026, 7, 19)
    assert result.valid is False
    assert result.invalid_reason == "no_reappearance_candidate_in_weather_window"


def _sample(
    at: datetime, *, cloud: float, dni: float, fetched: datetime
) -> WeatherSample:
    return WeatherSample(
        valid_time=at,
        cloud_cover=cloud,
        cloud_cover_low=cloud,
        cloud_cover_mid=cloud,
        cloud_cover_high=cloud,
        wind_speed=4.0,
        wind_direction=90.0,
        wind_gusts=6.0,
        direct_normal_irradiance=dni,
        shortwave_radiation=dni,
        is_day=True,
        source_fetched_at=fetched,
    )


def test_predictor_returns_range_angles_confidence_and_evidence() -> None:
    mechanics = MechanicalLimits(
        configured=True,
        azimuth_min=0,
        azimuth_max=360,
        elevation_min=0,
        elevation_max=90,
    )
    solar_service = SolarPositionService(mechanics)
    settings = WeatherSettings(minimum_prediction_confidence=0.2)
    predictor = ReappearancePredictor(solar_service, settings)
    site = SiteConfig(latitude=30.25, longitude=120.15, timezone="Asia/Shanghai")
    now = datetime(2026, 6, 21, 12, 0, tzinfo=timezone(timedelta(hours=8)))
    solar = solar_service.calculate(site, now)
    current = _sample(now, cloud=90, dni=20, fetched=now)
    future = _sample(now + timedelta(hours=1), cloud=20, dni=500, fetched=now)
    weather = WeatherState(
        valid=True,
        selected=current,
        hourly=(current, future),
        source="forecast",
        source_fetched_at=now,
    )
    thermal = ThermalGuidance.invalid("camera_unavailable", captured_at=now, now=now)

    result = predictor.predict(
        site=site,
        now=now,
        solar=solar,
        weather=weather,
        thermal=thermal,
    )

    assert result.valid is True
    assert result.best_estimate == future.valid_time
    assert result.estimated_from < result.best_estimate < result.estimated_to
    assert result.predicted_altitude is not None
    assert result.predicted_azimuth is not None
    assert result.confidence >= 0.2
    assert result.evidence


def test_predictor_skips_clear_weather_sample_outside_solar_daylight() -> None:
    mechanics = MechanicalLimits(
        configured=True,
        azimuth_min=0,
        azimuth_max=360,
        elevation_min=0,
        elevation_max=90,
    )
    solar_service = SolarPositionService(mechanics)
    settings = WeatherSettings(minimum_prediction_confidence=0.2)
    predictor = ReappearancePredictor(solar_service, settings)
    site = SiteConfig(latitude=30.25, longitude=120.15, timezone="Asia/Shanghai")
    selected_time = datetime(
        2026, 6, 21, 12, 0, tzinfo=timezone(timedelta(hours=8))
    )
    fetched = selected_time
    current = _sample(selected_time, cloud=90, dni=20, fetched=fetched)
    weather_night = _sample(
        selected_time.replace(hour=23), cloud=20, dni=500, fetched=fetched
    )
    next_daylight = _sample(
        (selected_time + timedelta(days=1)).replace(hour=8),
        cloud=20,
        dni=500,
        fetched=fetched,
    )
    weather = WeatherState(
        valid=True,
        selected=current,
        hourly=(current, weather_night, next_daylight),
        source="archive",
        source_fetched_at=fetched,
    )

    result = predictor.predict(
        site=site,
        now=selected_time,
        solar=solar_service.calculate(site, selected_time),
        weather=weather,
        thermal=ThermalGuidance.invalid("camera_unavailable", now=selected_time),
    )

    assert result.valid is True
    assert result.best_estimate == next_daylight.valid_time


def test_historical_override_does_not_use_weather_after_real_fetch_time() -> None:
    mechanics = MechanicalLimits(
        configured=True,
        azimuth_min=0,
        azimuth_max=360,
        elevation_min=0,
        elevation_max=90,
    )
    solar_service = SolarPositionService(mechanics)
    settings = WeatherSettings(minimum_prediction_confidence=0.2)
    predictor = ReappearancePredictor(solar_service, settings)
    selected_time = datetime(
        2026, 6, 21, 12, 0, tzinfo=timezone(timedelta(hours=8))
    )
    fetched_at = selected_time + timedelta(days=1)
    site = SiteConfig(
        latitude=30.25,
        longitude=120.15,
        timezone="Asia/Shanghai",
        calculation_time_override=selected_time,
    )
    current = _sample(selected_time, cloud=90, dni=20, fetched=fetched_at)
    not_yet_observed = _sample(
        fetched_at + timedelta(hours=2),
        cloud=20,
        dni=500,
        fetched=fetched_at,
    )
    weather = WeatherState(
        valid=True,
        selected=current,
        hourly=(current, not_yet_observed),
        source="forecast",
        source_fetched_at=fetched_at,
    )

    result = predictor.predict(
        site=site,
        now=selected_time,
        solar=solar_service.calculate(site, selected_time),
        weather=weather,
        thermal=ThermalGuidance.invalid("camera_unavailable", now=selected_time),
    )

    assert result.valid is False
    assert result.invalid_reason == "no_reappearance_candidate_in_weather_window"


def test_predictor_at_night_finds_next_daylight_candidate() -> None:
    mechanics = MechanicalLimits(
        configured=True,
        azimuth_min=0,
        azimuth_max=360,
        elevation_min=0,
        elevation_max=90,
    )
    solar_service = SolarPositionService(mechanics)
    predictor = ReappearancePredictor(solar_service, WeatherSettings())
    site = SiteConfig()
    at_night = datetime(2026, 6, 21, 0, 0, tzinfo=timezone(timedelta(hours=8)))
    solar = solar_service.calculate(site, at_night)

    current = _sample(at_night, cloud=90, dni=0, fetched=at_night).model_copy(
        update={"is_day": False}
    )
    future = _sample(
        at_night + timedelta(hours=8),
        cloud=20,
        dni=500,
        fetched=at_night,
    )
    result = predictor.predict(
        site=site,
        now=at_night,
        solar=solar,
        weather=WeatherState(
            valid=True,
            selected=current,
            hourly=(current, future),
            source="forecast",
            source_fetched_at=at_night,
        ),
        thermal=ThermalGuidance.invalid("camera_unavailable", now=at_night),
    )

    assert result.valid is True
    assert result.best_estimate == future.valid_time
    assert result.current_obstruction == "night"
    assert "solar_below_horizon" in result.evidence


def test_historical_prediction_never_uses_live_camera_as_evidence() -> None:
    mechanics = MechanicalLimits(
        configured=True,
        azimuth_min=0,
        azimuth_max=360,
        elevation_min=0,
        elevation_max=90,
    )
    solar_service = SolarPositionService(mechanics)
    predictor = ReappearancePredictor(
        solar_service,
        WeatherSettings(minimum_prediction_confidence=0.2),
    )
    selected_time = datetime(
        2020, 6, 21, 12, 0, tzinfo=timezone(timedelta(hours=8))
    )
    site = SiteConfig(
        latitude=30.25,
        longitude=120.15,
        timezone="Asia/Shanghai",
        calculation_time_override=selected_time,
    )
    current = _sample(selected_time, cloud=90, dni=20, fetched=selected_time)
    future = _sample(
        selected_time + timedelta(hours=1),
        cloud=20,
        dni=500,
        fetched=selected_time,
    )
    live_camera = ThermalGuidance(
        frame_id=99,
        captured_at=datetime.now(timezone.utc),
        processed_at=datetime.now(timezone.utc),
        valid=True,
        hotspot_valid=True,
        confidence=1.0,
        stale=False,
        invalid_reason=None,
    )

    result = predictor.predict(
        site=site,
        now=selected_time,
        solar=solar_service.calculate(site, selected_time),
        weather=WeatherState(
            valid=True,
            selected=current,
            hourly=(current, future),
            source="archive",
            source_fetched_at=selected_time,
        ),
        thermal=live_camera,
    )

    assert result.valid is True
    assert "camera_unavailable_weather_only" in result.evidence
    assert "camera_hotspot_visible" not in result.evidence


@pytest.mark.asyncio
async def test_weather_history_splits_archive_and_forecast_and_reuses_cache(
) -> None:
    clock = MutableClock(datetime(2026, 8, 11, 12, 0, tzinfo=timezone.utc))
    client = HistoryClient()
    service = WeatherService(
        client,
        WeatherSettings(cache_ttl_seconds=60.0),
        clock=clock,
    )
    site = SiteConfig(latitude=30.25, longitude=120.15, timezone="UTC")
    as_of = datetime(2026, 8, 11, 14, 30, tzinfo=timezone.utc)

    first = await service.get_history(site, as_of, days=3)
    second = await service.get_history(site, as_of, days=3)

    assert len(client.requests) == 2
    assert {
        (request["source"], request["start_date"], request["end_date"])
        for request in client.requests
    } == {
        ("archive", date(2026, 8, 9), date(2026, 8, 9)),
        ("forecast", date(2026, 8, 10), date(2026, 8, 11)),
    }
    assert first.source == "mixed"
    assert first.data_kind == "mixed"
    assert first.partial is False
    assert first.error is None
    assert len(first.points) == 3
    assert [point.source for point in first.points] == [
        "open_meteo_archive",
        "open_meteo_forecast",
        "open_meteo_forecast",
    ]
    assert [point.temperature_2m for point in first.points] == pytest.approx(
        [23.5, 24.5, 25.5]
    )
    assert first.points[-1].valid_time == as_of
    assert first.points[-1].valid_time <= first.as_of
    assert second == first.model_copy(update={"generated_at": second.generated_at})


@pytest.mark.asyncio
async def test_weather_history_marks_a_failed_segment_partial_without_fabrication(
) -> None:
    clock = MutableClock(datetime(2026, 8, 11, 12, 0, tzinfo=timezone.utc))
    service = WeatherService(
        HistoryClient(fail_sources={"archive"}),
        WeatherSettings(),
        clock=clock,
    )

    result = await service.get_history(
        SiteConfig(latitude=0, longitude=0, timezone="UTC"),
        datetime(2026, 8, 11, 14, 30, tzinfo=timezone.utc),
        days=3,
    )

    assert result.partial is True
    assert result.error is not None
    assert "archive_unavailable:TimeoutError" in result.error
    assert "weather_history_incomplete" in result.error
    assert result.points[0].source == "none"
    assert result.points[0].temperature_2m is None
    assert result.points[1].source == "open_meteo_forecast"
    assert result.source == "open_meteo_forecast"
    assert result.data_kind == "forecast"


@pytest.mark.asyncio
async def test_weather_history_preserves_available_metrics_when_one_is_missing(
) -> None:
    clock = MutableClock(datetime(2026, 8, 11, 12, 0, tzinfo=timezone.utc))
    service = WeatherService(
        MissingTemperatureHistoryClient(),
        WeatherSettings(),
        clock=clock,
    )

    result = await service.get_history(
        SiteConfig(latitude=0, longitude=0, timezone="UTC"),
        datetime(2026, 7, 1, 14, 30, tzinfo=timezone.utc),
        days=1,
    )

    assert result.partial is True
    assert result.error == "weather_history_incomplete"
    assert result.points[0].temperature_2m is None
    assert result.points[0].cloud_cover == pytest.approx(14.5)
    assert result.points[0].wind_speed == pytest.approx(14.5)
    assert result.points[0].source == "open_meteo_archive"


@pytest.mark.asyncio
async def test_weather_history_resolves_nonexistent_dst_wall_time_forward() -> None:
    zone = ZoneInfo("America/New_York")
    clock = MutableClock(datetime(2026, 3, 10, 16, 0, tzinfo=timezone.utc))
    service = WeatherService(
        HistoryClient(),
        WeatherSettings(),
        clock=clock,
    )
    as_of = datetime(2026, 3, 10, 2, 30, tzinfo=zone)

    result = await service.get_history(
        SiteConfig(latitude=40.7, longitude=-74.0, timezone=zone.key),
        as_of,
        days=3,
    )

    assert len(result.points) == 3
    spring_forward_point = result.points[0].valid_time.astimezone(zone)
    assert spring_forward_point.date() == date(2026, 3, 8)
    assert (spring_forward_point.hour, spring_forward_point.minute) == (3, 30)
    assert all(point.valid_time <= result.as_of for point in result.points)
