from __future__ import annotations

import asyncio
import io
import json
from datetime import datetime, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from PIL import Image

from app.config import AppSettings
from app.domain.thermal import ThermalGuidance
from app.infrastructure.frame_store import FrameRecord, FrameStore
from app.main import create_app
from app.presentation.media_stream import mjpeg_generator


def _jpeg(color: tuple[int, int, int]) -> bytes:
    output = io.BytesIO()
    Image.new("RGB", (20, 20), color=color).save(output, format="JPEG")
    return output.getvalue()


def test_openapi_contains_all_versioned_and_media_endpoints(
    commissioned_settings, fake_weather_client
) -> None:
    app = create_app(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    paths = app.openapi()["paths"]
    assert {
        "/api/v1/state",
        "/api/v1/weather/history",
        "/api/v1/mode",
        "/api/v1/manual-jog",
        "/api/v1/site-config",
        "/api/v1/reappearance",
        "/api/v1/thermal/metadata",
        "/api/v1/health",
        "/media/thermal/original.mjpeg",
        "/media/thermal/annotated.mjpeg",
    }.issubset(paths)


def test_weather_history_uses_runtime_site_and_selected_cutoff(
    commissioned_settings, fake_weather_client
) -> None:
    app = create_app(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    with TestClient(app) as client:
        response = client.get(
            "/api/v1/weather/history",
            params={
                "as_of": "2026-06-21T12:30:00+08:00",
                "days": 3,
            },
        )

    assert response.status_code == 200
    body = response.json()
    assert body["latitude"] == commissioned_settings.default_site.latitude
    assert body["longitude"] == commissioned_settings.default_site.longitude
    assert body["timezone"] == commissioned_settings.default_site.timezone
    assert body["as_of"] == "2026-06-21T12:30:00+08:00"
    assert body["days"] == 3
    assert body["source"] == "open_meteo_archive"
    assert body["data_kind"] == "model_reanalysis"
    assert body["partial"] is False
    assert body["error"] is None
    assert len(body["points"]) == 3
    assert body["points"][-1]["valid_time"] == body["as_of"]
    assert body["points"][-1]["temperature_2m"] == 21.5
    assert body["units"] == {
        "temperature_2m": "°C",
        "cloud_cover": "%",
        "wind_speed": "km/h",
    }


def test_weather_history_rejects_naive_cutoff_and_out_of_range_days(
    commissioned_settings, fake_weather_client
) -> None:
    app = create_app(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    with TestClient(app) as client:
        naive = client.get(
            "/api/v1/weather/history",
            params={"as_of": "2026-06-21T12:30:00", "days": 10},
        )
        too_many = client.get(
            "/api/v1/weather/history",
            params={
                "as_of": "2026-06-21T12:30:00+08:00",
                "days": 32,
            },
        )

    assert naive.status_code == 422
    assert too_many.status_code == 422


def test_rest_state_commands_site_persistence_and_audit(
    commissioned_settings, fake_weather_client
) -> None:
    app = create_app(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    with TestClient(app) as client:
        state = client.get("/api/v1/state")
        assert state.status_code == 200
        body = state.json()
        assert body["sequence"] >= 1
        assert body["simulation"]["active"] is True
        assert body["simulation"]["production_fallback_allowed"] is False
        assert body["plc"]["online"] is True
        assert any(
            alarm["code"] == "CONTROL_INHIBITED_BY_TIME_PREVIEW"
            for alarm in body["alarms"]
        )

        preview_blocked = client.post(
            "/api/v1/manual-jog",
            json={
                "direction": "az_right",
                "step_degrees": 1.0,
                "operator": "tester",
                "session_id": "session",
            },
        )
        assert preview_blocked.status_code == 409
        assert "preview override" in preview_blocked.json()["reason"]

        utc_time = datetime.now(timezone.utc)
        utc_hours = utc_time.hour + utc_time.minute / 60.0
        solar_noon_longitude = (12.0 - utc_hours) * 15.0
        if solar_noon_longitude > 180.0:
            solar_noon_longitude -= 360.0
        if solar_noon_longitude < -180.0:
            solar_noon_longitude += 360.0

        update = client.put(
            "/api/v1/site-config",
            json={
                "latitude": 31.2,
                "longitude": solar_noon_longitude,
                "timezone": "UTC",
                "calculation_time_override": None,
                "operator": "tester",
                "session_id": "session",
            },
        )
        assert update.status_code == 200
        assert update.json()["config"]["latitude"] == 31.2

        command_id = "6d770d47-2b9f-4c4b-855a-4057fb9c7730"
        jog_payload = {
            "command_id": command_id,
            "direction": "az_right",
            "step_degrees": 1.0,
            "operator": "tester",
            "session_id": "session",
        }
        first = client.post("/api/v1/manual-jog", json=jog_payload)
        duplicate = client.post("/api/v1/manual-jog", json=jog_payload)
        assert first.status_code == 202
        assert first.json()["accepted"] is True
        assert duplicate.status_code == 202
        assert duplicate.json()["duplicate"] is True

        solar_mode = client.post(
            "/api/v1/mode",
            json={
                "mode": "solar",
                "operator": "tester",
                "session_id": "session",
            },
        )
        assert solar_mode.status_code == 202
        assert solar_mode.json()["confirmed_mode"] == "solar"
        rejected_jog = client.post(
            "/api/v1/manual-jog",
            json={
                "direction": "az_left",
                "step_degrees": 1.0,
                "operator": "tester",
                "session_id": "session",
            },
        )
        assert rejected_jog.status_code == 409
        assert "not manual" in rejected_jog.json()["reason"]

        blocked_update = client.put(
            "/api/v1/site-config",
            json={
                "latitude": 32.0,
                "longitude": 121.5,
                "timezone": "Asia/Shanghai",
                "calculation_time_override": "2026-06-21T12:00:00+08:00",
                "operator": "tester",
                "session_id": "session",
            },
        )
        assert blocked_update.status_code == 409
        assert "confirmed manual" in blocked_update.json()["detail"]
        assert commissioned_settings.site_config_path.exists()
        assert commissioned_settings.audit_log_path.exists()
        audit = json.loads(
            commissioned_settings.audit_log_path.read_text(encoding="utf-8")
        )
        assert audit["old"]["latitude"] == 30.25
        assert audit["new"]["latitude"] == 31.2


def test_websocket_pushes_typed_system_snapshot(
    commissioned_settings, fake_weather_client
) -> None:
    app = create_app(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    with TestClient(app) as client:
        with client.websocket_connect("/ws/v1/system") as websocket:
            payload = websocket.receive_json()
            assert payload["sequence"] >= 1
            assert payload["confirmed_mode"] == "manual"
            assert "generated_at" in payload
            assert "thermal" in payload


def test_media_is_denied_by_safe_default(tmp_path: Path, fake_weather_client) -> None:
    settings = AppSettings(
        environment="test",
        site_config_path=tmp_path / "site.json",
        audit_log_path=tmp_path / "audit.jsonl",
    )
    app = create_app(
        settings=settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    with TestClient(app) as client:
        response = client.get("/media/thermal/original.mjpeg")
        assert response.status_code == 403
        assert "safe default" in response.json()["detail"]


@pytest.mark.asyncio
async def test_mjpeg_uses_same_frame_and_marks_status_frames() -> None:
    store = FrameStore()
    now = datetime.now(timezone.utc)
    guidance = ThermalGuidance.invalid(
        "test", frame_id=1, captured_at=now, now=now, stale=False
    )
    raw = _jpeg((10, 20, 30))
    annotated = _jpeg((40, 50, 60))
    store.publish(
        FrameRecord(
            frame_id=1,
            captured_at=now,
            raw_jpeg=raw,
            annotated_jpeg=annotated,
            guidance=guidance,
        )
    )
    stream = mjpeg_generator(
        store,
        annotated=True,
        camera_status=lambda: "online",
        stale_after_seconds=0.1,
    )
    first = await anext(stream)
    assert annotated in first
    assert b"X-Frame-Id: 1" in first
    assert b"X-Status-Frame: false" in first
    second = await asyncio.wait_for(anext(stream), timeout=1.0)
    assert b"X-Status-Frame: true" in second
    await stream.aclose()


def test_invalid_site_form_and_manual_bound_return_422(
    commissioned_settings, fake_weather_client
) -> None:
    app = create_app(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    with TestClient(app) as client:
        invalid_site = client.put(
            "/api/v1/site-config",
            json={
                "latitude": 95,
                "longitude": 0,
                "timezone": "UTC",
                "operator": "tester",
                "session_id": "session",
            },
        )
        invalid_jog = client.post(
            "/api/v1/manual-jog",
            json={
                "direction": "az_left",
                "step_degrees": 1,
                "max_duration_seconds": 1,
            },
        )
        assert invalid_site.status_code == 422
        assert invalid_jog.status_code == 422
