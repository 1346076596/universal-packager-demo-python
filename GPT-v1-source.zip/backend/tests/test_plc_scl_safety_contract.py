from __future__ import annotations

import re
from pathlib import Path

from app.domain.telemetry import PLC_DATA_VERSION

ROOT = Path(__file__).resolve().parents[2]
CONTROLLER = (ROOT / "plc" / "scl" / "SolarTracker_V15.scl").read_text(
    encoding="utf-8"
)
MAIN = (ROOT / "plc" / "scl" / "SolarTracker_Main_V15.scl").read_text(
    encoding="utf-8"
)


def _count_statement(name: str) -> int:
    return len(re.findall(rf"(?m)^\s*{re.escape(name)}\b", CONTROLLER))


def test_scl_structural_delimiters_are_balanced() -> None:
    assert _count_statement("TYPE") == _count_statement("END_TYPE")
    assert _count_statement("FUNCTION_BLOCK") == _count_statement(
        "END_FUNCTION_BLOCK"
    )
    assert _count_statement("DATA_BLOCK") == _count_statement("END_DATA_BLOCK")
    assert _count_statement("IF") == _count_statement("END_IF")
    assert CONTROLLER.count("(*") == CONTROLLER.count("*)")


def test_plc_contract_version_matches_python() -> None:
    assert f"#Status.DataVersion := {PLC_DATA_VERSION};" in CONTROLLER
    assert f"#LatchedCommand.DataVersion <> {PLC_DATA_VERSION}" in CONTROLLER
    assert f"Command.DataVersion := {PLC_DATA_VERSION};" in CONTROLLER


def test_command_sequence_remains_the_only_atomic_commit_marker() -> None:
    latch_section = CONTROLLER.split("#CommandPacketChanged := FALSE;", 1)[1].split(
        "#FaultResetPulse", 1
    )[0]
    assert (
        "AND (#Command.CommandSequence <> #LatchedCommand.CommandSequence)) THEN"
        in latch_section
    )
    assert (
        "OR (#Command.SessionEpoch <> #LatchedCommand.SessionEpoch)"
        not in latch_section
    )
    assert "#Command.SessionEpoch <> #LatchedCommand.SessionEpoch" in CONTROLLER
    assert "#OneShotBaselinePacket := TRUE;" in CONTROLLER
    assert "#ConfirmedModeMemory := #MODE_MANUAL;" in CONTROLLER


def test_command_status_field_and_retain_domains_are_isolated() -> None:
    for block in (
        "DB_ST_Command",
        "DB_ST_Status",
        "DB_ST_FieldIO",
        "DB_ST_Config",
        "DB_ST_FaultMemory",
    ):
        assert f'DATA_BLOCK "{block}"' in CONTROLLER
    assert "DB_ST_CommandStatus" not in CONTROLLER
    assert CONTROLLER.count("VAR RETAIN") == 2
    assert "AckCommandSessionEpoch" in CONTROLLER
    assert "AckManualSessionEpoch" in CONTROLLER


def test_ob1_has_no_uncommissioned_absolute_output_mapping() -> None:
    assert "%Q" not in CONTROLLER
    assert "%Q" not in MAIN
    assert 'Command := "DB_ST_Command".Command' in MAIN
    assert 'Status => "DB_ST_Status".Status' in MAIN
    assert 'FieldIO := "DB_ST_FieldIO".FieldIO' in MAIN
    assert 'RetainedFaultLatched := "DB_ST_FaultMemory".FaultLatched' in MAIN
