from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import uuid4

import pytest

from app.application.mode_service import ModeService
from app.domain.commands import (
    CommandStatus,
    ManualDirection,
    ManualJogRequest,
    ModeChangeRequest,
    SolarTargetCommand,
)
from app.domain.common import ControlMode
from app.domain.settings import SiteConfig
from app.domain.telemetry import AxisMotion, CommandAcknowledgement
from app.infrastructure.plc_gateway import DevelopmentSimulatedPlcGateway
from app.services.solar_position import SolarPositionService


@pytest.mark.asyncio
async def test_simulator_requires_python_solar_direction_to_match_local_error(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    initial = await gateway.read_telemetry()
    await gateway.request_mode(ModeChangeRequest(mode=ControlMode.SOLAR))

    assert initial.azimuth.actual_angle is not None
    assert initial.elevation.actual_angle is not None
    await gateway.send_solar_target(
        SolarTargetCommand(
            valid=True,
            target_azimuth=initial.azimuth.actual_angle + 10.0,
            target_altitude=initial.elevation.actual_angle + 5.0,
            azimuth_error=10.0,
            elevation_error=5.0,
            azimuth_direction=AxisMotion.NEGATIVE,
            elevation_direction=AxisMotion.POSITIVE,
            feedback_sampled_at=initial.sampled_at,
            feedback_fresh=True,
        )
    )
    mismatched = await gateway.read_telemetry()

    assert mismatched.azimuth.actual_angle == initial.azimuth.actual_angle
    assert mismatched.elevation.actual_angle > initial.elevation.actual_angle

    await gateway.send_solar_target(
        SolarTargetCommand(
            valid=True,
            target_azimuth=initial.azimuth.actual_angle + 10.0,
            target_altitude=initial.elevation.actual_angle + 5.0,
            azimuth_error=10.0,
            elevation_error=5.0,
            azimuth_direction=AxisMotion.POSITIVE,
            elevation_direction=AxisMotion.POSITIVE,
            feedback_sampled_at=mismatched.sampled_at,
            feedback_fresh=True,
        )
    )
    matched = await gateway.read_telemetry()

    assert matched.azimuth.actual_angle > mismatched.azimuth.actual_angle


@pytest.mark.asyncio
async def test_manual_jog_is_bounded_and_idempotent(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    telemetry = await gateway.read_telemetry()
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        SiteConfig(),
        datetime(2026, 6, 21, 12, 0, tzinfo=timezone(timedelta(hours=8))),
    )
    service = ModeService(gateway, commissioned_settings)
    command = ManualJogRequest(
        direction=ManualDirection.AZ_RIGHT,
        step_degrees=1.0,
    )

    first = await service.manual_jog(command, telemetry=telemetry, solar=solar)
    after_first = await gateway.read_telemetry()
    duplicate = await service.manual_jog(command, telemetry=after_first, solar=solar)
    after_duplicate = await gateway.read_telemetry()

    assert first.accepted is True
    assert first.status is CommandStatus.CONFIRMED
    assert duplicate.duplicate is True
    assert after_duplicate.azimuth.actual_angle == after_first.azimuth.actual_angle


@pytest.mark.asyncio
async def test_command_id_is_bound_to_action_and_payload(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    telemetry = await gateway.read_telemetry()
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        commissioned_settings.default_site,
        commissioned_settings.default_site.calculation_time_override,
    )
    service = ModeService(gateway, commissioned_settings)
    command_id = uuid4()
    original = ManualJogRequest(
        command_id=command_id,
        direction=ManualDirection.AZ_RIGHT,
        step_degrees=1.0,
    )

    accepted = await service.manual_jog(
        original,
        telemetry=telemetry,
        solar=solar,
    )
    changed_payload = await service.manual_jog(
        original.model_copy(update={"direction": ManualDirection.AZ_LEFT}),
        telemetry=telemetry,
        solar=solar,
    )
    changed_action = await service.request_mode(
        ModeChangeRequest(command_id=command_id, mode=ControlMode.SOLAR),
        telemetry=telemetry,
        camera_online=True,
    )

    assert accepted.accepted is True
    assert changed_payload.accepted is False
    assert changed_payload.reason == (
        "command_id was reused with a different action or payload"
    )
    assert changed_action.accepted is False
    assert changed_action.reason == (
        "command_id was reused with a different action or payload"
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("axis_name", "feedback_field", "feedback_value", "expected_reason"),
    [
        ("azimuth", "moving", True, "an axis is already moving"),
        ("elevation", "moving", True, "an axis is already moving"),
        (
            "azimuth",
            "fault",
            True,
            "axis feedback reports a fault or motion timeout",
        ),
        (
            "elevation",
            "fault",
            True,
            "axis feedback reports a fault or motion timeout",
        ),
        (
            "azimuth",
            "timed_out",
            True,
            "axis feedback reports a fault or motion timeout",
        ),
        (
            "elevation",
            "timed_out",
            True,
            "axis feedback reports a fault or motion timeout",
        ),
        (
            "azimuth",
            "motion_stopped",
            False,
            "physical stopped feedback is not confirmed",
        ),
        (
            "elevation",
            "motion_stopped",
            False,
            "physical stopped feedback is not confirmed",
        ),
    ],
)
async def test_manual_jog_rejects_active_or_faulted_axis_feedback(
    commissioned_settings,
    axis_name: str,
    feedback_field: str,
    feedback_value: bool,
    expected_reason: str,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    telemetry = await gateway.read_telemetry()
    axis = getattr(telemetry, axis_name).model_copy(
        update={feedback_field: feedback_value}
    )
    blocked_telemetry = telemetry.model_copy(update={axis_name: axis})
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        commissioned_settings.default_site,
        commissioned_settings.default_site.calculation_time_override,
    )
    service = ModeService(gateway, commissioned_settings)

    receipt = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.AZ_RIGHT,
            step_degrees=1.0,
        ),
        telemetry=blocked_telemetry,
        solar=solar,
    )

    assert receipt.accepted is False
    assert receipt.reason == expected_reason


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("terminal_accepted", "terminal_completed", "terminal_result"),
    [
        (True, True, "confirmed"),
        (False, False, "rejected"),
    ],
)
async def test_pending_manual_jog_is_released_only_by_matching_terminal_ack(
    commissioned_settings,
    monkeypatch: pytest.MonkeyPatch,
    terminal_accepted: bool,
    terminal_completed: bool,
    terminal_result: str,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    telemetry = await gateway.read_telemetry()
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        commissioned_settings.default_site,
        commissioned_settings.default_site.calculation_time_override,
    )
    service = ModeService(gateway, commissioned_settings)
    gateway_calls: list[ManualJogRequest] = []

    async def accept_without_completion(
        command: ManualJogRequest,
    ) -> CommandAcknowledgement:
        gateway_calls.append(command)
        return CommandAcknowledgement(
            command_id=command.command_id,
            accepted=True,
            completed=False,
            result="accepted",
        )

    monkeypatch.setattr(gateway, "manual_jog", accept_without_completion)
    pending_command = ManualJogRequest(
        direction=ManualDirection.AZ_RIGHT,
        step_degrees=1.0,
    )

    pending = await service.manual_jog(
        pending_command,
        telemetry=telemetry,
        solar=solar,
    )
    service.observe_telemetry(
        telemetry.model_copy(
            update={
                "last_ack": CommandAcknowledgement(
                    command_id=pending_command.command_id,
                    accepted=True,
                    completed=False,
                    result="accepted",
                )
            }
        )
    )
    blocked_by_non_terminal = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.AZ_LEFT,
            step_degrees=1.0,
        ),
        telemetry=telemetry,
        solar=solar,
    )
    service.observe_telemetry(
        telemetry.model_copy(
            update={
                "last_ack": CommandAcknowledgement(
                    command_id=uuid4(),
                    accepted=True,
                    completed=True,
                    result="confirmed",
                )
            }
        )
    )
    blocked_by_unrelated = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.ALT_UP,
            step_degrees=1.0,
        ),
        telemetry=telemetry,
        solar=solar,
    )
    service.observe_telemetry(
        telemetry.model_copy(
            update={
                "last_ack": CommandAcknowledgement(
                    command_id=pending_command.command_id,
                    accepted=terminal_accepted,
                    completed=terminal_completed,
                    result=terminal_result,
                    reason=(
                        None if terminal_accepted else "synthetic rejection"
                    ),
                )
            }
        )
    )
    accepted_after_terminal = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.ALT_DOWN,
            step_degrees=1.0,
        ),
        telemetry=telemetry,
        solar=solar,
    )

    assert pending.accepted is True
    assert pending.status is CommandStatus.ACCEPTED
    assert blocked_by_non_terminal.accepted is False
    assert blocked_by_non_terminal.reason == "previous manual command is still pending"
    assert blocked_by_unrelated.accepted is False
    assert blocked_by_unrelated.reason == "previous manual command is still pending"
    assert accepted_after_terminal.accepted is True
    assert len(gateway_calls) == 2


@pytest.mark.asyncio
async def test_non_manual_mode_rejects_jog(commissioned_settings) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    service = ModeService(gateway, commissioned_settings)
    telemetry = await gateway.read_telemetry()
    mode_receipt = await service.request_mode(
        ModeChangeRequest(mode=ControlMode.SOLAR),
        telemetry=telemetry,
        camera_online=True,
    )
    assert mode_receipt.accepted is True
    telemetry = await gateway.read_telemetry()
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        commissioned_settings.default_site,
        commissioned_settings.default_site.calculation_time_override,
    )

    receipt = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.AZ_LEFT,
            step_degrees=1.0,
        ),
        telemetry=telemetry,
        solar=solar,
    )

    assert receipt.accepted is False
    assert receipt.reason == "PLC confirmed mode is not manual"


@pytest.mark.asyncio
async def test_expired_command_and_limit_direction_are_rejected(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    service = ModeService(gateway, commissioned_settings)
    telemetry = await gateway.read_telemetry()
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        commissioned_settings.default_site,
        commissioned_settings.default_site.calculation_time_override,
    )
    expired = ManualJogRequest(
        direction=ManualDirection.AZ_LEFT,
        step_degrees=1.0,
        issued_at=datetime.now(timezone.utc) - timedelta(seconds=30),
    )
    receipt = await service.manual_jog(expired, telemetry=telemetry, solar=solar)
    assert receipt.accepted is False
    assert receipt.reason == "command expired before execution"

    # Move repeatedly to the commissioned negative limit using unique commands.
    for _ in range(100):
        await gateway.manual_jog(
            ManualJogRequest(
                command_id=uuid4(),
                direction=ManualDirection.AZ_LEFT,
                step_degrees=2.0,
            )
        )
    telemetry = await gateway.read_telemetry()
    assert telemetry.azimuth.negative_limit is True
    blocked = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.AZ_LEFT,
            step_degrees=1.0,
        ),
        telemetry=telemetry,
        solar=solar,
    )
    assert blocked.accepted is False
    assert "limit" in (blocked.reason or "")


@pytest.mark.asyncio
async def test_thermal_mode_requires_camera_and_hardware_approval(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    service = ModeService(gateway, commissioned_settings)
    telemetry = await gateway.read_telemetry()

    result = await service.request_mode(
        ModeChangeRequest(mode=ControlMode.THERMAL),
        telemetry=telemetry,
        camera_online=False,
    )

    assert result.accepted is False
    assert result.reason == "thermal camera is offline"


@pytest.mark.asyncio
async def test_preview_override_and_stale_plc_feedback_block_control(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    service = ModeService(gateway, commissioned_settings)
    telemetry = await gateway.read_telemetry()
    solar = SolarPositionService(commissioned_settings.mechanics).calculate(
        commissioned_settings.default_site,
        commissioned_settings.default_site.calculation_time_override,
    )

    preview_blocked = await service.manual_jog(
        ManualJogRequest(
            direction=ManualDirection.AZ_RIGHT,
            step_degrees=1.0,
        ),
        telemetry=telemetry,
        solar=solar,
        control_time_valid=False,
    )
    assert preview_blocked.accepted is False
    assert "preview override" in (preview_blocked.reason or "")

    stale = telemetry.model_copy(
        update={"sampled_at": datetime.now(timezone.utc) - timedelta(seconds=5)}
    )
    stale_blocked = await service.request_mode(
        ModeChangeRequest(mode=ControlMode.SOLAR),
        telemetry=stale,
        camera_online=True,
    )
    assert stale_blocked.accepted is False
    assert stale_blocked.reason == "PLC telemetry is stale"

    mismatched = telemetry.model_copy(update={"data_version": 1})
    version_blocked = await service.request_mode(
        ModeChangeRequest(mode=ControlMode.SOLAR),
        telemetry=mismatched,
        camera_online=True,
    )
    assert version_blocked.accepted is False
    assert "contract mismatch" in (version_blocked.reason or "")


@pytest.mark.asyncio
async def test_preview_override_inhibits_simulated_night_parking(
    commissioned_settings,
) -> None:
    gateway = DevelopmentSimulatedPlcGateway(commissioned_settings.mechanics)
    await gateway.start()
    before = await gateway.read_telemetry()

    await gateway.send_time_state(is_day=False, calculation_time_valid=False)
    after = await gateway.read_telemetry()

    assert after.azimuth.actual_angle == before.azimuth.actual_angle
    assert after.elevation.actual_angle == before.elevation.actual_angle
    assert after.azimuth.moving is False
    assert after.elevation.moving is False
