from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo

from app.config import MechanicalLimits
from app.domain.settings import SiteConfig
from app.services.solar_position import SolarPositionService


def test_summer_noon_position_and_sunrise_are_plausible() -> None:
    service = SolarPositionService(
        MechanicalLimits(
            configured=True,
            azimuth_min=0.0,
            azimuth_max=360.0,
            elevation_min=0.0,
            elevation_max=90.0,
        )
    )
    site = SiteConfig()
    local_noon = datetime(2026, 6, 21, 12, 0, tzinfo=ZoneInfo("Asia/Shanghai"))

    state = service.calculate(site, local_noon)

    assert 75.0 < state.altitude < 85.0
    assert 150.0 < state.azimuth < 220.0
    assert state.is_day is True
    assert state.target_valid is True
    assert state.sunrise is not None and 4 <= state.sunrise.hour <= 6
    assert state.sunset is not None and 18 <= state.sunset.hour <= 20


def test_night_never_produces_a_motion_target() -> None:
    service = SolarPositionService(
        MechanicalLimits(
            configured=True,
            azimuth_min=0.0,
            azimuth_max=360.0,
            elevation_min=0.0,
            elevation_max=90.0,
        )
    )
    site = SiteConfig()
    midnight = datetime(2026, 6, 21, 0, 0, tzinfo=ZoneInfo("Asia/Shanghai"))

    state = service.calculate(site, midnight)

    assert state.is_day is False
    assert state.target_valid is False
    assert state.target_invalid_reason == "night"


def test_uncommissioned_mechanics_allow_display_but_block_target() -> None:
    state = SolarPositionService(MechanicalLimits()).calculate(
        SiteConfig(),
        datetime(2026, 6, 21, 12, 0, tzinfo=ZoneInfo("Asia/Shanghai")),
    )
    assert state.is_day is True
    assert state.target_valid is False
    assert state.target_invalid_reason == "mechanical_range_not_commissioned"
