from __future__ import annotations

import asyncio
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from uuid import uuid4

import pytest

from app.application.system_orchestrator import SiteUpdateRejected
from app.domain.commands import (
    ManualJogRequest,
    ModeChangeRequest,
    SolarTargetCommand,
    ThermalControlCommand,
)
from app.domain.common import ControlMode, utc_now
from app.domain.settings import SiteConfigUpdate
from app.domain.telemetry import (
    AxisTelemetry,
    CommandAcknowledgement,
    PlcTelemetry,
    SafetyTelemetry,
)
from app.infrastructure.plc_gateway import PlcGateway
from app.main import build_runtime


@pytest.mark.asyncio
async def test_site_update_immediately_refreshes_historical_weather_and_snapshot(
    commissioned_settings, fake_weather_client
) -> None:
    runtime = build_runtime(
        settings=commissioned_settings,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    await runtime.start()
    try:
        previous_sequence = runtime.snapshot.sequence
        site = await runtime.update_site(
            SiteConfigUpdate(
                latitude=31.2,
                longitude=121.5,
                timezone="Asia/Shanghai",
                calculation_time_override=datetime(
                    2020,
                    6,
                    21,
                    12,
                    0,
                    tzinfo=timezone(timedelta(hours=8)),
                ),
                operator="tester",
                session_id="weather-refresh",
            )
        )

        assert fake_weather_client.calls == 1
        assert runtime.weather.valid is True
        assert runtime.weather.source == "archive"
        assert runtime.weather.error is None
        assert runtime.snapshot.sequence == previous_sequence + 2
        assert runtime.snapshot.site == site
        assert runtime.snapshot.weather == runtime.weather
        assert runtime.snapshot.weather.error != "refresh_pending_after_site_change"
    finally:
        await runtime.stop()


class BlockingWeatherClient:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []
        self.first_started = asyncio.Event()
        self.release_first = asyncio.Event()

    async def fetch_hourly(self, **kwargs):
        self.calls.append(kwargs)
        call_number = len(self.calls)
        if call_number == 1:
            self.first_started.set()
            await self.release_first.wait()

        start_date = kwargs["start_date"]
        end_date = kwargs["end_date"]
        start = datetime.combine(start_date, datetime.min.time())
        hours = int((end_date - start_date).days * 24) + 24
        times = [
            (start + timedelta(hours=index)).isoformat(timespec="minutes")
            for index in range(hours)
        ]
        count = len(times)
        weather_code = 63 if kwargs["longitude"] == 121.5 else 1
        return {
            "hourly": {
                "time": times,
                "weather_code": [weather_code] * count,
                "cloud_cover": [25.0] * count,
                "wind_speed_10m": [3.5] * count,
                "direct_normal_irradiance": [450.0] * count,
                "is_day": [1] * count,
            }
        }

    async def close(self) -> None:
        return None


class RecordingPlcGateway(PlcGateway):
    def __init__(self, telemetry: PlcTelemetry) -> None:
        self.telemetry = telemetry
        self.solar_commands: list[SolarTargetCommand] = []
        self.time_states: list[tuple[bool, bool]] = []

    async def read_telemetry(self) -> PlcTelemetry:
        self.telemetry = self.telemetry.model_copy(update={"sampled_at": utc_now()})
        return self.telemetry

    async def request_mode(
        self, command: ModeChangeRequest
    ) -> CommandAcknowledgement:
        self.telemetry = self.telemetry.model_copy(
            update={"confirmed_mode": command.mode}
        )
        return CommandAcknowledgement(
            command_id=command.command_id,
            accepted=True,
            completed=True,
            result="confirmed",
        )

    async def manual_jog(
        self, command: ManualJogRequest
    ) -> CommandAcknowledgement:
        return CommandAcknowledgement(
            command_id=command.command_id,
            accepted=True,
            completed=True,
            result="confirmed",
        )

    async def send_solar_target(self, command: SolarTargetCommand) -> None:
        self.solar_commands.append(command)

    async def send_thermal_guidance(self, command: ThermalControlCommand) -> None:
        return None

    async def send_time_state(
        self, *, is_day: bool, calculation_time_valid: bool
    ) -> None:
        self.time_states.append((is_day, calculation_time_valid))


class StaleRecordingPlcGateway(RecordingPlcGateway):
    async def read_telemetry(self) -> PlcTelemetry:
        return self.telemetry


def _safe_solar_telemetry() -> PlcTelemetry:
    return PlcTelemetry(
        online=True,
        heartbeat=10,
        confirmed_mode=ControlMode.SOLAR,
        azimuth=AxisTelemetry(
            actual_angle=350.0,
            position_valid=True,
            motion_stopped=True,
        ),
        elevation=AxisTelemetry(
            actual_angle=1.0,
            position_valid=True,
            motion_stopped=True,
        ),
        safety=SafetyTelemetry(
            safety_chain_ok=True,
            communication_fault=False,
            position_feedback_valid=True,
            fault_code=None,
        ),
    )


def _live_settings(commissioned_settings):
    now = utc_now()
    utc_hours = now.hour + now.minute / 60.0
    longitude = (12.0 - utc_hours) * 15.0
    if longitude > 180.0:
        longitude -= 360.0
    if longitude < -180.0:
        longitude += 360.0
    return replace(
        commissioned_settings,
        default_site=commissioned_settings.default_site.model_copy(
            update={
                "latitude": 0.0,
                "longitude": longitude,
                "timezone": "UTC",
                "calculation_time_override": None,
            }
        ),
    )


@pytest.mark.asyncio
async def test_startup_revokes_retained_solar_target_until_manual_rearm(
    commissioned_settings, fake_weather_client
) -> None:
    gateway = RecordingPlcGateway(_safe_solar_telemetry())
    runtime = build_runtime(
        settings=_live_settings(commissioned_settings),
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        assert runtime._automatic_rearm_required is True  # noqa: SLF001
        assert gateway.solar_commands[-1].valid is False
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_reused_mode_command_id_cannot_clear_solar_rearm(
    commissioned_settings, fake_weather_client
) -> None:
    gateway = RecordingPlcGateway(
        _safe_solar_telemetry().model_copy(
            update={"confirmed_mode": ControlMode.MANUAL}
        )
    )
    runtime = build_runtime(
        settings=_live_settings(commissioned_settings),
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )
    command_id = uuid4()

    await runtime.start()
    try:
        first = await runtime.request_mode(
            ModeChangeRequest(
                command_id=command_id,
                mode=ControlMode.MANUAL,
                operator="tester",
                session_id="id-binding",
            )
        )
        reused = await runtime.request_mode(
            ModeChangeRequest(
                command_id=command_id,
                mode=ControlMode.SOLAR,
                operator="tester",
                session_id="id-binding",
            )
        )

        assert first.accepted is True
        assert reused.accepted is False
        assert runtime._automatic_rearm_required is True  # noqa: SLF001
        assert gateway.telemetry.confirmed_mode is ControlMode.MANUAL
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_solar_target_is_revoked_on_plc_data_contract_mismatch(
    commissioned_settings, fake_weather_client
) -> None:
    gateway = RecordingPlcGateway(
        _safe_solar_telemetry().model_copy(
            update={"confirmed_mode": ControlMode.MANUAL}
        )
    )
    runtime = build_runtime(
        settings=_live_settings(commissioned_settings),
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        accepted = await runtime.request_mode(
            ModeChangeRequest(
                mode=ControlMode.SOLAR,
                operator="tester",
                session_id="data-version",
            )
        )
        assert accepted.accepted is True
        assert gateway.solar_commands[-1].valid is True

        gateway.telemetry = gateway.telemetry.model_copy(
            update={"data_version": 1, "heartbeat": 11}
        )
        await runtime.refresh_once()

        assert gateway.solar_commands[-1].valid is False
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_online_site_update_rejects_stale_plc_snapshot(
    commissioned_settings, fake_weather_client
) -> None:
    stale = _safe_solar_telemetry().model_copy(
        update={
            "confirmed_mode": ControlMode.MANUAL,
            "sampled_at": utc_now() - timedelta(hours=1),
        }
    )
    runtime = build_runtime(
        settings=_live_settings(commissioned_settings),
        plc_gateway=StaleRecordingPlcGateway(stale),
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        with pytest.raises(SiteUpdateRejected, match="fresh valid feedback"):
            await runtime.update_site(
                SiteConfigUpdate(
                    latitude=31.2,
                    longitude=121.5,
                    timezone="Asia/Shanghai",
                    calculation_time_override=None,
                    operator="tester",
                    session_id="stale-site-update",
                )
            )
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_live_solar_control_sends_python_deviation_and_direction(
    commissioned_settings, fake_weather_client
) -> None:
    now = utc_now()
    utc_hours = now.hour + now.minute / 60.0
    longitude = (12.0 - utc_hours) * 15.0
    if longitude > 180.0:
        longitude -= 360.0
    if longitude < -180.0:
        longitude += 360.0
    settings = replace(
        commissioned_settings,
        default_site=commissioned_settings.default_site.model_copy(
            update={
                "latitude": 0.0,
                "longitude": longitude,
                "timezone": "UTC",
                "calculation_time_override": None,
            }
        ),
    )
    gateway = RecordingPlcGateway(
        _safe_solar_telemetry().model_copy(
            update={"confirmed_mode": ControlMode.MANUAL}
        )
    )
    runtime = build_runtime(
        settings=settings,
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        assert gateway.solar_commands[-1].valid is False
        receipt = await runtime.request_mode(
            ModeChangeRequest(
                command_id=uuid4(),
                mode=ControlMode.SOLAR,
                operator="tester",
                session_id="live-solar-rearm",
            )
        )
        assert receipt.accepted is True
        command = gateway.solar_commands[-1]
        assert command.valid is True
        assert command.feedback_fresh is True
        assert command.target_azimuth is not None
        assert command.target_altitude is not None
        assert command.azimuth_error == pytest.approx(
            command.target_azimuth - 350.0
        )
        assert command.elevation_error == pytest.approx(
            command.target_altitude - 1.0
        )
        assert command.azimuth_direction.value == "negative"
        assert command.elevation_direction.value == "positive"
        assert gateway.time_states[-1][1] is True
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_historical_preview_explicitly_invalidates_solar_control(
    commissioned_settings, fake_weather_client
) -> None:
    gateway = RecordingPlcGateway(_safe_solar_telemetry())
    runtime = build_runtime(
        settings=commissioned_settings,
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        assert runtime.site.calculation_time_override is not None
        assert gateway.time_states[-1][1] is False
        assert gateway.solar_commands[-1].valid is False
        receipt = await runtime.request_mode(
            ModeChangeRequest(
                command_id=uuid4(),
                mode=ControlMode.SOLAR,
                operator="tester",
                session_id="preview-test",
            )
        )
        assert receipt.accepted is False
        assert "preview override" in (receipt.reason or "")
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_stalled_plc_heartbeat_marks_feedback_offline(
    commissioned_settings, fake_weather_client
) -> None:
    gateway = RecordingPlcGateway(_safe_solar_telemetry())
    runtime = build_runtime(
        settings=commissioned_settings,
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        runtime._last_plc_heartbeat_changed_at = utc_now() - timedelta(  # noqa: SLF001
            seconds=commissioned_settings.control.plc_heartbeat_max_stall_seconds
            + 1.0
        )
        runtime._record_plc_telemetry(  # noqa: SLF001
            gateway.telemetry.model_copy(update={"sampled_at": utc_now()})
        )
        assert runtime.plc.online is False
        assert runtime.plc.safety.communication_fault is True
        assert runtime.plc.safety.fault_code == "PLC_HEARTBEAT_STALE"
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_offline_site_change_requires_manual_stopped_rearm_before_solar(
    commissioned_settings, fake_weather_client
) -> None:
    settings = replace(
        commissioned_settings,
        default_site=commissioned_settings.default_site.model_copy(
            update={"calculation_time_override": None}
        ),
    )
    offline = _safe_solar_telemetry().model_copy(
        update={
            "online": False,
            "safety": SafetyTelemetry(
                safety_chain_ok=False,
                communication_fault=True,
                position_feedback_valid=True,
                fault_code="PLC_OFFLINE",
            ),
        }
    )
    gateway = RecordingPlcGateway(offline)
    runtime = build_runtime(
        settings=settings,
        plc_gateway=gateway,
        weather_client=fake_weather_client,
        start_background_tasks=False,
    )

    await runtime.start()
    try:
        await runtime.update_site(
            SiteConfigUpdate(
                latitude=31.2,
                longitude=121.5,
                timezone="Asia/Shanghai",
                calculation_time_override=None,
                operator="tester",
                session_id="offline-site-change",
            )
        )

        gateway.telemetry = _safe_solar_telemetry().model_copy(
            update={"heartbeat": 11}
        )
        await runtime.refresh_once()
        blocked = await runtime.request_mode(
            ModeChangeRequest(
                command_id=uuid4(),
                mode=ControlMode.SOLAR,
                operator="tester",
                session_id="rearm-blocked",
            )
        )
        assert blocked.accepted is False
        assert "manual mode" in (blocked.reason or "")

        gateway.telemetry = gateway.telemetry.model_copy(
            update={"confirmed_mode": ControlMode.MANUAL, "heartbeat": 12}
        )
        await runtime.refresh_once()
        accepted = await runtime.request_mode(
            ModeChangeRequest(
                command_id=uuid4(),
                mode=ControlMode.SOLAR,
                operator="tester",
                session_id="rearm-accepted",
            )
        )
        assert accepted.accepted is True
        assert runtime._automatic_rearm_required is False  # noqa: SLF001
    finally:
        await runtime.stop()


@pytest.mark.asyncio
async def test_old_site_weather_request_cannot_overwrite_new_site_result(
    commissioned_settings,
) -> None:
    client = BlockingWeatherClient()
    runtime = build_runtime(
        settings=commissioned_settings,
        weather_client=client,
        start_background_tasks=False,
    )
    await runtime.start()
    old_refresh = asyncio.create_task(runtime.refresh_once(include_weather=True))
    try:
        await asyncio.wait_for(client.first_started.wait(), timeout=1.0)

        await runtime.update_site(
            SiteConfigUpdate(
                latitude=31.2,
                longitude=121.5,
                timezone="Asia/Shanghai",
                calculation_time_override=datetime(
                    2020,
                    6,
                    21,
                    12,
                    0,
                    tzinfo=timezone(timedelta(hours=8)),
                ),
                operator="tester",
                session_id="weather-race",
            )
        )
        assert len(client.calls) == 2
        assert runtime.weather.selected is not None
        assert runtime.weather.selected.weather_code == 63

        client.release_first.set()
        await asyncio.wait_for(old_refresh, timeout=1.0)

        assert runtime.snapshot.site.longitude == 121.5
        assert runtime.snapshot.weather.selected is not None
        assert runtime.snapshot.weather.selected.weather_code == 63
    finally:
        client.release_first.set()
        if not old_refresh.done():
            await old_refresh
        await runtime.stop()
