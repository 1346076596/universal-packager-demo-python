from __future__ import annotations

from datetime import date
from typing import Any, Protocol

import httpx

OPEN_METEO_VARIABLES = (
    "temperature_2m",
    "weather_code",
    "cloud_cover",
    "cloud_cover_low",
    "cloud_cover_mid",
    "cloud_cover_high",
    "visibility",
    "wind_speed_10m",
    "wind_direction_10m",
    "wind_gusts_10m",
    "shortwave_radiation",
    "direct_normal_irradiance",
    "is_day",
)


class WeatherClient(Protocol):
    async def fetch_hourly(
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str,
        start_date: date,
        end_date: date,
        source: str,
    ) -> dict[str, Any]: ...

    async def close(self) -> None: ...


class OpenMeteoClient:
    def __init__(self, *, timeout_seconds: float = 5.0) -> None:
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout_seconds),
            headers={"User-Agent": "solar-tracker-backend/0.1"},
        )

    async def fetch_hourly(
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str,
        start_date: date,
        end_date: date,
        source: str,
    ) -> dict[str, Any]:
        if source == "archive":
            url = "https://archive-api.open-meteo.com/v1/archive"
        elif source == "forecast":
            url = "https://api.open-meteo.com/v1/forecast"
        else:
            raise ValueError(f"unsupported Open-Meteo source: {source}")
        response = await self._client.get(
            url,
            params={
                "latitude": latitude,
                "longitude": longitude,
                "timezone": timezone,
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat(),
                "hourly": ",".join(OPEN_METEO_VARIABLES),
                **(
                    {"current": ",".join(OPEN_METEO_VARIABLES)}
                    if source == "forecast"
                    else {}
                ),
            },
        )
        response.raise_for_status()
        payload = response.json()
        if payload.get("error"):
            raise RuntimeError(str(payload.get("reason") or "Open-Meteo error"))
        return payload

    async def close(self) -> None:
        await self._client.aclose()
