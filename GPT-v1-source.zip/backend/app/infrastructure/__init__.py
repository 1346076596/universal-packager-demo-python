"""External-system adapters with safe, explicit defaults."""
