from __future__ import annotations

import json
import os
import threading
from datetime import datetime
from pathlib import Path

from app.domain.common import utc_now
from app.domain.settings import SiteConfig


class ConfigRepository:
    def __init__(
        self,
        config_path: Path,
        audit_path: Path,
        default_site: SiteConfig,
    ) -> None:
        self._config_path = config_path
        self._audit_path = audit_path
        self._default_site = default_site
        self._lock = threading.RLock()

    def load(self) -> SiteConfig:
        with self._lock:
            if not self._config_path.exists():
                return self._default_site
            payload = json.loads(self._config_path.read_text(encoding="utf-8"))
            return SiteConfig.model_validate(payload)

    def save(
        self,
        config: SiteConfig,
        *,
        operator: str,
        session_id: str,
        changed_at: datetime | None = None,
    ) -> SiteConfig:
        timestamp = changed_at or utc_now()
        with self._lock:
            old = self.load()
            self._config_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self._config_path.with_suffix(self._config_path.suffix + ".tmp")
            temporary.write_text(
                config.model_dump_json(indent=2),
                encoding="utf-8",
            )
            os.replace(temporary, self._config_path)
            self._append_audit(
                {
                    "event": "site_config_changed",
                    "changed_at": timestamp.isoformat(),
                    "operator": operator,
                    "session_id": session_id,
                    "old": old.model_dump(mode="json"),
                    "new": config.model_dump(mode="json"),
                }
            )
        return config

    def _append_audit(self, record: dict[str, object]) -> None:
        self._audit_path.parent.mkdir(parents=True, exist_ok=True)
        with self._audit_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")))
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
