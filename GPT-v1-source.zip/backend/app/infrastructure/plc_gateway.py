from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod

from app.config import MechanicalLimits
from app.domain.commands import (
    ManualDirection,
    ManualJogRequest,
    ModeChangeRequest,
    SolarTargetCommand,
    ThermalControlCommand,
)
from app.domain.common import ControlMode, utc_now
from app.domain.telemetry import (
    AxisMotion,
    AxisTelemetry,
    CommandAcknowledgement,
    PlcTelemetry,
    SafetyTelemetry,
)


class PlcGateway(ABC):
    """Semantic PLC boundary. Concrete register mapping is deliberately not guessed."""

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    @abstractmethod
    async def read_telemetry(self) -> PlcTelemetry: ...

    @abstractmethod
    async def request_mode(
        self, command: ModeChangeRequest
    ) -> CommandAcknowledgement: ...

    @abstractmethod
    async def manual_jog(self, command: ManualJogRequest) -> CommandAcknowledgement: ...

    @abstractmethod
    async def send_solar_target(self, command: SolarTargetCommand) -> None: ...

    @abstractmethod
    async def send_thermal_guidance(self, command: ThermalControlCommand) -> None: ...

    @abstractmethod
    async def send_time_state(
        self, *, is_day: bool, calculation_time_valid: bool
    ) -> None: ...


class UnconfiguredPlcGateway(PlcGateway):
    """Safe default: always offline and never acknowledges a physical action."""

    def __init__(self) -> None:
        self._telemetry = PlcTelemetry()

    async def read_telemetry(self) -> PlcTelemetry:
        return self._telemetry.model_copy(update={"sampled_at": utc_now()})

    async def request_mode(self, command: ModeChangeRequest) -> CommandAcknowledgement:
        return CommandAcknowledgement(
            command_id=command.command_id,
            accepted=False,
            completed=True,
            result="rejected",
            reason="PLC protocol/register mapping is not commissioned",
        )

    async def manual_jog(self, command: ManualJogRequest) -> CommandAcknowledgement:
        return CommandAcknowledgement(
            command_id=command.command_id,
            accepted=False,
            completed=True,
            result="rejected",
            reason="PLC offline; production never falls back to simulated motion",
        )

    async def send_solar_target(self, command: SolarTargetCommand) -> None:
        return None

    async def send_thermal_guidance(self, command: ThermalControlCommand) -> None:
        return None

    async def send_time_state(
        self, *, is_day: bool, calculation_time_valid: bool
    ) -> None:
        return None


class DevelopmentSimulatedPlcGateway(PlcGateway):
    """Explicit in-memory simulator for development and tests, never a fallback."""

    def __init__(self, mechanics: MechanicalLimits) -> None:
        self._mechanics = mechanics
        self._lock = asyncio.Lock()
        self._running = False
        self._heartbeat = 0
        self._confirmed_mode = ControlMode.MANUAL
        self._requested_mode: ControlMode | None = None
        self._last_ack: CommandAcknowledgement | None = None
        self._executed: dict[str, CommandAcknowledgement] = {}
        self._is_day = True
        self._calculation_time_valid = True
        self._azimuth = (
            (mechanics.azimuth_min + mechanics.azimuth_max) / 2.0
            if mechanics.configured
            else 0.0
        )
        self._elevation = (
            (mechanics.elevation_min + mechanics.elevation_max) / 2.0
            if mechanics.configured
            else 0.0
        )
        self._solar_target: SolarTargetCommand | None = None
        self._thermal: ThermalControlCommand | None = None
        self._az_motion = AxisMotion.STOPPED
        self._el_motion = AxisMotion.STOPPED

    async def start(self) -> None:
        async with self._lock:
            self._running = True

    async def stop(self) -> None:
        async with self._lock:
            self._running = False
            self._az_motion = AxisMotion.STOPPED
            self._el_motion = AxisMotion.STOPPED

    async def read_telemetry(self) -> PlcTelemetry:
        async with self._lock:
            self._heartbeat += 1
            self._advance()
            safety = SafetyTelemetry(
                emergency_stop=False,
                safety_chain_ok=self._running,
                communication_fault=not self._running,
                position_feedback_valid=self._mechanics.configured,
                drive_fault=False,
                fault_code=(
                    None
                    if self._running and self._mechanics.configured
                    else "MECHANICS_NOT_COMMISSIONED"
                ),
            )
            az_neg, az_pos, el_neg, el_pos = self._limits()
            return PlcTelemetry(
                sampled_at=utc_now(),
                online=self._running,
                heartbeat=self._heartbeat,
                confirmed_mode=self._confirmed_mode,
                requested_mode=self._requested_mode,
                running_state=self._running_state(),
                night_parked=self._night_parked(),
                azimuth=AxisTelemetry(
                    actual_angle=(
                        round(self._azimuth, 4)
                        if self._mechanics.configured
                        else None
                    ),
                    negative_limit=az_neg,
                    positive_limit=az_pos,
                    moving=self._az_motion is not AxisMotion.STOPPED,
                    motion_stopped=self._az_motion is AxisMotion.STOPPED,
                    direction=self._az_motion,
                    at_target=self._az_motion is AxisMotion.STOPPED,
                    position_valid=self._mechanics.configured,
                ),
                elevation=AxisTelemetry(
                    actual_angle=(
                        round(self._elevation, 4)
                        if self._mechanics.configured
                        else None
                    ),
                    negative_limit=el_neg,
                    positive_limit=el_pos,
                    moving=self._el_motion is not AxisMotion.STOPPED,
                    motion_stopped=self._el_motion is AxisMotion.STOPPED,
                    direction=self._el_motion,
                    at_target=self._el_motion is AxisMotion.STOPPED,
                    position_valid=self._mechanics.configured,
                ),
                safety=safety,
                last_ack=self._last_ack,
                simulated=True,
                simulation_label="DEVELOPMENT SIMULATION - NO PHYSICAL PLC OUTPUT",
            )

    async def request_mode(self, command: ModeChangeRequest) -> CommandAcknowledgement:
        async with self._lock:
            prior = self._executed.get(str(command.command_id))
            if prior is not None:
                return prior
            self._requested_mode = command.mode
            if not self._running or not self._mechanics.configured:
                ack = CommandAcknowledgement(
                    command_id=command.command_id,
                    accepted=False,
                    completed=True,
                    result="rejected",
                    reason="simulator offline or mechanics not commissioned",
                )
            else:
                self._az_motion = AxisMotion.STOPPED
                self._el_motion = AxisMotion.STOPPED
                # A target or camera frame belongs to the mode/site in which it was
                # received. Never consume retained automatic guidance after switching.
                self._solar_target = None
                self._thermal = None
                self._confirmed_mode = command.mode
                ack = CommandAcknowledgement(
                    command_id=command.command_id,
                    accepted=True,
                    completed=True,
                    result="confirmed",
                )
            self._last_ack = ack
            self._executed[str(command.command_id)] = ack
            return ack

    async def manual_jog(self, command: ManualJogRequest) -> CommandAcknowledgement:
        async with self._lock:
            prior = self._executed.get(str(command.command_id))
            if prior is not None:
                return prior
            if (
                not self._running
                or not self._is_day
                or not self._mechanics.configured
                or self._confirmed_mode is not ControlMode.MANUAL
            ):
                ack = CommandAcknowledgement(
                    command_id=command.command_id,
                    accepted=False,
                    completed=True,
                    result="rejected",
                    reason="manual motion preconditions are not satisfied",
                )
            else:
                amount = command.step_degrees
                if amount is None:
                    amount = (command.max_duration_seconds or 0.0) * 0.5
                if command.direction is ManualDirection.AZ_LEFT:
                    self._azimuth = max(
                        self._mechanics.azimuth_min, self._azimuth - amount
                    )
                elif command.direction is ManualDirection.AZ_RIGHT:
                    self._azimuth = min(
                        self._mechanics.azimuth_max, self._azimuth + amount
                    )
                elif command.direction is ManualDirection.ALT_DOWN:
                    self._elevation = max(
                        self._mechanics.elevation_min, self._elevation - amount
                    )
                else:
                    self._elevation = min(
                        self._mechanics.elevation_max, self._elevation + amount
                    )
                ack = CommandAcknowledgement(
                    command_id=command.command_id,
                    accepted=True,
                    completed=True,
                    result="confirmed",
                )
            self._last_ack = ack
            self._executed[str(command.command_id)] = ack
            return ack

    async def send_solar_target(self, command: SolarTargetCommand) -> None:
        async with self._lock:
            if (
                command.valid
                and command.feedback_fresh
                and command.target_azimuth is not None
                and command.target_altitude is not None
            ):
                self._solar_target = command
            else:
                self._solar_target = None

    async def send_thermal_guidance(self, command: ThermalControlCommand) -> None:
        async with self._lock:
            self._thermal = command

    async def send_time_state(
        self, *, is_day: bool, calculation_time_valid: bool
    ) -> None:
        async with self._lock:
            self._is_day = is_day
            self._calculation_time_valid = calculation_time_valid

    def _advance(self) -> None:
        self._az_motion = AxisMotion.STOPPED
        self._el_motion = AxisMotion.STOPPED
        if not self._running or not self._mechanics.configured:
            return
        # Historical/future calculation overrides are display-only. Match the
        # production PLC priority order: preview inhibition wins over night parking.
        if not self._calculation_time_valid:
            return
        if not self._is_day:
            if not self._mechanics.parking_calibrated:
                return
            self._azimuth, self._az_motion = self._step_toward(
                self._azimuth,
                self._mechanics.parking_azimuth,
                self._mechanics.azimuth_min,
                self._mechanics.azimuth_max,
            )
            if self._az_motion is AxisMotion.STOPPED:
                self._elevation, self._el_motion = self._step_toward(
                    self._elevation,
                    self._mechanics.parking_elevation,
                    self._mechanics.elevation_min,
                    self._mechanics.elevation_max,
                )
            return
        if (
            self._confirmed_mode is ControlMode.SOLAR
            and self._solar_target
        ):
            command = self._solar_target
            self._azimuth, self._az_motion = self._step_toward_authorized(
                self._azimuth,
                command.target_azimuth,
                command.azimuth_direction,
                self._mechanics.azimuth_min,
                self._mechanics.azimuth_max,
            )
            self._elevation, self._el_motion = self._step_toward_authorized(
                self._elevation,
                command.target_altitude,
                command.elevation_direction,
                self._mechanics.elevation_min,
                self._mechanics.elevation_max,
            )
        elif self._confirmed_mode is ControlMode.THERMAL and self._thermal:
            guidance = self._thermal
            if not (
                guidance.image_valid and guidance.hotspot_valid and not guidance.aligned
            ):
                return
            if guidance.priority_axis == "azimuth":
                if guidance.horizontal_direction == "left":
                    self._azimuth = max(
                        self._mechanics.azimuth_min, self._azimuth - 0.1
                    )
                    self._az_motion = AxisMotion.NEGATIVE
                elif guidance.horizontal_direction == "right":
                    self._azimuth = min(
                        self._mechanics.azimuth_max, self._azimuth + 0.1
                    )
                    self._az_motion = AxisMotion.POSITIVE
            elif guidance.priority_axis == "elevation":
                if guidance.vertical_direction == "up":
                    self._elevation = min(
                        self._mechanics.elevation_max, self._elevation + 0.1
                    )
                    self._el_motion = AxisMotion.POSITIVE
                elif guidance.vertical_direction == "down":
                    self._elevation = max(
                        self._mechanics.elevation_min, self._elevation - 0.1
                    )
                    self._el_motion = AxisMotion.NEGATIVE

    @staticmethod
    def _step_toward(
        actual: float,
        target: float,
        minimum: float,
        maximum: float,
        step: float = 0.2,
    ) -> tuple[float, AxisMotion]:
        target = min(maximum, max(minimum, target))
        error = target - actual
        if abs(error) <= 0.1:
            return target, AxisMotion.STOPPED
        if error > 0:
            return actual + min(step, error), AxisMotion.POSITIVE
        return actual - min(step, abs(error)), AxisMotion.NEGATIVE

    @classmethod
    def _step_toward_authorized(
        cls,
        actual: float,
        target: float | None,
        requested_direction: AxisMotion,
        minimum: float,
        maximum: float,
    ) -> tuple[float, AxisMotion]:
        if target is None:
            return actual, AxisMotion.STOPPED
        error = target - actual
        direction_matches = (
            requested_direction is AxisMotion.POSITIVE and error > 0.0
        ) or (
            requested_direction is AxisMotion.NEGATIVE and error < 0.0
        )
        if not direction_matches:
            return actual, AxisMotion.STOPPED
        return cls._step_toward(actual, target, minimum, maximum)

    def _limits(self) -> tuple[bool, bool, bool, bool]:
        if not self._mechanics.configured:
            return False, False, False, False
        return (
            self._azimuth <= self._mechanics.azimuth_min,
            self._azimuth >= self._mechanics.azimuth_max,
            self._elevation <= self._mechanics.elevation_min,
            self._elevation >= self._mechanics.elevation_max,
        )

    def _night_parked(self) -> bool:
        return (
            not self._is_day
            and self._mechanics.parking_calibrated
            and abs(self._azimuth - self._mechanics.parking_azimuth) <= 0.1
            and abs(self._elevation - self._mechanics.parking_elevation) <= 0.1
        )

    def _running_state(self) -> str:
        if not self._running:
            return "disabled"
        if not self._is_day:
            return "night_park" if not self._night_parked() else "night_parked"
        return self._confirmed_mode.value


def build_plc_gateway(kind: str, mechanics: MechanicalLimits) -> PlcGateway:
    if kind == "development_simulation":
        return DevelopmentSimulatedPlcGateway(mechanics)
    return UnconfiguredPlcGateway()
