from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime

from app.domain.thermal import ThermalGuidance


@dataclass(frozen=True, slots=True)
class FrameRecord:
    frame_id: int
    captured_at: datetime
    raw_jpeg: bytes
    annotated_jpeg: bytes
    guidance: ThermalGuidance
    simulated: bool = False

    def __post_init__(self) -> None:
        if self.frame_id != self.guidance.frame_id:
            raise ValueError("frame and guidance must use the same frame_id")
        if not self.raw_jpeg.startswith(b"\xff\xd8"):
            raise ValueError("raw frame is not JPEG data")
        if not self.annotated_jpeg.startswith(b"\xff\xd8"):
            raise ValueError("annotated frame is not JPEG data")


class FrameStore:
    """Thread-safe latest-value store; it never queues unbounded video frames."""

    def __init__(self) -> None:
        self._latest: FrameRecord | None = None
        self._lock = threading.Lock()

    def publish(self, frame: FrameRecord) -> None:
        with self._lock:
            if self._latest is not None and frame.frame_id <= self._latest.frame_id:
                raise ValueError("frame_id must increase monotonically")
            self._latest = frame

    def latest(self) -> FrameRecord | None:
        with self._lock:
            return self._latest
