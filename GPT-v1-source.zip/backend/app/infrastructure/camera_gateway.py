from __future__ import annotations

import asyncio
import io
import math
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime

import numpy as np
from PIL import Image, ImageDraw

from app.domain.common import utc_now


@dataclass(frozen=True, slots=True)
class CapturedFrame:
    frame_id: int
    captured_at: datetime
    jpeg: bytes
    temperature: np.ndarray | None
    simulated: bool = False


class CameraGateway(ABC):
    @property
    @abstractmethod
    def online(self) -> bool: ...

    @property
    @abstractmethod
    def status(self) -> str: ...

    @property
    @abstractmethod
    def simulated(self) -> bool: ...

    async def start(self) -> None:
        return None

    async def stop(self) -> None:
        return None

    @abstractmethod
    async def read_frame(self) -> CapturedFrame | None: ...


class UnconfiguredCameraGateway(CameraGateway):
    """Safe default for an unknown camera model/SDK. It never fabricates a frame."""

    @property
    def online(self) -> bool:
        return False

    @property
    def status(self) -> str:
        return "camera_unconfigured"

    @property
    def simulated(self) -> bool:
        return False

    async def read_frame(self) -> CapturedFrame | None:
        await asyncio.sleep(0.25)
        return None


class DevelopmentSimulatedCameraGateway(CameraGateway):
    """Explicit, watermarked development source; forbidden by production settings."""

    def __init__(self, *, frames_per_second: float = 5.0) -> None:
        self._period = 1.0 / frames_per_second
        self._running = False
        self._frame_id = 0

    @property
    def online(self) -> bool:
        return self._running

    @property
    def status(self) -> str:
        return (
            "development_simulation_not_live"
            if self._running
            else "development_simulation_stopped"
        )

    @property
    def simulated(self) -> bool:
        return True

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def read_frame(self) -> CapturedFrame | None:
        if not self._running:
            return None
        await asyncio.sleep(self._period)
        self._frame_id += 1
        phase = self._frame_id / 12.0
        thermal_height, thermal_width = 60, 80
        hotspot_x = int((0.5 + 0.28 * math.sin(phase)) * thermal_width)
        hotspot_y = int((0.5 + 0.22 * math.cos(phase * 0.8)) * thermal_height)
        yy, xx = np.mgrid[0:thermal_height, 0:thermal_width]
        distance = (xx - hotspot_x) ** 2 + (yy - hotspot_y) ** 2
        temperature = 24.0 + 78.0 * np.exp(-distance / 32.0)

        normalized = np.clip(
            (temperature - temperature.min())
            / max(float(np.ptp(temperature)), 1e-6)
            * 255.0,
            0,
            255,
        ).astype(np.uint8)
        thermal_image = Image.fromarray(normalized, mode="L").resize(
            (640, 480), Image.Resampling.BILINEAR
        )
        image = Image.merge(
            "RGB",
            (
                thermal_image,
                thermal_image.point(lambda value: int(value * 0.35)),
                thermal_image.point(lambda value: 255 - value),
            ),
        )
        draw = ImageDraw.Draw(image)
        draw.rectangle((0, 0, 639, 34), fill=(150, 0, 0))
        draw.text(
            (10, 9),
            "DEVELOPMENT SIMULATION - NOT LIVE CAMERA",
            fill=(255, 255, 255),
        )
        output = io.BytesIO()
        image.save(output, format="JPEG", quality=85)
        return CapturedFrame(
            frame_id=self._frame_id,
            captured_at=utc_now(),
            jpeg=output.getvalue(),
            temperature=temperature,
            simulated=True,
        )


def build_camera_gateway(kind: str) -> CameraGateway:
    if kind == "development_simulation":
        return DevelopmentSimulatedCameraGateway()
    return UnconfiguredCameraGateway()
