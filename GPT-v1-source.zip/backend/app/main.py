# ruff: noqa: E402
from __future__ import annotations

# 兼容 VS Code 编辑器右上角的“运行 Python 文件”。直接运行本文件时，
# 转入全栈启动器；Uvicorn 以 app.main 导入时不会进入这个分支。
if __name__ == "__main__":
    import runpy
    from pathlib import Path

    launcher = (
        Path(__file__).resolve().parents[2] / "tools" / "start_full_stack.py"
    )
    runpy.run_path(str(launcher), run_name="__main__")
    raise SystemExit(0)

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.application.mode_service import ModeService
from app.application.snapshot_service import SnapshotService
from app.application.system_orchestrator import SystemOrchestrator
from app.config import AppSettings
from app.infrastructure.camera_gateway import CameraGateway, build_camera_gateway
from app.infrastructure.config_repository import ConfigRepository
from app.infrastructure.frame_store import FrameStore
from app.infrastructure.open_meteo_client import OpenMeteoClient, WeatherClient
from app.infrastructure.plc_gateway import PlcGateway, build_plc_gateway
from app.presentation.media_stream import router as media_router
from app.presentation.rest_api import router as rest_router
from app.presentation.websocket import router as websocket_router
from app.services.reappearance_predictor import ReappearancePredictor
from app.services.solar_position import SolarPositionService
from app.services.thermal_tracker import ThermalTracker
from app.services.weather_service import WeatherService


def build_runtime(
    *,
    settings: AppSettings,
    plc_gateway: PlcGateway | None = None,
    camera_gateway: CameraGateway | None = None,
    weather_client: WeatherClient | None = None,
    start_background_tasks: bool = True,
) -> SystemOrchestrator:
    config_repository = ConfigRepository(
        settings.site_config_path,
        settings.audit_log_path,
        settings.default_site,
    )
    plc = plc_gateway or build_plc_gateway(
        settings.plc_gateway_kind, settings.mechanics
    )
    camera = camera_gateway or build_camera_gateway(settings.camera_gateway_kind)
    frame_store = FrameStore()
    solar_service = SolarPositionService(settings.mechanics)
    client = weather_client or OpenMeteoClient(
        timeout_seconds=settings.weather.timeout_seconds
    )
    weather_service = WeatherService(client, settings.weather)
    predictor = ReappearancePredictor(solar_service, settings.weather)
    thermal_tracker = ThermalTracker(settings.thermal)
    mode_service = ModeService(plc, settings)
    snapshot_service = SnapshotService(settings)
    return SystemOrchestrator(
        settings=settings,
        config_repository=config_repository,
        plc_gateway=plc,
        camera_gateway=camera,
        frame_store=frame_store,
        solar_service=solar_service,
        weather_service=weather_service,
        predictor=predictor,
        thermal_tracker=thermal_tracker,
        mode_service=mode_service,
        snapshot_service=snapshot_service,
        start_background_tasks=start_background_tasks,
    )


def create_app(
    *,
    settings: AppSettings | None = None,
    plc_gateway: PlcGateway | None = None,
    camera_gateway: CameraGateway | None = None,
    weather_client: WeatherClient | None = None,
    start_background_tasks: bool = True,
) -> FastAPI:
    resolved_settings = settings or AppSettings.from_env()
    runtime = build_runtime(
        settings=resolved_settings,
        plc_gateway=plc_gateway,
        camera_gateway=camera_gateway,
        weather_client=weather_client,
        start_background_tasks=start_background_tasks,
    )

    @asynccontextmanager
    async def lifespan(application: FastAPI) -> AsyncIterator[None]:
        await runtime.start()
        try:
            yield
        finally:
            await runtime.stop()

    application = FastAPI(
        title="逐日追踪系统 API",
        version="1.2.0",
        description=(
            "Vue-only API boundary. Physical outputs remain exclusively controlled "
            "and safety-arbitrated by the PLC."
        ),
        lifespan=lifespan,
    )
    application.state.runtime = runtime
    application.include_router(rest_router)
    application.include_router(websocket_router)
    application.include_router(media_router)
    return application


app = create_app()
