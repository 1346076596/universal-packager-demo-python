from __future__ import annotations

import io
from datetime import datetime, timezone

import numpy as np
from PIL import Image, ImageDraw

from app.domain.common import utc_now
from app.domain.thermal import (
    AxisPriority,
    HorizontalDirection,
    ThermalCalibration,
    ThermalGuidance,
    VerticalDirection,
)


class ThermalTracker:
    def __init__(self, calibration: ThermalCalibration) -> None:
        self._calibration = calibration
        self._previous_aligned = False

    def analyze(
        self,
        temperature: np.ndarray | None,
        *,
        frame_id: int,
        captured_at: datetime,
        now: datetime | None = None,
        simulated: bool = False,
    ) -> ThermalGuidance:
        processed_at = now or utc_now()
        if not self._calibration.configured:
            return ThermalGuidance.invalid(
                "thermal_calibration_not_commissioned",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )
        if captured_at.tzinfo is None or captured_at.utcoffset() is None:
            return ThermalGuidance.invalid(
                "frame_timestamp_missing_timezone",
                frame_id=frame_id,
                now=processed_at,
                simulated=simulated,
            )
        age = (
            processed_at.astimezone(timezone.utc) - captured_at.astimezone(timezone.utc)
        ).total_seconds()
        if age < -0.5 or age > self._calibration.max_frame_age_seconds:
            self._previous_aligned = False
            return ThermalGuidance.invalid(
                "frame_stale",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                simulated=simulated,
            )
        if temperature is None:
            return ThermalGuidance.invalid(
                "temperature_data_unavailable",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )
        matrix = np.asarray(temperature, dtype=np.float64)
        if matrix.ndim != 2 or min(matrix.shape) < 2:
            return ThermalGuidance.invalid(
                "invalid_temperature_shape",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )
        if not np.isfinite(matrix).all():
            return ThermalGuidance.invalid(
                "non_finite_temperature_data",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )

        saturated = matrix >= self._calibration.saturation_temperature
        if float(np.mean(saturated)) > self._calibration.max_saturation_ratio:
            self._previous_aligned = False
            return ThermalGuidance.invalid(
                "frame_saturated",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )

        mask = matrix >= self._calibration.hot_threshold
        hot_count = int(np.count_nonzero(mask))
        if hot_count < self._calibration.min_hot_pixels:
            self._previous_aligned = False
            return ThermalGuidance.invalid(
                "hotspot_not_found",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )

        yy, xx = np.nonzero(mask)
        weights = matrix[mask] - self._calibration.hot_threshold + 1e-6
        centroid_x = float(np.average(xx, weights=weights))
        centroid_y = float(np.average(yy, weights=weights))
        height, width = matrix.shape
        center_x = self._calibration.center_x_normalized * (width - 1)
        center_y = self._calibration.center_y_normalized * (height - 1)
        dx = (centroid_x - center_x) / max(width / 2.0, 1.0)
        dy = (centroid_y - center_y) / max(height / 2.0, 1.0)
        dx *= self._calibration.horizontal_sign
        dy *= self._calibration.vertical_sign

        maximum = float(np.max(matrix[mask]))
        contrast_score = max(
            0.0,
            min(
                1.0,
                (maximum - self._calibration.hot_threshold) / max(abs(maximum), 1.0),
            ),
        )
        area_score = min(
            1.0,
            hot_count / max(self._calibration.min_hot_pixels * 4.0, 1.0),
        )
        confidence = max(0.0, min(1.0, 0.65 * contrast_score + 0.35 * area_score))
        if confidence < self._calibration.minimum_confidence:
            self._previous_aligned = False
            return ThermalGuidance.invalid(
                "hotspot_confidence_too_low",
                frame_id=frame_id,
                captured_at=captured_at,
                now=processed_at,
                stale=False,
                simulated=simulated,
            )

        if self._previous_aligned:
            aligned = (
                abs(dx) <= self._calibration.exit_deadband_x
                and abs(dy) <= self._calibration.exit_deadband_y
            )
        else:
            aligned = (
                abs(dx) <= self._calibration.enter_deadband_x
                and abs(dy) <= self._calibration.enter_deadband_y
            )
        self._previous_aligned = aligned

        horizontal = HorizontalDirection.NONE
        vertical = VerticalDirection.NONE
        priority = AxisPriority.NONE
        if not aligned:
            if dx < -self._calibration.enter_deadband_x:
                horizontal = HorizontalDirection.LEFT
            elif dx > self._calibration.enter_deadband_x:
                horizontal = HorizontalDirection.RIGHT
            if dy < -self._calibration.enter_deadband_y:
                vertical = VerticalDirection.UP
            elif dy > self._calibration.enter_deadband_y:
                vertical = VerticalDirection.DOWN
            normalized_x = abs(dx) / self._calibration.enter_deadband_x
            normalized_y = abs(dy) / self._calibration.enter_deadband_y
            if (
                horizontal is not HorizontalDirection.NONE
                or vertical is not VerticalDirection.NONE
            ):
                priority = (
                    AxisPriority.AZIMUTH
                    if normalized_x >= normalized_y
                    else AxisPriority.ELEVATION
                )

        return ThermalGuidance(
            frame_id=frame_id,
            captured_at=captured_at,
            processed_at=processed_at,
            valid=True,
            hotspot_valid=True,
            aligned=aligned,
            dx_normalized=round(dx, 5),
            dy_normalized=round(dy, 5),
            centroid_x=round(centroid_x, 3),
            centroid_y=round(centroid_y, 3),
            horizontal_direction=horizontal,
            vertical_direction=vertical,
            priority_axis=priority,
            confidence=round(confidence, 4),
            stale=False,
            invalid_reason=None,
            simulated=simulated,
        )

    def annotate_jpeg(
        self,
        raw_jpeg: bytes,
        guidance: ThermalGuidance,
        *,
        thermal_width: int,
        thermal_height: int,
    ) -> bytes:
        with Image.open(io.BytesIO(raw_jpeg)) as source:
            image = source.convert("RGB").copy()
        draw = ImageDraw.Draw(image)
        width, height = image.size
        cx = self._calibration.center_x_normalized * width
        cy = self._calibration.center_y_normalized * height
        half_deadband_x = self._calibration.enter_deadband_x * width / 2.0
        half_deadband_y = self._calibration.enter_deadband_y * height / 2.0
        draw.line((cx, 0, cx, height), fill=(0, 255, 0), width=1)
        draw.line((0, cy, width, cy), fill=(0, 255, 0), width=1)
        draw.rectangle(
            (
                cx - half_deadband_x,
                cy - half_deadband_y,
                cx + half_deadband_x,
                cy + half_deadband_y,
            ),
            outline=(255, 255, 0),
            width=2,
        )
        if guidance.centroid_x is not None and guidance.centroid_y is not None:
            px = guidance.centroid_x / max(thermal_width - 1, 1) * width
            py = guidance.centroid_y / max(thermal_height - 1, 1) * height
            draw.ellipse((px - 5, py - 5, px + 5, py + 5), outline=(255, 0, 0), width=3)
            draw.line((cx, cy, px, py), fill=(255, 0, 0), width=2)
        label = (
            f"frame={guidance.frame_id} "
            f"dx={guidance.dx_normalized:+.3f} "
            f"dy={guidance.dy_normalized:+.3f} "
            f"conf={guidance.confidence:.2f}"
        )
        draw.rectangle((4, 4, min(width - 4, 470), 26), fill=(0, 0, 0))
        draw.text((8, 8), label, fill=(255, 255, 255))
        if guidance.simulated:
            warning = "DEVELOPMENT SIMULATION - NOT LIVE CAMERA"
            draw.rectangle(
                (4, height - 28, min(width - 4, 360), height - 4),
                fill=(160, 0, 0),
            )
            draw.text((8, height - 24), warning, fill=(255, 255, 255))
        output = io.BytesIO()
        image.save(output, format="JPEG", quality=85)
        return output.getvalue()
