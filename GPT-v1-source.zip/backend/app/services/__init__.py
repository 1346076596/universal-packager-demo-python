"""Pure and orchestrated domain services."""
