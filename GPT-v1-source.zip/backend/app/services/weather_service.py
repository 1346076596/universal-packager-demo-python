from __future__ import annotations

import asyncio
from collections import OrderedDict
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable
from zoneinfo import ZoneInfo

from app.config import WeatherSettings
from app.domain.common import utc_now
from app.domain.settings import SiteConfig
from app.domain.weather import (
    WeatherHistoryPoint,
    WeatherHistoryState,
    WeatherSample,
    WeatherState,
)
from app.infrastructure.open_meteo_client import WeatherClient

OPEN_METEO_ARCHIVE_START = date(1940, 1, 1)
OPEN_METEO_MAX_FUTURE_OFFSET_DAYS = 15
OPEN_METEO_HOURLY_BOUNDARY_TOLERANCE = timedelta(hours=1)
WEATHER_CACHE_MAX_ENTRIES = 128
WEATHER_LOCK_MAX_ENTRIES = 128

_WeatherKey = tuple[object, ...]


@dataclass(slots=True)
class _CacheEntry:
    samples: tuple[WeatherSample, ...]
    fetched_at: datetime
    source: str
    current: WeatherSample | None = None


@dataclass(slots=True)
class _LockEntry:
    lock: asyncio.Lock
    users: int = 0


@dataclass(frozen=True, slots=True)
class _HistoryWindow:
    source: str
    start_date: date
    end_date: date


class WeatherService:
    def __init__(
        self,
        client: WeatherClient,
        settings: WeatherSettings,
        *,
        clock: Callable[[], datetime] = utc_now,
    ) -> None:
        self._client = client
        self._settings = settings
        self._clock = clock
        self._cache: OrderedDict[_WeatherKey, _CacheEntry] = OrderedDict()
        self._locks: OrderedDict[_WeatherKey, _LockEntry] = OrderedDict()

    async def get_weather(
        self,
        site: SiteConfig,
        calculation_time: datetime,
    ) -> WeatherState:
        now = self._clock()
        local_time = calculation_time.astimezone(ZoneInfo(site.timezone))
        source, start_date, end_date, range_error = self._select_window(
            local_time, now.astimezone(ZoneInfo(site.timezone))
        )
        if range_error:
            return WeatherState(error=range_error, source="none")

        key = (
            round(site.latitude, 4),
            round(site.longitude, 4),
            site.timezone,
            start_date,
            end_date,
            source,
        )
        allow_current = site.calculation_time_override is None
        entry = self._cached_entry(key)
        if entry is not None and self._age_seconds(entry.fetched_at, now) <= (
            self._settings.cache_ttl_seconds
        ):
            return self._state_from_entry(
                entry,
                local_time,
                now,
                stale=False,
                allow_current=allow_current,
            )

        lock_entry = self._lock_entry(key)
        lock_entry.users += 1
        try:
            async with lock_entry.lock:
                now = self._clock()
                entry = self._cached_entry(key)
                if entry is not None and self._age_seconds(entry.fetched_at, now) <= (
                    self._settings.cache_ttl_seconds
                ):
                    return self._state_from_entry(
                        entry,
                        local_time,
                        now,
                        stale=False,
                        allow_current=allow_current,
                    )
                try:
                    payload = await self._client.fetch_hourly(
                        latitude=site.latitude,
                        longitude=site.longitude,
                        timezone=site.timezone,
                        start_date=start_date,
                        end_date=end_date,
                        source=source,
                    )
                    samples = self._parse_hourly(payload, site.timezone, now)
                    if not samples:
                        raise ValueError("Open-Meteo returned no usable hourly samples")
                    entry = _CacheEntry(
                        samples=samples,
                        fetched_at=now,
                        source=source,
                        current=self._parse_current(payload, site.timezone, now),
                    )
                    self._cache[key] = entry
                    self._cache.move_to_end(key)
                    self._trim_cache()
                    return self._state_from_entry(
                        entry,
                        local_time,
                        now,
                        stale=False,
                        allow_current=allow_current,
                    )
                except Exception as exc:
                    # Keep the stale entry held by this request usable even if
                    # unrelated traffic evicted its key while the refresh was in
                    # flight.
                    stale_entry = self._cached_entry(key) or entry
                    if stale_entry is not None:
                        age = self._age_seconds(stale_entry.fetched_at, now)
                        if age <= self._settings.stale_max_age_seconds:
                            state = self._state_from_entry(
                                stale_entry,
                                local_time,
                                now,
                                stale=True,
                                allow_current=allow_current,
                            )
                            return state.model_copy(
                                update={
                                    "error": f"refresh_failed: {type(exc).__name__}"
                                }
                            )
                    return WeatherState(
                        error=f"weather_unavailable: {type(exc).__name__}",
                        source=source,
                    )
        finally:
            lock_entry.users -= 1
            self._trim_locks()

    async def get_history(
        self,
        site: SiteConfig,
        as_of: datetime,
        *,
        days: int = 10,
    ) -> WeatherHistoryState:
        if as_of.tzinfo is None or as_of.utcoffset() is None:
            raise ValueError("as_of must include a timezone")
        if not 1 <= days <= 31:
            raise ValueError("days must be between 1 and 31")

        now = self._clock()
        zone = ZoneInfo(site.timezone)
        local_now = now.astimezone(zone)
        local_as_of = as_of.astimezone(zone)
        requested_start = local_as_of.date() - timedelta(days=days - 1)
        end_date = local_as_of.date()
        maximum_future_days = max(
            0,
            min(
                self._settings.maximum_future_days,
                OPEN_METEO_MAX_FUTURE_OFFSET_DAYS,
            ),
        )

        if end_date < OPEN_METEO_ARCHIVE_START:
            return self._empty_history(
                site=site,
                as_of=local_as_of,
                days=days,
                generated_at=now,
                error="calculation_time_before_historical_weather_range",
            )
        if end_date > local_now.date() + timedelta(days=maximum_future_days):
            return self._empty_history(
                site=site,
                as_of=local_as_of,
                days=days,
                generated_at=now,
                error="calculation_time_outside_forecast_range",
            )

        effective_start = max(requested_start, OPEN_METEO_ARCHIVE_START)
        windows = self._history_windows(
            effective_start,
            end_date,
            local_now.date(),
        )
        results = await asyncio.gather(
            *(
                self._history_entry(site=site, window=window, now=now)
                for window in windows
            )
        )
        entries = {
            window.source: entry
            for window, (entry, _, _) in zip(windows, results)
            if entry is not None
        }
        stale_sources = {
            window.source
            for window, (_, stale, _) in zip(windows, results)
            if stale
        }
        errors = [
            error
            for _, (_, _, error) in zip(windows, results)
            if error is not None
        ]
        if requested_start < OPEN_METEO_ARCHIVE_START:
            errors.append("history_partially_before_1940")

        points: list[WeatherHistoryPoint] = []
        missing_point = False
        for offset in range(days - 1, -1, -1):
            point_date = local_as_of.date() - timedelta(days=offset)
            target = (
                local_as_of
                if offset == 0
                else self._history_target(local_as_of, point_date, zone)
            )
            window = next(
                (
                    item
                    for item in windows
                    if item.start_date <= point_date <= item.end_date
                ),
                None,
            )
            entry = entries.get(window.source) if window is not None else None
            sample = (
                self._interpolate(entry.samples, target)
                if entry is not None
                else None
            )
            if sample is None or window is None:
                missing_point = True
                points.append(WeatherHistoryPoint(valid_time=target))
                continue
            if any(
                value is None
                for value in (
                    sample.temperature_2m,
                    sample.cloud_cover,
                    sample.wind_speed,
                )
            ):
                missing_point = True
            points.append(
                WeatherHistoryPoint(
                    valid_time=target,
                    temperature_2m=sample.temperature_2m,
                    weather_code=sample.weather_code,
                    cloud_cover=sample.cloud_cover,
                    wind_speed=sample.wind_speed,
                    source=self._history_source_label(window.source),
                    data_kind=self._history_data_kind(window.source),
                    source_fetched_at=sample.source_fetched_at,
                )
            )

        if missing_point:
            errors.append("weather_history_incomplete")
        if stale_sources:
            errors.append(
                "weather_history_stale_cache:" + ",".join(sorted(stale_sources))
            )
        unique_errors = tuple(dict.fromkeys(errors))
        point_sources = {point.source for point in points if point.source != "none"}
        point_kinds = {
            point.data_kind
            for point in points
            if point.data_kind != "unavailable"
        }
        return WeatherHistoryState(
            latitude=site.latitude,
            longitude=site.longitude,
            timezone=site.timezone,
            as_of=local_as_of,
            days=days,
            generated_at=now,
            source=self._combined_history_value(point_sources),
            data_kind=self._combined_history_value(
                point_kinds,
                default="unavailable",
            ),
            points=tuple(points),
            partial=bool(unique_errors),
            error="; ".join(unique_errors) if unique_errors else None,
        )

    async def close(self) -> None:
        await self._client.close()

    async def _history_entry(
        self,
        *,
        site: SiteConfig,
        window: _HistoryWindow,
        now: datetime,
    ) -> tuple[_CacheEntry | None, bool, str | None]:
        key = (
            round(site.latitude, 4),
            round(site.longitude, 4),
            site.timezone,
            window.start_date,
            window.end_date,
            window.source,
        )
        entry = self._cached_entry(key)
        if entry is not None and self._age_seconds(entry.fetched_at, now) <= (
            self._settings.cache_ttl_seconds
        ):
            return entry, False, None

        lock_entry = self._lock_entry(key)
        lock_entry.users += 1
        try:
            async with lock_entry.lock:
                refresh_time = self._clock()
                entry = self._cached_entry(key)
                if entry is not None and self._age_seconds(
                    entry.fetched_at, refresh_time
                ) <= self._settings.cache_ttl_seconds:
                    return entry, False, None
                try:
                    payload = await self._client.fetch_hourly(
                        latitude=site.latitude,
                        longitude=site.longitude,
                        timezone=site.timezone,
                        start_date=window.start_date,
                        end_date=window.end_date,
                        source=window.source,
                    )
                    samples = self._parse_hourly(
                        payload,
                        site.timezone,
                        refresh_time,
                    )
                    if not samples:
                        raise ValueError(
                            "Open-Meteo returned no usable hourly samples"
                        )
                    entry = _CacheEntry(
                        samples=samples,
                        fetched_at=refresh_time,
                        source=window.source,
                        current=self._parse_current(
                            payload,
                            site.timezone,
                            refresh_time,
                        ),
                    )
                    self._cache[key] = entry
                    self._cache.move_to_end(key)
                    self._trim_cache()
                    return entry, False, None
                except Exception as exc:
                    stale_entry = self._cached_entry(key) or entry
                    if stale_entry is not None and self._age_seconds(
                        stale_entry.fetched_at, refresh_time
                    ) <= self._settings.stale_max_age_seconds:
                        return (
                            stale_entry,
                            True,
                            f"{window.source}_refresh_failed:{type(exc).__name__}",
                        )
                    return (
                        None,
                        False,
                        f"{window.source}_unavailable:{type(exc).__name__}",
                    )
        finally:
            lock_entry.users -= 1
            self._trim_locks()

    @staticmethod
    def _history_windows(
        start_date: date,
        end_date: date,
        current_date: date,
    ) -> tuple[_HistoryWindow, ...]:
        if start_date > end_date:
            return ()
        result: list[_HistoryWindow] = []
        archive_end = min(end_date, current_date - timedelta(days=2))
        if start_date <= archive_end:
            result.append(
                _HistoryWindow(
                    source="archive",
                    start_date=start_date,
                    end_date=archive_end,
                )
            )
        forecast_start = max(start_date, current_date - timedelta(days=1))
        if forecast_start <= end_date:
            result.append(
                _HistoryWindow(
                    source="forecast",
                    start_date=forecast_start,
                    end_date=end_date,
                )
            )
        return tuple(result)

    @staticmethod
    def _history_target(
        local_as_of: datetime,
        target_date: date,
        zone: ZoneInfo,
    ) -> datetime:
        naive = datetime.combine(target_date, local_as_of.timetz().replace(tzinfo=None))
        valid: list[datetime] = []
        for fold in (0, 1):
            candidate = naive.replace(tzinfo=zone, fold=fold)
            round_trip = candidate.astimezone(timezone.utc).astimezone(zone)
            if round_trip.replace(tzinfo=None) == naive:
                valid.append(candidate)
        if valid:
            preferred_fold = local_as_of.fold
            return next(
                (item for item in valid if item.fold == preferred_fold),
                valid[0],
            )
        # A DST spring-forward can make the requested local wall time nonexistent.
        # Resolve it forward through UTC to the first real local instant instead of
        # returning a timestamp that never occurred.
        return (
            naive.replace(tzinfo=zone, fold=0)
            .astimezone(timezone.utc)
            .astimezone(zone)
        )

    @staticmethod
    def _history_source_label(source: str) -> str:
        return {
            "archive": "open_meteo_archive",
            "forecast": "open_meteo_forecast",
        }.get(source, "none")

    @staticmethod
    def _history_data_kind(source: str) -> str:
        return {
            "archive": "model_reanalysis",
            "forecast": "forecast",
        }.get(source, "unavailable")

    @staticmethod
    def _combined_history_value(
        values: set[str],
        *,
        default: str = "none",
    ) -> str:
        if not values:
            return default
        if len(values) == 1:
            return next(iter(values))
        return "mixed"

    @staticmethod
    def _empty_history(
        *,
        site: SiteConfig,
        as_of: datetime,
        days: int,
        generated_at: datetime,
        error: str,
    ) -> WeatherHistoryState:
        return WeatherHistoryState(
            latitude=site.latitude,
            longitude=site.longitude,
            timezone=site.timezone,
            as_of=as_of,
            days=days,
            generated_at=generated_at,
            source="none",
            data_kind="unavailable",
            points=(),
            partial=True,
            error=error,
        )

    def _cached_entry(self, key: _WeatherKey) -> _CacheEntry | None:
        entry = self._cache.get(key)
        if entry is not None:
            self._cache.move_to_end(key)
        return entry

    def _lock_entry(self, key: _WeatherKey) -> _LockEntry:
        entry = self._locks.get(key)
        if entry is None:
            entry = _LockEntry(lock=asyncio.Lock())
            self._locks[key] = entry
        else:
            self._locks.move_to_end(key)
        return entry

    def _trim_cache(self) -> None:
        limit = max(1, WEATHER_CACHE_MAX_ENTRIES)
        while len(self._cache) > limit:
            self._cache.popitem(last=False)

    def _trim_locks(self) -> None:
        limit = max(1, WEATHER_LOCK_MAX_ENTRIES)
        if len(self._locks) <= limit:
            return
        for key, entry in tuple(self._locks.items()):
            if len(self._locks) <= limit:
                break
            if entry.users > 0 or entry.lock.locked():
                continue
            if self._locks.get(key) is entry:
                del self._locks[key]

    def _select_window(
        self, calculation_time: datetime, local_now: datetime
    ) -> tuple[str, date, date, str | None]:
        calculation_date = calculation_time.date()
        current_date = local_now.date()
        delta = calculation_date - current_date
        if calculation_date < OPEN_METEO_ARCHIVE_START:
            return (
                "none",
                calculation_date,
                calculation_date,
                "calculation_time_before_historical_weather_range",
            )
        maximum_future_days = max(
            0,
            min(
                self._settings.maximum_future_days,
                OPEN_METEO_MAX_FUTURE_OFFSET_DAYS,
            ),
        )
        if delta.days > maximum_future_days:
            return (
                "none",
                calculation_date,
                calculation_date,
                "calculation_time_outside_forecast_range",
            )
        if delta.days < 0:
            # A historical calculation must use a window anchored to the selected
            # date. Anchoring the range to ``local_now`` would mix the selected
            # historical state with today's forward forecast. Reuse the configured
            # prediction horizon, but never ask for weather beyond the latest date
            # that has actually been reached.
            historical_end = min(
                calculation_date
                + timedelta(days=max(1, self._settings.forecast_days) - 1),
                current_date,
            )
            return (
                "archive" if delta.days < -1 else "forecast",
                calculation_date,
                historical_end,
                None,
            )
        end = max(
            calculation_date,
            current_date + timedelta(days=self._settings.forecast_days - 1),
        )
        maximum = current_date + timedelta(days=maximum_future_days)
        return "forecast", current_date, min(end, maximum), None

    @staticmethod
    def _parse_hourly(
        payload: dict[str, Any],
        timezone_name: str,
        fetched_at: datetime,
    ) -> tuple[WeatherSample, ...]:
        hourly = payload.get("hourly")
        if not isinstance(hourly, dict):
            raise ValueError("hourly payload is missing")
        times = hourly.get("time")
        if not isinstance(times, list):
            raise ValueError("hourly time array is missing")
        zone = ZoneInfo(timezone_name)
        result: list[WeatherSample] = []
        aliases = {
            "temperature_2m": "temperature_2m",
            "weather_code": "weather_code",
            "cloud_cover": "cloud_cover",
            "cloud_cover_low": "cloud_cover_low",
            "cloud_cover_mid": "cloud_cover_mid",
            "cloud_cover_high": "cloud_cover_high",
            "visibility": "visibility",
            "wind_speed": "wind_speed_10m",
            "wind_direction": "wind_direction_10m",
            "wind_gusts": "wind_gusts_10m",
            "shortwave_radiation": "shortwave_radiation",
            "direct_normal_irradiance": "direct_normal_irradiance",
            "is_day": "is_day",
        }
        for index, raw_time in enumerate(times):
            parsed = datetime.fromisoformat(str(raw_time))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=zone)
            else:
                parsed = parsed.astimezone(zone)
            values: dict[str, Any] = {}
            for model_name, api_name in aliases.items():
                series = hourly.get(api_name)
                value = (
                    series[index]
                    if isinstance(series, list) and index < len(series)
                    else None
                )
                if model_name == "is_day" and value is not None:
                    value = bool(value)
                values[model_name] = value
            result.append(
                WeatherSample(
                    valid_time=parsed,
                    source_fetched_at=fetched_at,
                    **values,
                )
            )
        return tuple(result)

    @staticmethod
    def _parse_current(
        payload: dict[str, Any],
        timezone_name: str,
        fetched_at: datetime,
    ) -> WeatherSample | None:
        current = payload.get("current")
        if not isinstance(current, dict) or current.get("time") is None:
            return None
        zone = ZoneInfo(timezone_name)
        parsed = datetime.fromisoformat(str(current["time"]))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=zone)
        else:
            parsed = parsed.astimezone(zone)
        return WeatherSample(
            valid_time=parsed,
            temperature_2m=current.get("temperature_2m"),
            weather_code=current.get("weather_code"),
            cloud_cover=current.get("cloud_cover"),
            cloud_cover_low=current.get("cloud_cover_low"),
            cloud_cover_mid=current.get("cloud_cover_mid"),
            cloud_cover_high=current.get("cloud_cover_high"),
            visibility=current.get("visibility"),
            wind_speed=current.get("wind_speed_10m"),
            wind_direction=current.get("wind_direction_10m"),
            wind_gusts=current.get("wind_gusts_10m"),
            shortwave_radiation=current.get("shortwave_radiation"),
            direct_normal_irradiance=current.get("direct_normal_irradiance"),
            is_day=(
                bool(current["is_day"]) if current.get("is_day") is not None else None
            ),
            source_fetched_at=fetched_at,
        )

    def _state_from_entry(
        self,
        entry: _CacheEntry,
        calculation_time: datetime,
        now: datetime,
        *,
        stale: bool,
        allow_current: bool,
    ) -> WeatherState:
        use_current = (
            allow_current
            and entry.current is not None
            and abs(
                (
                    calculation_time.astimezone(timezone.utc)
                    - entry.current.valid_time.astimezone(timezone.utc)
                ).total_seconds()
            )
            <= 90 * 60
        )
        selected = (
            entry.current
            if use_current
            else self._interpolate(entry.samples, calculation_time)
        )
        if selected is None:
            return WeatherState(
                valid=False,
                hourly=entry.samples,
                stale=stale,
                cache_age_seconds=self._age_seconds(entry.fetched_at, now),
                source=entry.source,
                selection_method="none",
                source_fetched_at=entry.fetched_at,
                error="calculation_time_not_covered_by_weather_samples",
            )
        return WeatherState(
            valid=True,
            selected=selected,
            hourly=entry.samples,
            stale=stale,
            cache_age_seconds=self._age_seconds(entry.fetched_at, now),
            source=entry.source,
            selection_method=(
                "current"
                if use_current
                else self._selection_method(entry.samples, calculation_time)
            ),
            source_fetched_at=entry.fetched_at,
            error=None,
        )

    @staticmethod
    def _selection_method(
        samples: tuple[WeatherSample, ...], calculation_time: datetime
    ) -> str:
        target = calculation_time.astimezone(timezone.utc)
        sample_times = sorted(
            item.valid_time.astimezone(timezone.utc) for item in samples
        )
        if target in sample_times:
            return "hourly_exact"
        if sample_times and (target < sample_times[0] or target > sample_times[-1]):
            return "hourly_nearest_boundary"
        return "hourly_interpolated"

    @classmethod
    def _interpolate(
        cls,
        samples: tuple[WeatherSample, ...],
        calculation_time: datetime,
    ) -> WeatherSample | None:
        if not samples:
            return None
        target = calculation_time.astimezone(timezone.utc)
        ordered = sorted(samples, key=lambda item: item.valid_time)
        first_time = ordered[0].valid_time.astimezone(timezone.utc)
        last_time = ordered[-1].valid_time.astimezone(timezone.utc)
        if target < first_time:
            if first_time - target <= OPEN_METEO_HOURLY_BOUNDARY_TOLERANCE:
                return ordered[0].model_copy(
                    update={"valid_time": calculation_time}
                )
            return None
        if target > last_time:
            # Open-Meteo labels an hourly bucket with one timestamp. In
            # particular, 23:00 is the final bucket of a requested date and
            # remains the nearest available estimate through the end of that
            # hour. Keep the tolerance bounded so an old boundary sample is
            # never carried forward indefinitely.
            if target - last_time <= OPEN_METEO_HOURLY_BOUNDARY_TOLERANCE:
                return ordered[-1].model_copy(
                    update={"valid_time": calculation_time}
                )
            return None
        for sample in ordered:
            if target == sample.valid_time.astimezone(timezone.utc):
                return sample
        before: WeatherSample | None = None
        after: WeatherSample | None = None
        for sample in ordered:
            sample_time = sample.valid_time.astimezone(timezone.utc)
            if sample_time < target:
                before = sample
            elif sample_time > target:
                after = sample
                break
        if before is None or after is None:
            return before or after
        span = (
            after.valid_time.astimezone(timezone.utc)
            - before.valid_time.astimezone(timezone.utc)
        ).total_seconds()
        ratio = (
            target - before.valid_time.astimezone(timezone.utc)
        ).total_seconds() / span

        def linear(field: str) -> float | None:
            left = getattr(before, field)
            right = getattr(after, field)
            if left is None or right is None:
                return left if ratio < 0.5 else right
            return float(left + (right - left) * ratio)

        def nearest(field: str) -> Any:
            left = getattr(before, field)
            right = getattr(after, field)
            if left is None:
                return right
            if right is None:
                return left
            return left if ratio < 0.5 else right

        wind_direction = cls._circular_interpolate(
            before.wind_direction, after.wind_direction, ratio
        )
        return WeatherSample(
            valid_time=calculation_time,
            temperature_2m=linear("temperature_2m"),
            weather_code=nearest("weather_code"),
            cloud_cover=linear("cloud_cover"),
            cloud_cover_low=linear("cloud_cover_low"),
            cloud_cover_mid=linear("cloud_cover_mid"),
            cloud_cover_high=linear("cloud_cover_high"),
            visibility=linear("visibility"),
            wind_speed=linear("wind_speed"),
            wind_direction=wind_direction,
            wind_gusts=linear("wind_gusts"),
            shortwave_radiation=linear("shortwave_radiation"),
            direct_normal_irradiance=linear("direct_normal_irradiance"),
            is_day=nearest("is_day"),
            source_fetched_at=max(before.source_fetched_at, after.source_fetched_at),
        )

    @staticmethod
    def _circular_interpolate(
        start: float | None, end: float | None, ratio: float
    ) -> float | None:
        if start is None or end is None:
            return start if ratio < 0.5 else end
        delta = ((end - start + 180.0) % 360.0) - 180.0
        return (start + delta * ratio) % 360.0

    @staticmethod
    def _age_seconds(then: datetime, now: datetime) -> float:
        return max(
            0.0,
            (
                now.astimezone(timezone.utc) - then.astimezone(timezone.utc)
            ).total_seconds(),
        )
