from __future__ import annotations

import math
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from app.config import MechanicalLimits
from app.domain.common import utc_now
from app.domain.settings import SiteConfig
from app.domain.solar import SolarState


class SolarPositionService:
    """Dependency-free NOAA-style solar position approximation."""

    def __init__(self, mechanics: MechanicalLimits) -> None:
        self._mechanics = mechanics

    def calculate(
        self,
        site: SiteConfig,
        calculation_time: datetime,
        *,
        generated_at: datetime | None = None,
    ) -> SolarState:
        if calculation_time.tzinfo is None or calculation_time.utcoffset() is None:
            raise ValueError("calculation_time must include a timezone")

        calculated_at = generated_at or utc_now()
        local = calculation_time.astimezone(ZoneInfo(site.timezone))
        declination, equation_of_time = self._declination_and_equation(local)
        timezone_minutes = local.utcoffset().total_seconds() / 60.0
        clock_minutes = (
            local.hour * 60.0
            + local.minute
            + local.second / 60.0
            + local.microsecond / 60_000_000.0
        )
        true_solar_minutes = (
            clock_minutes + equation_of_time + 4.0 * site.longitude - timezone_minutes
        ) % 1440.0
        hour_angle = true_solar_minutes / 4.0 - 180.0
        if hour_angle < -180.0:
            hour_angle += 360.0

        latitude_rad = math.radians(site.latitude)
        declination_rad = math.radians(declination)
        hour_angle_rad = math.radians(hour_angle)
        sin_altitude = math.sin(latitude_rad) * math.sin(declination_rad) + math.cos(
            latitude_rad
        ) * math.cos(declination_rad) * math.cos(hour_angle_rad)
        altitude = math.degrees(math.asin(max(-1.0, min(1.0, sin_altitude))))
        azimuth = (
            math.degrees(
                math.atan2(
                    math.sin(hour_angle_rad),
                    math.cos(hour_angle_rad) * math.sin(latitude_rad)
                    - math.tan(declination_rad) * math.cos(latitude_rad),
                )
            )
            + 180.0
        ) % 360.0

        sunrise, sunset = self._sunrise_sunset(
            site=site,
            local_date=local.date(),
            declination=declination,
            equation_of_time=equation_of_time,
            timezone_minutes=timezone_minutes,
        )
        is_day = altitude > 0.0

        target_valid = is_day and self._mechanics.contains(azimuth, altitude)
        invalid_reason: str | None = None
        if not is_day:
            invalid_reason = "night"
        elif not self._mechanics.configured:
            invalid_reason = "mechanical_range_not_commissioned"
        elif not self._mechanics.contains(azimuth, altitude):
            invalid_reason = "sun_outside_mechanical_range"

        return SolarState(
            calculated_at=calculated_at,
            calculation_time=local,
            altitude=round(altitude, 4),
            azimuth=round(azimuth, 4),
            sunrise=sunrise,
            sunset=sunset,
            is_day=is_day,
            target_valid=target_valid,
            target_azimuth=round(azimuth, 4) if target_valid else None,
            target_altitude=round(altitude, 4) if target_valid else None,
            target_invalid_reason=invalid_reason,
        )

    @staticmethod
    def _declination_and_equation(at_time: datetime) -> tuple[float, float]:
        utc = at_time.astimezone(timezone.utc)
        julian_day = utc.timestamp() / 86400.0 + 2440587.5
        century = (julian_day - 2451545.0) / 36525.0
        geom_long = (280.46646 + century * (36000.76983 + century * 0.0003032)) % 360.0
        geom_anomaly = 357.52911 + century * (35999.05029 - 0.0001537 * century)
        eccentricity = 0.016708634 - century * (0.000042037 + 0.0000001267 * century)
        anomaly_rad = math.radians(geom_anomaly)
        equation_center = (
            math.sin(anomaly_rad)
            * (1.914602 - century * (0.004817 + 0.000014 * century))
            + math.sin(2 * anomaly_rad) * (0.019993 - 0.000101 * century)
            + math.sin(3 * anomaly_rad) * 0.000289
        )
        true_long = geom_long + equation_center
        omega = 125.04 - 1934.136 * century
        apparent_long = true_long - 0.00569 - 0.00478 * math.sin(math.radians(omega))
        mean_obliquity = (
            23.0
            + (
                26.0
                + (
                    21.448
                    - century * (46.815 + century * (0.00059 - century * 0.001813))
                )
                / 60.0
            )
            / 60.0
        )
        obliquity = mean_obliquity + 0.00256 * math.cos(math.radians(omega))
        declination = math.degrees(
            math.asin(
                math.sin(math.radians(obliquity))
                * math.sin(math.radians(apparent_long))
            )
        )

        y = math.tan(math.radians(obliquity) / 2.0) ** 2
        equation = 4.0 * math.degrees(
            y * math.sin(2.0 * math.radians(geom_long))
            - 2.0 * eccentricity * math.sin(anomaly_rad)
            + 4.0
            * eccentricity
            * y
            * math.sin(anomaly_rad)
            * math.cos(2.0 * math.radians(geom_long))
            - 0.5 * y * y * math.sin(4.0 * math.radians(geom_long))
            - 1.25 * eccentricity * eccentricity * math.sin(2.0 * anomaly_rad)
        )
        return declination, equation

    @staticmethod
    def _sunrise_sunset(
        *,
        site: SiteConfig,
        local_date: date,
        declination: float,
        equation_of_time: float,
        timezone_minutes: float,
    ) -> tuple[datetime | None, datetime | None]:
        latitude = math.radians(site.latitude)
        declination_rad = math.radians(declination)
        denominator = math.cos(latitude) * math.cos(declination_rad)
        if abs(denominator) < 1e-12:
            return None, None
        cosine = math.cos(math.radians(90.833)) / denominator - math.tan(
            latitude
        ) * math.tan(declination_rad)
        if cosine < -1.0 or cosine > 1.0:
            return None, None
        hour_angle = math.degrees(math.acos(cosine))
        solar_noon_minutes = (
            720.0 - 4.0 * site.longitude - equation_of_time + timezone_minutes
        )
        zone = ZoneInfo(site.timezone)
        midnight = datetime.combine(local_date, time.min, tzinfo=zone)
        sunrise = midnight + timedelta(minutes=solar_noon_minutes - 4.0 * hour_angle)
        sunset = midnight + timedelta(minutes=solar_noon_minutes + 4.0 * hour_angle)
        return sunrise, sunset
