from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.config import WeatherSettings
from app.domain.common import utc_now
from app.domain.settings import SiteConfig
from app.domain.solar import SolarState
from app.domain.thermal import ThermalGuidance
from app.domain.weather import PredictionState, WeatherSample, WeatherState
from app.services.solar_position import SolarPositionService


class ReappearancePredictor:
    def __init__(
        self,
        solar_service: SolarPositionService,
        settings: WeatherSettings,
    ) -> None:
        self._solar_service = solar_service
        self._settings = settings

    def predict(
        self,
        *,
        site: SiteConfig,
        now: datetime,
        solar: SolarState,
        weather: WeatherState,
        thermal: ThermalGuidance,
    ) -> PredictionState:
        generated = utc_now()
        if not weather.valid or weather.selected is None:
            return self._invalid(
                generated,
                weather.error or "weather_unavailable",
                weather,
                "night" if not solar.is_day else "unknown",
            )
        if weather.stale and (
            weather.cache_age_seconds is None
            or weather.cache_age_seconds > self._settings.stale_max_age_seconds
        ):
            return self._invalid(generated, "weather_too_stale", weather, "unknown")

        if not solar.is_day:
            obstruction = "night"
            camera_evidence = "solar_below_horizon"
            camera_confidence = 0.35
        else:
            obstruction, camera_evidence, camera_confidence = self._obstruction(
                thermal,
                weather.selected,
                allow_camera=site.calculation_time_override is None,
            )
        origin = now.astimezone(timezone.utc)
        candidate_upper_bound: datetime | None = None
        if (
            site.calculation_time_override is not None
            and weather.source_fetched_at is not None
            and origin < weather.source_fetched_at.astimezone(timezone.utc)
        ):
            # In retrospective mode, weather after the real fetch time is still a
            # present-day forecast. It must not leak into a result whose origin is
            # the operator-selected historical time.
            candidate_upper_bound = weather.source_fetched_at.astimezone(timezone.utc)
        candidates = sorted(
            (
                sample
                for sample in weather.hourly
                if sample.valid_time.astimezone(timezone.utc) >= origin
                and (
                    candidate_upper_bound is None
                    or sample.valid_time.astimezone(timezone.utc)
                    <= candidate_upper_bound
                )
                and self._is_clear_candidate(sample)
            ),
            key=lambda item: item.valid_time,
        )
        if not candidates:
            return self._invalid(
                generated,
                "no_reappearance_candidate_in_weather_window",
                weather,
                obstruction,
                evidence=(camera_evidence,),
            )

        candidate: WeatherSample | None = None
        predicted_solar: SolarState | None = None
        for weather_candidate in candidates:
            candidate_solar = self._solar_service.calculate(
                site, weather_candidate.valid_time, generated_at=generated
            )
            if candidate_solar.is_day:
                candidate = weather_candidate
                predicted_solar = candidate_solar
                break
        if candidate is None or predicted_solar is None:
            return self._invalid(
                generated,
                "candidate_outside_daylight",
                weather,
                obstruction,
            )

        cloud = candidate.cloud_cover if candidate.cloud_cover is not None else 100.0
        cloud_score = max(0.0, min(1.0, 1.0 - cloud / 100.0))
        dni = candidate.direct_normal_irradiance or 0.0
        radiation_score = max(0.0, min(1.0, dni / 800.0))
        freshness_score = (
            0.65
            if weather.stale
            else max(
                0.5,
                1.0
                - (weather.cache_age_seconds or 0.0)
                / max(self._settings.stale_max_age_seconds, 1.0),
            )
        )
        confidence = (
            0.35 * cloud_score
            + 0.25 * radiation_score
            + 0.2 * freshness_score
            + 0.2 * camera_confidence
        )
        confidence = round(max(0.0, min(1.0, confidence)), 3)
        if confidence < self._settings.minimum_prediction_confidence:
            return self._invalid(
                generated,
                "confidence_below_display_threshold",
                weather,
                obstruction,
                confidence=confidence,
                evidence=(camera_evidence, "weather_candidate_low_confidence"),
            )

        center = candidate.valid_time
        estimated_from = center - timedelta(minutes=30)
        estimated_to = center + timedelta(minutes=30)
        minutes = (
            center.astimezone(timezone.utc) - now.astimezone(timezone.utc)
        ).total_seconds() / 60.0
        evidence = (
            camera_evidence,
            f"cloud_cover={cloud:.1f}%",
            f"direct_normal_irradiance={dni:.1f}",
            "hourly_weather_model_estimate",
        )
        return PredictionState(
            valid=True,
            generated_at=generated,
            input_weather_time=weather.selected.valid_time,
            estimated_from=estimated_from,
            estimated_to=estimated_to,
            best_estimate=center,
            minutes_from_now=round(max(0.0, minutes), 1),
            predicted_altitude=predicted_solar.altitude,
            predicted_azimuth=predicted_solar.azimuth,
            confidence=confidence,
            evidence=evidence,
            invalid_reason=None,
            stale=weather.stale,
            current_obstruction=obstruction,
        )

    def _is_clear_candidate(self, sample: WeatherSample) -> bool:
        cloud = sample.cloud_cover
        dni = sample.direct_normal_irradiance
        return (
            cloud is not None
            and cloud <= self._settings.prediction_cloud_threshold
            and dni is not None
            and dni >= self._settings.prediction_dni_threshold
            and sample.is_day is not False
        )

    @staticmethod
    def _obstruction(
        thermal: ThermalGuidance,
        sample: WeatherSample,
        *,
        allow_camera: bool,
    ) -> tuple[str, str, float]:
        if allow_camera and thermal.valid and not thermal.stale:
            if thermal.hotspot_valid:
                return "visible", "camera_hotspot_visible", thermal.confidence
            return "obscured", "camera_reports_no_hotspot", 0.65
        if sample.cloud_cover is not None:
            obscured = sample.cloud_cover > 70.0
            return (
                "obscured" if obscured else "likely_visible",
                "camera_unavailable_weather_only",
                0.35,
            )
        return "unknown", "camera_and_cloud_state_unavailable", 0.1

    @staticmethod
    def _invalid(
        generated_at: datetime,
        reason: str,
        weather: WeatherState,
        obstruction: str,
        *,
        confidence: float = 0.0,
        evidence: tuple[str, ...] = (),
    ) -> PredictionState:
        return PredictionState(
            valid=False,
            generated_at=generated_at,
            input_weather_time=(
                weather.selected.valid_time if weather.selected else None
            ),
            confidence=confidence,
            evidence=evidence,
            invalid_reason=reason,
            stale=weather.stale,
            current_obstruction=obstruction,
        )
