from __future__ import annotations

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.application.system_orchestrator import SystemOrchestrator

router = APIRouter()


@router.websocket("/ws/v1/system")
async def system_websocket(websocket: WebSocket) -> None:
    await websocket.accept()
    runtime: SystemOrchestrator = websocket.app.state.runtime
    sequence = -1
    try:
        while True:
            snapshot = await runtime.wait_for_snapshot(
                sequence,
                timeout=runtime.settings.control.websocket_heartbeat_seconds,
            )
            await websocket.send_json(snapshot.model_dump(mode="json"))
            sequence = snapshot.sequence
    except WebSocketDisconnect:
        return
