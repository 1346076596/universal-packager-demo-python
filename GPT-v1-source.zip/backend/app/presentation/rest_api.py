from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, status
from pydantic import BaseModel, ConfigDict

from app.application.system_orchestrator import SiteUpdateRejected, SystemOrchestrator
from app.domain.commands import (
    CommandReceipt,
    ManualJogRequest,
    ModeChangeRequest,
)
from app.domain.common import AwareDatetime, utc_now
from app.domain.settings import (
    SiteConfigEnvelope,
    SiteConfigUpdate,
)
from app.domain.snapshot import ConnectionState, SystemSnapshot
from app.domain.thermal import ThermalMetadata
from app.domain.weather import PredictionState, WeatherHistoryState

router = APIRouter(prefix="/api/v1")


def get_runtime(request: Request) -> SystemOrchestrator:
    return request.app.state.runtime


RuntimeDependency = Annotated[SystemOrchestrator, Depends(get_runtime)]


class HealthResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    checked_at: AwareDatetime
    status: str
    services: ConnectionState
    simulation_active: bool


@router.get("/state", response_model=SystemSnapshot)
async def get_state(runtime: RuntimeDependency) -> SystemSnapshot:
    return runtime.snapshot


@router.get("/weather/history", response_model=WeatherHistoryState)
async def get_weather_history(
    as_of: AwareDatetime,
    runtime: RuntimeDependency,
    days: Annotated[int, Query(ge=1, le=31)] = 10,
) -> WeatherHistoryState:
    return await runtime.weather_service.get_history(
        runtime.site,
        as_of,
        days=days,
    )


@router.post("/mode", response_model=CommandReceipt)
async def post_mode(
    command: ModeChangeRequest,
    response: Response,
    runtime: RuntimeDependency,
) -> CommandReceipt:
    receipt = await runtime.request_mode(command)
    response.status_code = (
        status.HTTP_202_ACCEPTED if receipt.accepted else status.HTTP_409_CONFLICT
    )
    return receipt


@router.post("/manual-jog", response_model=CommandReceipt)
async def post_manual_jog(
    command: ManualJogRequest,
    response: Response,
    runtime: RuntimeDependency,
) -> CommandReceipt:
    receipt = await runtime.manual_jog(command)
    response.status_code = (
        status.HTTP_202_ACCEPTED if receipt.accepted else status.HTTP_409_CONFLICT
    )
    return receipt


@router.get("/site-config", response_model=SiteConfigEnvelope)
async def get_site_config(runtime: RuntimeDependency) -> SiteConfigEnvelope:
    return SiteConfigEnvelope(
        config=runtime.site,
        persisted=runtime.settings.site_config_path.exists(),
        updated_at=runtime.snapshot.generated_at,
    )


@router.put("/site-config", response_model=SiteConfigEnvelope)
async def put_site_config(
    update: SiteConfigUpdate,
    runtime: RuntimeDependency,
) -> SiteConfigEnvelope:
    try:
        config = await runtime.update_site(update)
    except SiteUpdateRejected as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    return SiteConfigEnvelope(
        config=config,
        persisted=True,
        updated_at=runtime.snapshot.generated_at,
    )


@router.get("/reappearance", response_model=PredictionState)
async def get_reappearance(runtime: RuntimeDependency) -> PredictionState:
    return runtime.snapshot.prediction


@router.get("/thermal/metadata", response_model=ThermalMetadata)
async def get_thermal_metadata(runtime: RuntimeDependency) -> ThermalMetadata:
    return runtime.snapshot.thermal


@router.get("/health", response_model=HealthResponse)
async def get_health(runtime: RuntimeDependency) -> HealthResponse:
    connections = runtime.snapshot.connections
    critical_ok = (
        connections.plc.value == "online" and connections.web.value == "online"
    )
    return HealthResponse(
        checked_at=utc_now(),
        status="ok" if critical_ok else "degraded",
        services=connections,
        simulation_active=runtime.snapshot.simulation.active,
    )
