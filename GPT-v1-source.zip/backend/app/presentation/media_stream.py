from __future__ import annotations

import asyncio
import io
from collections.abc import AsyncIterator, Callable

from fastapi import APIRouter, HTTPException, Request, status
from fastapi.responses import StreamingResponse
from PIL import Image, ImageDraw

from app.application.system_orchestrator import SystemOrchestrator
from app.infrastructure.frame_store import FrameStore

router = APIRouter()
BOUNDARY = b"solar-tracker-frame"


def make_status_jpeg(message: str) -> bytes:
    image = Image.new("RGB", (640, 480), color=(24, 28, 34))
    draw = ImageDraw.Draw(image)
    draw.rectangle((18, 190, 622, 290), outline=(220, 60, 60), width=4)
    draw.text((40, 220), message, fill=(255, 255, 255))
    draw.text(
        (40, 252),
        "STATUS FRAME ONLY - NOT A LIVE CAMERA IMAGE",
        fill=(255, 180, 80),
    )
    output = io.BytesIO()
    image.save(output, format="JPEG", quality=80)
    return output.getvalue()


def _part(jpeg: bytes, *, frame_id: int | None, status_frame: bool) -> bytes:
    headers = [
        b"--" + BOUNDARY,
        b"Content-Type: image/jpeg",
        f"Content-Length: {len(jpeg)}".encode(),
        f"X-Frame-Id: {frame_id if frame_id is not None else 'status'}".encode(),
        f"X-Status-Frame: {'true' if status_frame else 'false'}".encode(),
        b"",
        jpeg,
        b"",
    ]
    return b"\r\n".join(headers)


async def mjpeg_generator(
    store: FrameStore,
    *,
    annotated: bool,
    camera_status: Callable[[], str],
    stale_after_seconds: float,
) -> AsyncIterator[bytes]:
    last_frame_id = -1
    unchanged_seconds = 0.0
    poll = min(0.2, max(0.05, stale_after_seconds / 10.0))
    while True:
        record = store.latest()
        if record is not None and record.frame_id != last_frame_id:
            jpeg = record.annotated_jpeg if annotated else record.raw_jpeg
            yield _part(jpeg, frame_id=record.frame_id, status_frame=False)
            last_frame_id = record.frame_id
            unchanged_seconds = 0.0
        else:
            unchanged_seconds += poll
            if (
                record is None and unchanged_seconds >= 0.5
            ) or unchanged_seconds >= stale_after_seconds:
                message = (
                    f"NO LIVE FRAME: {camera_status()}"
                    if record is None
                    else f"FRAME FROZEN: id={record.frame_id}"
                )
                yield _part(
                    make_status_jpeg(message),
                    frame_id=None,
                    status_frame=True,
                )
                unchanged_seconds = 0.0
        await asyncio.sleep(poll)


def _authorize_media(request: Request, runtime: SystemOrchestrator) -> None:
    mode = runtime.settings.media_access_mode
    if mode == "trusted_network":
        return
    if mode == "bearer":
        expected = runtime.settings.media_bearer_token
        supplied = request.headers.get("authorization", "")
        if expected and supplied == f"Bearer {expected}":
            return
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="valid media bearer token required",
        )
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=(
            "media access is denied by safe default; configure authenticated "
            "access or explicitly isolated trusted_network mode"
        ),
    )


def _response(request: Request, *, annotated: bool) -> StreamingResponse:
    runtime: SystemOrchestrator = request.app.state.runtime
    _authorize_media(request, runtime)
    stream = mjpeg_generator(
        runtime.frame_store,
        annotated=annotated,
        camera_status=lambda: runtime.camera_gateway.status,
        stale_after_seconds=runtime.settings.thermal.max_frame_age_seconds,
    )
    return StreamingResponse(
        stream,
        media_type=f"multipart/x-mixed-replace; boundary={BOUNDARY.decode()}",
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
            "X-Content-Type-Options": "nosniff",
        },
    )


@router.get("/media/thermal/original.mjpeg")
async def original_stream(request: Request) -> StreamingResponse:
    return _response(request, annotated=False)


@router.get("/media/thermal/annotated.mjpeg")
async def annotated_stream(request: Request) -> StreamingResponse:
    return _response(request, annotated=True)
