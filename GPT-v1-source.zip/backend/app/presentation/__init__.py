"""FastAPI REST, WebSocket, and media adapters."""
