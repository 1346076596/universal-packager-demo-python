from __future__ import annotations

from datetime import datetime, timezone

from app.config import AppSettings
from app.domain.common import ControlMode, ServiceHealth
from app.domain.settings import SiteConfig
from app.domain.snapshot import (
    Alarm,
    ConnectionState,
    SimulationState,
    SystemSnapshot,
)
from app.domain.solar import SolarState
from app.domain.telemetry import PlcTelemetry
from app.domain.thermal import ThermalGuidance, ThermalMetadata
from app.domain.weather import PredictionState, WeatherState


class SnapshotService:
    def __init__(self, settings: AppSettings) -> None:
        self._settings = settings

    def assemble(
        self,
        *,
        generated_at: datetime,
        sequence: int,
        requested_mode: ControlMode | None,
        site: SiteConfig,
        solar: SolarState,
        weather: WeatherState,
        prediction: PredictionState,
        thermal: ThermalGuidance,
        plc: PlcTelemetry,
        camera_online: bool,
        camera_status: str,
        frame_available: bool,
        automatic_rearm_required: bool,
    ) -> SystemSnapshot:
        frame_age = max(
            0.0,
            (
                generated_at.astimezone(timezone.utc)
                - thermal.captured_at.astimezone(timezone.utc)
            ).total_seconds(),
        )
        if thermal.frame_id == 0:
            frame_age_value: float | None = None
        else:
            frame_age_value = round(frame_age, 3)
        thermal_metadata = ThermalMetadata(
            guidance=thermal,
            stream_available=frame_available and not thermal.stale,
            camera_online=camera_online,
            camera_status=camera_status,
            frame_age_seconds=frame_age_value,
            simulation_active=thermal.simulated,
            display_warning=(
                "DEVELOPMENT SIMULATION — NOT A LIVE CAMERA"
                if thermal.simulated
                else None
            ),
        )
        plc_age = (
            generated_at.astimezone(timezone.utc)
            - plc.sampled_at.astimezone(timezone.utc)
        ).total_seconds()
        plc_fresh = (
            plc.online
            and -self._settings.control.allowed_future_clock_skew_seconds
            <= plc_age
            <= self._settings.control.plc_telemetry_max_age_seconds
        )
        connections = ConnectionState(
            plc=ServiceHealth.ONLINE if plc_fresh else ServiceHealth.OFFLINE,
            camera=(ServiceHealth.ONLINE if camera_online else ServiceHealth.OFFLINE),
            thermal_algorithm=(
                ServiceHealth.DISABLED
                if not self._settings.thermal.configured
                else (ServiceHealth.ONLINE if thermal.valid else ServiceHealth.DEGRADED)
            ),
            weather=(
                ServiceHealth.OFFLINE
                if not weather.valid
                else (ServiceHealth.DEGRADED if weather.stale else ServiceHealth.ONLINE)
            ),
            prediction=(
                ServiceHealth.ONLINE if prediction.valid else ServiceHealth.DEGRADED
            ),
        )
        alarms = self._alarms(
            plc,
            weather,
            thermal,
            camera_online,
            plc_fresh=plc_fresh,
            plc_age=max(0.0, plc_age),
            calculation_preview_active=(
                site.calculation_time_override is not None
            ),
            automatic_rearm_required=automatic_rearm_required,
        )
        simulation = SimulationState(
            active=self._settings.simulation_active,
            label=(
                "DEVELOPMENT SIMULATION — NO PHYSICAL PLC/CAMERA"
                if self._settings.simulation_active
                else None
            ),
            production_fallback_allowed=False,
        )
        return SystemSnapshot(
            generated_at=generated_at,
            sequence=sequence,
            requested_mode=requested_mode,
            confirmed_mode=plc.confirmed_mode,
            mode_switch_pending=(
                requested_mode is not None and requested_mode is not plc.confirmed_mode
            ),
            site=site,
            solar=solar,
            weather=weather,
            prediction=prediction,
            thermal=thermal_metadata,
            plc=plc,
            connections=connections,
            simulation=simulation,
            alarms=alarms,
        )

    def _alarms(
        self,
        plc: PlcTelemetry,
        weather: WeatherState,
        thermal: ThermalGuidance,
        camera_online: bool,
        *,
        plc_fresh: bool,
        plc_age: float,
        calculation_preview_active: bool,
        automatic_rearm_required: bool,
    ) -> tuple[Alarm, ...]:
        alarms: list[Alarm] = []
        if calculation_preview_active:
            alarms.append(
                Alarm(
                    code="CONTROL_INHIBITED_BY_TIME_PREVIEW",
                    severity="warning",
                    message=(
                        "当前为历史/未来计算时间预览；太阳控制目标和手动动作已禁止"
                    ),
                    source="control",
                )
            )
        if automatic_rearm_required:
            alarms.append(
                Alarm(
                    code="AUTOMATIC_CONTROL_REARM_REQUIRED",
                    severity="warning",
                    message=(
                        "系统启动、站点/时间变化或控制异常后需要重新授权；"
                        "自动跟踪保持禁止，需由 PLC 确认手动且物理停稳后"
                        "重新选择"
                    ),
                    source="control",
                )
            )
        if not plc.online:
            alarms.append(
                Alarm(
                    code="PLC_OFFLINE",
                    severity="critical",
                    message="PLC 离线；所有运动命令已禁用",
                    source="plc",
                )
            )
        elif not plc_fresh:
            alarms.append(
                Alarm(
                    code="PLC_TELEMETRY_STALE",
                    severity="critical",
                    message=(
                        "PLC 位置反馈已过期，所有运动指令已禁止"
                        f"（{plc_age:.2f} 秒）"
                    ),
                    source="plc",
                )
            )
        elif not plc.safety.safety_ok:
            alarms.append(
                Alarm(
                    code="SAFETY_NOT_OK",
                    severity="critical",
                    message="PLC 安全条件不满足",
                    source="plc",
                )
            )
        for axis_name, axis in (
            ("AZIMUTH", plc.azimuth),
            ("ELEVATION", plc.elevation),
        ):
            if axis.negative_limit and axis.positive_limit:
                alarms.append(
                    Alarm(
                        code=f"{axis_name}_LIMIT_CONFLICT",
                        severity="critical",
                        message=f"{axis_name} 两端限位同时触发，轴已锁定",
                        source="plc",
                    )
                )
            elif axis.negative_limit or axis.positive_limit:
                alarms.append(
                    Alarm(
                        code=f"{axis_name}_HARD_LIMIT",
                        severity="warning",
                        message=f"{axis_name} 硬限位已触发",
                        source="plc",
                    )
                )
        if plc.confirmed_mode is ControlMode.THERMAL:
            if not camera_online:
                alarms.append(
                    Alarm(
                        code="CAMERA_OFFLINE",
                        severity="critical",
                        message="热成像相机离线；热成像动作已撤销",
                        source="camera",
                    )
                )
            elif thermal.stale:
                alarms.append(
                    Alarm(
                        code="THERMAL_FRAME_STALE",
                        severity="critical",
                        message="热成像画面冻结或过期；热成像动作已撤销",
                        source="thermal",
                    )
                )
            elif not thermal.valid:
                alarms.append(
                    Alarm(
                        code="THERMAL_GUIDANCE_INVALID",
                        severity="warning",
                        message=f"热成像指导无效：{thermal.invalid_reason}",
                        source="thermal",
                    )
                )
        if not weather.valid:
            alarms.append(
                Alarm(
                    code="WEATHER_UNAVAILABLE",
                    severity="warning",
                    message=f"天气数据不可用：{weather.error}",
                    source="weather",
                )
            )
        elif weather.stale:
            alarms.append(
                Alarm(
                    code="WEATHER_STALE",
                    severity="warning",
                    message=(
                        "正在使用过期天气缓存"
                        f"（{weather.cache_age_seconds:.0f} 秒）"
                    ),
                    source="weather",
                )
            )
        return tuple(alarms)
