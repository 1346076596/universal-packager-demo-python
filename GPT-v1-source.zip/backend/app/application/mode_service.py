from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from uuid import UUID

from app.application.permission_service import PermissionService
from app.config import AppSettings
from app.domain.commands import (
    CommandReceipt,
    CommandStatus,
    ManualDirection,
    ManualJogRequest,
    ModeChangeRequest,
)
from app.domain.common import ControlMode, utc_now
from app.domain.solar import SolarState
from app.domain.telemetry import PLC_DATA_VERSION, PlcTelemetry
from app.infrastructure.plc_gateway import PlcGateway


class ModeService:
    _MAX_RECEIPTS = 2048

    def __init__(
        self,
        gateway: PlcGateway,
        settings: AppSettings,
        permission_service: PermissionService | None = None,
    ) -> None:
        self._gateway = gateway
        self._settings = settings
        self._permissions = permission_service or PermissionService(settings)
        self._receipts: dict[UUID, CommandReceipt] = {}
        self._request_signatures: dict[UUID, tuple[str, str]] = {}
        self._manual_pending_command_id: UUID | None = None
        self._manual_pending_started_at: datetime | None = None
        self._lock = asyncio.Lock()

    async def request_mode(
        self,
        command: ModeChangeRequest,
        *,
        telemetry: PlcTelemetry,
        camera_online: bool,
        solar_control_allowed: bool = True,
        automatic_rearm_allowed: bool = True,
        mode_transition_pending: bool = False,
    ) -> CommandReceipt:
        async with self._lock:
            signature = (
                "mode_change",
                command.model_dump_json(exclude={"command_id", "issued_at"}),
            )
            duplicate = self._receipts.get(command.command_id)
            if duplicate is not None:
                if self._request_signatures.get(command.command_id) != signature:
                    return self._rejected(
                        command.command_id,
                        telemetry.confirmed_mode,
                        "command_id was reused with a different action or payload",
                        requested_mode=command.mode,
                    )
                return duplicate.model_copy(update={"duplicate": True})
            self._request_signatures[command.command_id] = signature
            reason = self._permissions.denial_reason(
                operator=command.operator,
                session_id=command.session_id,
                action="mode_change",
            )
            reason = reason or self._freshness_error(command.issued_at)
            reason = reason or self._common_control_error(telemetry)
            if self._manual_pending_command_id is not None:
                reason = reason or "a manual command is still pending"
            if mode_transition_pending:
                reason = reason or "a previous mode command is still pending"
            if not self._settings.mechanics.configured:
                reason = reason or "mechanical ranges are not commissioned"
            if command.mode is not ControlMode.MANUAL and not solar_control_allowed:
                reason = reason or (
                    "automatic control is inhibited while a calculation-time preview "
                    "override is active"
                )
            if (
                command.mode in {ControlMode.SOLAR, ControlMode.THERMAL}
                and not automatic_rearm_allowed
            ):
                reason = reason or (
                    "automatic tracking rearm requires PLC-confirmed manual mode with "
                    "both axes stopped"
                )
            if command.mode is ControlMode.THERMAL:
                if not self._settings.thermal_hardware_approved:
                    reason = reason or (
                        "thermal tracking is disabled until solar-observation "
                        "hardware approval is recorded"
                    )
                elif not self._settings.thermal.configured:
                    reason = reason or "thermal calibration is not commissioned"
                elif not camera_online:
                    reason = reason or "thermal camera is offline"
            if reason:
                return self._remember(
                    self._rejected(
                        command.command_id,
                        telemetry.confirmed_mode,
                        reason,
                        requested_mode=command.mode,
                    )
                )

            acknowledgement = await self._gateway.request_mode(command)
            if not acknowledgement.accepted:
                receipt = self._rejected(
                    command.command_id,
                    telemetry.confirmed_mode,
                    acknowledgement.reason or "PLC rejected mode request",
                    requested_mode=command.mode,
                    acknowledged_at=acknowledgement.acknowledged_at,
                )
            elif acknowledgement.completed:
                receipt = CommandReceipt(
                    command_id=command.command_id,
                    accepted=True,
                    status=CommandStatus.CONFIRMED,
                    requested_mode=command.mode,
                    confirmed_mode=command.mode,
                    acknowledged_at=acknowledgement.acknowledged_at,
                )
            else:
                receipt = CommandReceipt(
                    command_id=command.command_id,
                    accepted=True,
                    status=CommandStatus.ACCEPTED,
                    requested_mode=command.mode,
                    confirmed_mode=telemetry.confirmed_mode,
                    acknowledged_at=acknowledgement.acknowledged_at,
                    reason="waiting for PLC confirmation",
                )
            return self._remember(receipt)

    async def manual_jog(
        self,
        command: ManualJogRequest,
        *,
        telemetry: PlcTelemetry,
        solar: SolarState,
        control_time_valid: bool = True,
        mode_transition_pending: bool = False,
    ) -> CommandReceipt:
        async with self._lock:
            signature = (
                "manual_jog",
                command.model_dump_json(exclude={"command_id", "issued_at"}),
            )
            duplicate = self._receipts.get(command.command_id)
            if duplicate is not None:
                if self._request_signatures.get(command.command_id) != signature:
                    return self._rejected(
                        command.command_id,
                        telemetry.confirmed_mode,
                        "command_id was reused with a different action or payload",
                    )
                return duplicate.model_copy(update={"duplicate": True})
            self._request_signatures[command.command_id] = signature
            reason = self._permissions.denial_reason(
                operator=command.operator,
                session_id=command.session_id,
                action="manual_jog",
            )
            reason = reason or self._freshness_error(command.issued_at)
            reason = reason or self._common_control_error(telemetry)
            if not self._settings.mechanics.configured:
                reason = reason or "mechanical ranges are not commissioned"
            if telemetry.confirmed_mode is not ControlMode.MANUAL:
                reason = reason or "PLC confirmed mode is not manual"
            if not control_time_valid:
                reason = reason or (
                    "manual motion is inhibited while a calculation-time preview "
                    "override is active"
                )
            if not solar.is_day:
                reason = reason or "manual motion is disabled at night"
            if telemetry.azimuth.moving or telemetry.elevation.moving:
                reason = reason or "an axis is already moving"
            if not (
                telemetry.azimuth.motion_stopped
                and telemetry.elevation.motion_stopped
            ):
                reason = reason or "physical stopped feedback is not confirmed"
            if (
                telemetry.azimuth.fault
                or telemetry.elevation.fault
                or telemetry.azimuth.timed_out
                or telemetry.elevation.timed_out
            ):
                reason = reason or "axis feedback reports a fault or motion timeout"
            if self._manual_pending_command_id is not None:
                reason = reason or "previous manual command is still pending"
            if mode_transition_pending:
                reason = reason or "a mode command is still pending"
            if (
                command.step_degrees is not None
                and command.step_degrees
                > self._settings.control.max_manual_step_degrees
            ):
                reason = reason or "manual step exceeds configured maximum"
            if (
                command.max_duration_seconds is not None
                and command.max_duration_seconds
                > self._settings.control.max_manual_duration_seconds
            ):
                reason = reason or "manual duration exceeds configured maximum"
            reason = reason or self._direction_limit_error(command, telemetry)
            if reason:
                return self._remember(
                    self._rejected(
                        command.command_id,
                        telemetry.confirmed_mode,
                        reason,
                    )
                )

            self._manual_pending_command_id = command.command_id
            self._manual_pending_started_at = utc_now()
            try:
                acknowledgement = await self._gateway.manual_jog(command)
            except Exception:
                self._clear_manual_pending()
                raise
            if not acknowledgement.accepted or acknowledgement.completed:
                self._clear_manual_pending()
            if not acknowledgement.accepted:
                receipt = self._rejected(
                    command.command_id,
                    telemetry.confirmed_mode,
                    acknowledgement.reason or "PLC rejected manual command",
                    acknowledged_at=acknowledgement.acknowledged_at,
                )
            else:
                receipt = CommandReceipt(
                    command_id=command.command_id,
                    accepted=True,
                    status=(
                        CommandStatus.CONFIRMED
                        if acknowledgement.completed
                        else CommandStatus.ACCEPTED
                    ),
                    confirmed_mode=telemetry.confirmed_mode,
                    acknowledged_at=acknowledgement.acknowledged_at,
                    reason=(
                        None
                        if acknowledgement.completed
                        else "waiting for PLC confirmation"
                    ),
                )
            return self._remember(receipt)

    @property
    def manual_command_pending(self) -> bool:
        return self._manual_pending_command_id is not None

    def observe_telemetry(self, telemetry: PlcTelemetry) -> None:
        acknowledgement = telemetry.last_ack
        if acknowledgement is not None:
            receipt = self._receipts.get(acknowledgement.command_id)
            if receipt is not None and receipt.status is CommandStatus.ACCEPTED:
                if not acknowledgement.accepted:
                    self._receipts[acknowledgement.command_id] = self._rejected(
                        acknowledgement.command_id,
                        telemetry.confirmed_mode,
                        acknowledgement.reason or "PLC rejected pending command",
                        requested_mode=receipt.requested_mode,
                        acknowledged_at=acknowledgement.acknowledged_at,
                    )
                elif acknowledgement.completed and (
                    receipt.requested_mode is None
                    or telemetry.confirmed_mode is receipt.requested_mode
                ):
                    self._receipts[acknowledgement.command_id] = receipt.model_copy(
                        update={
                            "status": CommandStatus.CONFIRMED,
                            "confirmed_mode": telemetry.confirmed_mode,
                            "acknowledged_at": acknowledgement.acknowledged_at,
                            "reason": None,
                        }
                    )
        pending = self._manual_pending_command_id
        if pending is None:
            return
        if not telemetry.online or not telemetry.safety.safety_ok:
            self._reject_pending_receipt(
                pending,
                telemetry,
                "manual command lost PLC online/safety confirmation",
            )
            self._clear_manual_pending()
            return
        if (
            acknowledgement is not None
            and acknowledgement.command_id == pending
            and (acknowledgement.completed or not acknowledgement.accepted)
        ):
            self._clear_manual_pending()
            return
        if self._manual_pending_started_at is not None:
            age = (
                utc_now().astimezone(timezone.utc)
                - self._manual_pending_started_at.astimezone(timezone.utc)
            ).total_seconds()
            if age > self._settings.control.command_ttl_seconds:
                self._reject_pending_receipt(
                    pending,
                    telemetry,
                    "PLC manual command confirmation timed out",
                )
                self._clear_manual_pending()

    def expire_pending(
        self,
        command_id: UUID,
        telemetry: PlcTelemetry,
        reason: str,
    ) -> None:
        self._reject_pending_receipt(command_id, telemetry, reason)

    def _reject_pending_receipt(
        self,
        command_id: UUID,
        telemetry: PlcTelemetry,
        reason: str,
    ) -> None:
        receipt = self._receipts.get(command_id)
        if receipt is None or receipt.status is not CommandStatus.ACCEPTED:
            return
        self._receipts[command_id] = self._rejected(
            command_id,
            telemetry.confirmed_mode,
            reason,
            requested_mode=receipt.requested_mode,
        )

    def _clear_manual_pending(self) -> None:
        self._manual_pending_command_id = None
        self._manual_pending_started_at = None

    def _freshness_error(self, issued_at: datetime) -> str | None:
        now = utc_now()
        age = (
            now.astimezone(timezone.utc) - issued_at.astimezone(timezone.utc)
        ).total_seconds()
        if age > self._settings.control.command_ttl_seconds:
            return "command expired before execution"
        if age < -self._settings.control.allowed_future_clock_skew_seconds:
            return "command timestamp is too far in the future"
        return None

    def _common_control_error(self, telemetry: PlcTelemetry) -> str | None:
        if not telemetry.online:
            return "PLC is offline"
        if telemetry.data_version != PLC_DATA_VERSION:
            return (
                "PLC data contract mismatch: expected "
                f"v{PLC_DATA_VERSION}, received v{telemetry.data_version}"
            )
        age = (
            utc_now().astimezone(timezone.utc)
            - telemetry.sampled_at.astimezone(timezone.utc)
        ).total_seconds()
        if (
            age < -self._settings.control.allowed_future_clock_skew_seconds
            or age > self._settings.control.plc_telemetry_max_age_seconds
        ):
            return "PLC telemetry is stale"
        if not telemetry.safety.safety_ok:
            return "PLC safety conditions are not satisfied"
        if not (
            telemetry.azimuth.position_valid and telemetry.elevation.position_valid
        ):
            return "position feedback is invalid"
        if (
            telemetry.azimuth.fault
            or telemetry.elevation.fault
            or telemetry.azimuth.timed_out
            or telemetry.elevation.timed_out
        ):
            return "axis feedback reports a fault or motion timeout"
        if (
            telemetry.azimuth.negative_limit
            and telemetry.azimuth.positive_limit
        ) or (
            telemetry.elevation.negative_limit
            and telemetry.elevation.positive_limit
        ):
            return "conflicting hard-limit feedback"
        return None

    @staticmethod
    def _direction_limit_error(
        command: ManualJogRequest, telemetry: PlcTelemetry
    ) -> str | None:
        if (
            command.direction is ManualDirection.AZ_LEFT
            and telemetry.azimuth.negative_limit
        ):
            return "azimuth negative limit blocks left motion"
        if (
            command.direction is ManualDirection.AZ_RIGHT
            and telemetry.azimuth.positive_limit
        ):
            return "azimuth positive limit blocks right motion"
        if (
            command.direction is ManualDirection.ALT_DOWN
            and telemetry.elevation.negative_limit
        ):
            return "elevation negative limit blocks down motion"
        if (
            command.direction is ManualDirection.ALT_UP
            and telemetry.elevation.positive_limit
        ):
            return "elevation positive limit blocks up motion"
        return None

    def _remember(self, receipt: CommandReceipt) -> CommandReceipt:
        self._receipts[receipt.command_id] = receipt
        while len(self._receipts) > self._MAX_RECEIPTS:
            oldest_command_id = next(iter(self._receipts))
            self._receipts.pop(oldest_command_id, None)
            self._request_signatures.pop(oldest_command_id, None)
        return receipt

    @staticmethod
    def _rejected(
        command_id: UUID,
        confirmed_mode: ControlMode,
        reason: str,
        *,
        requested_mode: ControlMode | None = None,
        acknowledged_at: datetime | None = None,
    ) -> CommandReceipt:
        return CommandReceipt(
            command_id=command_id,
            accepted=False,
            status=CommandStatus.REJECTED,
            requested_mode=requested_mode,
            confirmed_mode=confirmed_mode,
            acknowledged_at=acknowledged_at,
            reason=reason,
        )
