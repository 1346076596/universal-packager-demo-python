"""Application orchestration layer."""
