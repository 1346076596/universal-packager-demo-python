from __future__ import annotations

import asyncio
import contextlib
import logging
from datetime import datetime, timezone
from uuid import UUID

from app.application.mode_service import ModeService
from app.application.permission_service import PermissionService
from app.application.snapshot_service import SnapshotService
from app.config import AppSettings
from app.domain.commands import (
    CommandReceipt,
    ManualJogRequest,
    ModeChangeRequest,
    SolarTargetCommand,
    ThermalControlCommand,
)
from app.domain.common import ControlMode, utc_now
from app.domain.settings import SiteConfig, SiteConfigUpdate
from app.domain.snapshot import SystemSnapshot
from app.domain.telemetry import (
    PLC_DATA_VERSION,
    AxisMotion,
    AxisTelemetry,
    PlcTelemetry,
)
from app.domain.thermal import ThermalGuidance
from app.domain.weather import PredictionState, WeatherState
from app.infrastructure.camera_gateway import CameraGateway
from app.infrastructure.config_repository import ConfigRepository
from app.infrastructure.frame_store import FrameRecord, FrameStore
from app.infrastructure.plc_gateway import PlcGateway
from app.services.reappearance_predictor import ReappearancePredictor
from app.services.solar_position import SolarPositionService
from app.services.thermal_tracker import ThermalTracker
from app.services.weather_service import WeatherService

logger = logging.getLogger(__name__)


class SiteUpdateRejected(RuntimeError):
    """Raised when changing the preview site could race an active PLC motion."""


class SystemOrchestrator:
    def __init__(
        self,
        *,
        settings: AppSettings,
        config_repository: ConfigRepository,
        plc_gateway: PlcGateway,
        camera_gateway: CameraGateway,
        frame_store: FrameStore,
        solar_service: SolarPositionService,
        weather_service: WeatherService,
        predictor: ReappearancePredictor,
        thermal_tracker: ThermalTracker,
        mode_service: ModeService,
        snapshot_service: SnapshotService,
        start_background_tasks: bool = True,
    ) -> None:
        self.settings = settings
        self.config_repository = config_repository
        self.plc_gateway = plc_gateway
        self.camera_gateway = camera_gateway
        self.frame_store = frame_store
        self.solar_service = solar_service
        self.weather_service = weather_service
        self.predictor = predictor
        self.thermal_tracker = thermal_tracker
        self.mode_service = mode_service
        self.permission_service = PermissionService(settings)
        self.snapshot_service = snapshot_service
        self._background_enabled = start_background_tasks
        self._tasks: list[asyncio.Task[None]] = []
        self._state_lock = asyncio.Lock()
        self._control_lock = asyncio.Lock()
        self._snapshot_condition = asyncio.Condition()
        self._started = False
        self._site_revision = 0
        self._control_transaction_active = False
        # Every process start is fail-safe: an already-running PLC must first be
        # observed in safe manual/stopped state and an automatic mode must be
        # explicitly selected. The one-shot readiness token is consumed by either
        # automatic mode and revoked as soon as safe MANUAL feedback is lost.
        self._automatic_rearm_required = True
        self._automatic_rearm_manual_ready = False
        self._automatic_rearm_command_id: UUID | None = None
        self._pending_mode_command_id: UUID | None = None
        self._pending_mode_started_at: datetime | None = None

        self.site = self.config_repository.load()
        now = utc_now()
        calculation_time = self.site.calculation_time(now)
        self.solar = self.solar_service.calculate(
            self.site, calculation_time, generated_at=now
        )
        self.control_solar = self.solar_service.calculate(
            self.site, now, generated_at=now
        )
        self.weather = WeatherState()
        self.thermal = ThermalGuidance.invalid("camera_unavailable", now=now)
        self.plc = PlcTelemetry()
        self._last_plc_heartbeat = self.plc.heartbeat
        self._last_plc_heartbeat_changed_at = now
        self.requested_mode: ControlMode | None = None
        self.prediction = PredictionState(
            generated_at=now,
            invalid_reason="prediction_not_loaded",
        )
        self._sequence = 0
        self.snapshot = self._assemble(now)

    async def start(self) -> None:
        if self._started:
            return
        await self.plc_gateway.start()
        try:
            async with self._control_lock:
                self._control_transaction_active = True
                try:
                    # Inhibit retained PLC control before publishing a valid live
                    # clock. Both the fail-safe and current time states precede the
                    # first telemetry read, so a retained IsDay value cannot permit
                    # movement during startup discovery.
                    await self.plc_gateway.send_time_state(
                        is_day=self.control_solar.is_day,
                        calculation_time_valid=False,
                    )
                    await self._invalidate_automatic_commands()
                    await self._refresh_solar()
                    await self.camera_gateway.start()
                    self._record_plc_telemetry(
                        await self.plc_gateway.read_telemetry()
                    )
                finally:
                    self._control_transaction_active = False
                await self._publish_snapshot()
        except Exception:
            with contextlib.suppress(Exception):
                await self._invalidate_automatic_commands()
            with contextlib.suppress(Exception):
                await self.camera_gateway.stop()
            with contextlib.suppress(Exception):
                await self.plc_gateway.stop()
            raise
        self._started = True
        if self._background_enabled:
            self._tasks = [
                asyncio.create_task(self._plc_loop(), name="plc-loop"),
                asyncio.create_task(self._solar_loop(), name="solar-loop"),
                asyncio.create_task(self._camera_loop(), name="camera-loop"),
                asyncio.create_task(self._weather_loop(), name="weather-loop"),
                asyncio.create_task(self._snapshot_loop(), name="snapshot-loop"),
            ]

    async def stop(self) -> None:
        for task in self._tasks:
            task.cancel()
        for task in self._tasks:
            with contextlib.suppress(asyncio.CancelledError):
                await task
        self._tasks.clear()
        await self.camera_gateway.stop()
        await self.plc_gateway.stop()
        await self.weather_service.close()
        self._started = False

    async def refresh_once(self, *, include_weather: bool = False) -> None:
        async with self._control_lock:
            self._record_plc_telemetry(
                await self.plc_gateway.read_telemetry()
            )
            await self._refresh_solar()
            weather_site = self.site
            weather_site_revision = self._site_revision

        # Weather I/O must not hold the control transaction lock. Site updates can
        # then supersede an in-flight request, and _refresh_weather will discard the
        # old result by revision instead of blocking the newer site refresh.
        if include_weather:
            await self._refresh_weather(
                site=weather_site,
                site_revision=weather_site_revision,
            )

        async with self._control_lock:
            await self._publish_snapshot()

    async def request_mode(self, command: ModeChangeRequest) -> CommandReceipt:
        async with self._control_lock:
            self._control_transaction_active = True
            try:
                receipt = await self.mode_service.request_mode(
                    command,
                    telemetry=self.plc,
                    camera_online=self.camera_gateway.online,
                    solar_control_allowed=(
                        self.site.calculation_time_override is None
                    ),
                    automatic_rearm_allowed=(
                        self._automatic_rearm_manual_ready
                    ),
                    mode_transition_pending=(
                        self._pending_mode_command_id is not None
                    ),
                )
                if receipt.accepted and not receipt.duplicate:
                    # Revoke all previous automatic guidance before reading
                    # telemetry after a mode transition. This prevents the first
                    # PLC scan in the new mode from consuming a target/frame that
                    # belonged to the previous mode or site.
                    await self._invalidate_automatic_commands()
                    self.requested_mode = command.mode
                    self._pending_mode_command_id = command.command_id
                    self._pending_mode_started_at = utc_now()
                    self._automatic_rearm_required = True
                    self._automatic_rearm_manual_ready = False
                    self._automatic_rearm_command_id = (
                        command.command_id
                        if command.mode
                        in {ControlMode.SOLAR, ControlMode.THERMAL}
                        else None
                    )
                self._record_plc_telemetry(
                    await self.plc_gateway.read_telemetry()
                )
            finally:
                self._control_transaction_active = False
            if self.plc.confirmed_mode is ControlMode.SOLAR:
                await self._send_solar_control()
            elif self.plc.confirmed_mode is ControlMode.THERMAL:
                await self._send_thermal_control(self.thermal)
            await self._publish_snapshot()
            return receipt

    async def manual_jog(self, command: ManualJogRequest) -> CommandReceipt:
        async with self._control_lock:
            self._control_transaction_active = True
            try:
                receipt = await self.mode_service.manual_jog(
                    command,
                    telemetry=self.plc,
                    solar=self.control_solar,
                    control_time_valid=(
                        self.site.calculation_time_override is None
                    ),
                    mode_transition_pending=(
                        self._pending_mode_command_id is not None
                    ),
                )
                if receipt.accepted and not receipt.duplicate:
                    self._automatic_rearm_required = True
                    self._automatic_rearm_manual_ready = False
                self._record_plc_telemetry(
                    await self.plc_gateway.read_telemetry()
                )
            finally:
                self._control_transaction_active = False
            await self._publish_snapshot()
            return receipt

    async def update_site(self, update: SiteConfigUpdate) -> SiteConfig:
        async with self._control_lock:
            self._control_transaction_active = True
            try:
                denial_reason = self.permission_service.denial_reason(
                    operator=update.operator,
                    session_id=update.session_id,
                    action="site_config_update",
                )
                if denial_reason:
                    raise SiteUpdateRejected(denial_reason)
                if self._pending_mode_command_id is not None:
                    raise SiteUpdateRejected(
                        "site/time changes are blocked while a mode command is "
                        "pending"
                    )
                if self.mode_service.manual_command_pending:
                    raise SiteUpdateRejected(
                        "site/time changes are blocked while a manual command is "
                        "pending"
                    )
                try:
                    self._record_plc_telemetry(
                        await self.plc_gateway.read_telemetry()
                    )
                except Exception as exc:
                    raise SiteUpdateRejected(
                        "site/time changes require a current PLC safety snapshot"
                    ) from exc
                if self._pending_mode_command_id is not None:
                    raise SiteUpdateRejected(
                        "site/time changes are blocked while a mode command is "
                        "pending"
                    )
                if self.mode_service.manual_command_pending:
                    raise SiteUpdateRejected(
                        "site/time changes are blocked while a manual command is "
                        "pending"
                    )
                if self.plc.online and not self._plc_is_safe_manual_stopped():
                    raise SiteUpdateRejected(
                        "site/time changes require an online PLC to be confirmed "
                        "manual with fresh valid feedback, a healthy safety chain, "
                        "and both axes stopped"
                    )
                site = update.site_config()
                self._automatic_rearm_required = True
                self._automatic_rearm_manual_ready = False
                self._automatic_rearm_command_id = None
                if self.plc.online:
                    await self._invalidate_automatic_commands()
                else:
                    with contextlib.suppress(Exception):
                        await self._invalidate_automatic_commands()
                self._pending_mode_command_id = None
                self._pending_mode_started_at = None
                self.requested_mode = (
                    self.plc.confirmed_mode if self.plc.online else None
                )
                self.config_repository.save(
                    site,
                    operator=update.operator,
                    session_id=update.session_id,
                )
                self.site = site
                self._site_revision += 1
                site_revision = self._site_revision
                self.weather = WeatherState(
                    error="refresh_pending_after_site_change"
                )
                await self._refresh_solar()
                self._automatic_rearm_manual_ready = (
                    self._plc_is_safe_manual_stopped()
                )
                await self._publish_snapshot()
                await self._refresh_weather(
                    site=site,
                    site_revision=site_revision,
                )
                await self._publish_snapshot()
                return site
            finally:
                self._control_transaction_active = False

    async def wait_for_snapshot(
        self, after_sequence: int, timeout: float
    ) -> SystemSnapshot:
        if self.snapshot.sequence > after_sequence:
            return self.snapshot
        async with self._snapshot_condition:
            with contextlib.suppress(asyncio.TimeoutError):
                await asyncio.wait_for(
                    self._snapshot_condition.wait_for(
                        lambda: self.snapshot.sequence > after_sequence
                    ),
                    timeout=timeout,
                )
        return self.snapshot

    async def _plc_loop(self) -> None:
        while True:
            try:
                async with self._control_lock:
                    self._record_plc_telemetry(
                        await self.plc_gateway.read_telemetry()
                    )
                    if self.requested_mode is not None and (
                        self.plc.confirmed_mode is self.requested_mode
                    ):
                        self.requested_mode = self.plc.confirmed_mode
                    if self.plc.confirmed_mode is ControlMode.SOLAR:
                        await self._send_solar_control()
                    await self._publish_snapshot()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("PLC telemetry loop failed")
                async with self._control_lock:
                    self._record_plc_telemetry(
                        self.plc.model_copy(update={"online": False})
                    )
                    with contextlib.suppress(Exception):
                        await self._invalidate_automatic_commands()
                    await self._publish_snapshot()
            await asyncio.sleep(self.settings.control.plc_poll_seconds)

    async def _solar_loop(self) -> None:
        while True:
            try:
                async with self._control_lock:
                    await self._refresh_solar()
                    await self._publish_snapshot()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("solar update loop failed")
            await asyncio.sleep(self.settings.control.solar_update_seconds)

    async def _camera_loop(self) -> None:
        while True:
            try:
                frame = await self.camera_gateway.read_frame()
                if frame is None:
                    latest = self.frame_store.latest()
                    guidance = self.thermal
                    if latest is None:
                        guidance = ThermalGuidance.invalid(
                            "camera_unavailable",
                            now=utc_now(),
                            stale=True,
                        )
                    elif (
                        utc_now() - latest.captured_at
                    ).total_seconds() > self.settings.thermal.max_frame_age_seconds:
                        guidance = ThermalGuidance.invalid(
                            "frame_stale",
                            frame_id=latest.frame_id,
                            captured_at=latest.captured_at,
                            now=utc_now(),
                            simulated=latest.simulated,
                        )
                    async with self._control_lock:
                        self.thermal = guidance
                        await self._send_thermal_control(self.thermal)
                        await self._publish_snapshot()
                    continue
                shape = (
                    frame.temperature.shape if frame.temperature is not None else (1, 1)
                )
                guidance = self.thermal_tracker.analyze(
                    frame.temperature,
                    frame_id=frame.frame_id,
                    captured_at=frame.captured_at,
                    simulated=frame.simulated,
                )
                annotated = self.thermal_tracker.annotate_jpeg(
                    frame.jpeg,
                    guidance,
                    thermal_width=shape[1],
                    thermal_height=shape[0],
                )
                async with self._control_lock:
                    self.frame_store.publish(
                        FrameRecord(
                            frame_id=frame.frame_id,
                            captured_at=frame.captured_at,
                            raw_jpeg=frame.jpeg,
                            annotated_jpeg=annotated,
                            guidance=guidance,
                            simulated=frame.simulated,
                        )
                    )
                    self.thermal = guidance
                    await self._send_thermal_control(guidance)
                    await self._publish_snapshot()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("camera/thermal loop failed")
                async with self._control_lock:
                    self.thermal = ThermalGuidance.invalid(
                        "thermal_processing_error",
                        now=utc_now(),
                        stale=True,
                    )
                    with contextlib.suppress(Exception):
                        await self.plc_gateway.send_thermal_guidance(
                            self._invalid_thermal_command()
                        )
                    with contextlib.suppress(Exception):
                        await self._publish_snapshot()
                await asyncio.sleep(self.settings.control.thermal_analysis_seconds)

    async def _weather_loop(self) -> None:
        while True:
            try:
                await self._refresh_weather()
                await self._publish_snapshot()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("weather loop failed")
            await asyncio.sleep(self.settings.control.weather_update_seconds)

    async def _snapshot_loop(self) -> None:
        while True:
            await asyncio.sleep(self.settings.control.snapshot_publish_seconds)
            await self._publish_snapshot()

    async def _refresh_solar(self) -> None:
        now = utc_now()
        calculation_time = self.site.calculation_time(now)
        self.solar = self.solar_service.calculate(
            self.site, calculation_time, generated_at=now
        )
        # A historical/future override is preview-only. Hardware control always uses
        # the trusted live clock and is explicitly inhibited while an override exists.
        self.control_solar = self.solar_service.calculate(
            self.site, now, generated_at=now
        )
        control_time_valid = self.site.calculation_time_override is None
        await self.plc_gateway.send_time_state(
            is_day=self.control_solar.is_day,
            calculation_time_valid=control_time_valid,
        )
        if self.plc.confirmed_mode is ControlMode.SOLAR:
            await self._send_solar_control()

    async def _send_solar_control(self) -> None:
        target_azimuth = self.control_solar.target_azimuth
        target_altitude = self.control_solar.target_altitude
        azimuth_error = self._axis_error(target_azimuth, self.plc.azimuth)
        elevation_error = self._axis_error(target_altitude, self.plc.elevation)
        feedback_fresh = self._plc_feedback_fresh()
        mode_stable = self.requested_mode in {None, ControlMode.SOLAR}
        control_time_valid = self.site.calculation_time_override is None
        command_valid = (
            control_time_valid
            and mode_stable
            and not self._control_transaction_active
            and not self._automatic_rearm_required
            and self.plc.confirmed_mode is ControlMode.SOLAR
            and self.plc.data_version == PLC_DATA_VERSION
            and self.control_solar.target_valid
            and self.plc.online
            and self.plc.safety.safety_ok
            and feedback_fresh
            and not self.plc.azimuth.timed_out
            and not self.plc.elevation.timed_out
            and not (
                self.plc.azimuth.negative_limit
                and self.plc.azimuth.positive_limit
            )
            and not (
                self.plc.elevation.negative_limit
                and self.plc.elevation.positive_limit
            )
            and azimuth_error is not None
            and elevation_error is not None
        )
        await self.plc_gateway.send_solar_target(
            SolarTargetCommand(
                valid=command_valid,
                target_azimuth=target_azimuth,
                target_altitude=target_altitude,
                azimuth_error=azimuth_error,
                elevation_error=elevation_error,
                azimuth_direction=(
                    self._axis_direction(azimuth_error, self.plc.azimuth)
                    if command_valid
                    else AxisMotion.STOPPED
                ),
                elevation_direction=(
                    self._axis_direction(elevation_error, self.plc.elevation)
                    if command_valid
                    else AxisMotion.STOPPED
                ),
                feedback_sampled_at=self.plc.sampled_at,
                feedback_fresh=feedback_fresh,
            )
        )

    def _plc_feedback_fresh(self) -> bool:
        age = (
            utc_now().astimezone(timezone.utc)
            - self.plc.sampled_at.astimezone(timezone.utc)
        ).total_seconds()
        return (
            -self.settings.control.allowed_future_clock_skew_seconds
            <= age
            <= self.settings.control.plc_telemetry_max_age_seconds
        )

    def _record_plc_telemetry(self, telemetry: PlcTelemetry) -> None:
        now = utc_now()
        if telemetry.heartbeat != self._last_plc_heartbeat:
            self._last_plc_heartbeat = telemetry.heartbeat
            self._last_plc_heartbeat_changed_at = now
        heartbeat_age = (
            now.astimezone(timezone.utc)
            - self._last_plc_heartbeat_changed_at.astimezone(timezone.utc)
        ).total_seconds()
        if (
            telemetry.online
            and heartbeat_age
            > self.settings.control.plc_heartbeat_max_stall_seconds
        ):
            telemetry = telemetry.model_copy(
                update={
                    "online": False,
                    "safety": telemetry.safety.model_copy(
                        update={
                            "communication_fault": True,
                            "fault_code": "PLC_HEARTBEAT_STALE",
                        }
                    ),
                }
            )
        self.plc = telemetry
        self.mode_service.observe_telemetry(telemetry)
        self._converge_pending_mode(now)
        if self._plc_is_safe_manual_stopped():
            self._automatic_rearm_required = True
            self._automatic_rearm_manual_ready = True
        else:
            self._automatic_rearm_manual_ready = False
            if not self._plc_control_feedback_healthy():
                # A safety/feedback interruption invalidates the pending rearm
                # command as well as active guidance. Recovery must pass through a
                # newly observed safe MANUAL/stopped state.
                self._automatic_rearm_required = True
                self._automatic_rearm_command_id = None

    def _plc_control_feedback_healthy(self) -> bool:
        return (
            self.plc.online
            and self.plc.data_version == PLC_DATA_VERSION
            and self.plc.azimuth.position_valid
            and self.plc.elevation.position_valid
            and self.plc.azimuth.actual_angle is not None
            and self.plc.elevation.actual_angle is not None
            and not self.plc.azimuth.fault
            and not self.plc.elevation.fault
            and not self.plc.azimuth.timed_out
            and not self.plc.elevation.timed_out
            and not (
                self.plc.azimuth.negative_limit
                and self.plc.azimuth.positive_limit
            )
            and not (
                self.plc.elevation.negative_limit
                and self.plc.elevation.positive_limit
            )
            and self.plc.safety.safety_ok
            and self._plc_feedback_fresh()
        )

    def _plc_is_safe_manual_stopped(self) -> bool:
        return (
            self._plc_control_feedback_healthy()
            and self.plc.confirmed_mode is ControlMode.MANUAL
            and not self.plc.azimuth.moving
            and not self.plc.elevation.moving
            and self.plc.azimuth.motion_stopped
            and self.plc.elevation.motion_stopped
            and self.plc.azimuth.direction is AxisMotion.STOPPED
            and self.plc.elevation.direction is AxisMotion.STOPPED
        )

    def _converge_pending_mode(self, now: datetime) -> None:
        pending = self._pending_mode_command_id
        requested = self.requested_mode
        if pending is None or requested is None:
            return
        acknowledgement = self.plc.last_ack
        if (
            acknowledgement is not None
            and acknowledgement.command_id == pending
            and not acknowledgement.accepted
        ):
            self.requested_mode = self.plc.confirmed_mode
            self._clear_pending_mode()
            return
        if self.plc.confirmed_mode is requested:
            if (
                requested in {ControlMode.SOLAR, ControlMode.THERMAL}
                and self._automatic_rearm_command_id == pending
            ):
                self._automatic_rearm_required = False
                self._automatic_rearm_manual_ready = False
            self.requested_mode = self.plc.confirmed_mode
            self._clear_pending_mode()
            return
        if self._pending_mode_started_at is not None:
            age = (
                now.astimezone(timezone.utc)
                - self._pending_mode_started_at.astimezone(timezone.utc)
            ).total_seconds()
            if age > self.settings.control.command_ttl_seconds:
                self.mode_service.expire_pending(
                    pending,
                    self.plc,
                    "PLC mode confirmation timed out",
                )
                self.requested_mode = self.plc.confirmed_mode
                self._clear_pending_mode()

    def _clear_pending_mode(self) -> None:
        self._pending_mode_command_id = None
        self._pending_mode_started_at = None
        self._automatic_rearm_command_id = None

    async def _invalidate_automatic_commands(self) -> None:
        await self.plc_gateway.send_solar_target(
            SolarTargetCommand(valid=False, feedback_fresh=False)
        )
        await self.plc_gateway.send_thermal_guidance(
            self._invalid_thermal_command()
        )

    @staticmethod
    def _invalid_thermal_command() -> ThermalControlCommand:
        now = utc_now()
        return ThermalControlCommand(
            image_valid=False,
            hotspot_valid=False,
            aligned=False,
            dx_normalized=0.0,
            dy_normalized=0.0,
            horizontal_direction="none",
            vertical_direction="none",
            priority_axis="none",
            confidence=0.0,
            frame_id=0,
            frame_captured_at=now,
        )

    async def _send_thermal_control(
        self, guidance: ThermalGuidance
    ) -> None:
        now = utc_now()
        frame_age = (
            now.astimezone(timezone.utc)
            - guidance.captured_at.astimezone(timezone.utc)
        ).total_seconds()
        frame_fresh = (
            -self.settings.control.allowed_future_clock_skew_seconds
            <= frame_age
            <= self.settings.thermal.max_frame_age_seconds
        )
        command_valid = (
            self.site.calculation_time_override is None
            and self.requested_mode in {None, ControlMode.THERMAL}
            and not self._control_transaction_active
            and not self._automatic_rearm_required
            and self.plc.confirmed_mode is ControlMode.THERMAL
            and self.plc.data_version == PLC_DATA_VERSION
            and self.plc.online
            and self.plc.safety.safety_ok
            and self._plc_feedback_fresh()
            and self.plc.azimuth.position_valid
            and self.plc.elevation.position_valid
            and not self.plc.azimuth.fault
            and not self.plc.elevation.fault
            and not self.plc.azimuth.timed_out
            and not self.plc.elevation.timed_out
            and not (
                self.plc.azimuth.negative_limit
                and self.plc.azimuth.positive_limit
            )
            and not (
                self.plc.elevation.negative_limit
                and self.plc.elevation.positive_limit
            )
            and self.camera_gateway.online
            and guidance.valid
            and not guidance.stale
            and guidance.hotspot_valid
            and frame_fresh
        )
        if not command_valid:
            await self.plc_gateway.send_thermal_guidance(
                self._invalid_thermal_command()
            )
            return
        await self.plc_gateway.send_thermal_guidance(
            ThermalControlCommand(
                image_valid=True,
                hotspot_valid=True,
                aligned=guidance.aligned,
                dx_normalized=guidance.dx_normalized,
                dy_normalized=guidance.dy_normalized,
                horizontal_direction=guidance.horizontal_direction.value,
                vertical_direction=guidance.vertical_direction.value,
                priority_axis=guidance.priority_axis.value,
                confidence=guidance.confidence,
                frame_id=guidance.frame_id,
                frame_captured_at=guidance.captured_at,
            )
        )

    @staticmethod
    def _axis_error(
        target: float | None, telemetry: AxisTelemetry
    ) -> float | None:
        if (
            target is None
            or telemetry.actual_angle is None
            or not telemetry.position_valid
            or telemetry.fault
        ):
            return None
        return round(target - telemetry.actual_angle, 4)

    def _axis_direction(
        self, error: float | None, telemetry: AxisTelemetry
    ) -> AxisMotion:
        if error is None or abs(error) <= (
            self.settings.control.solar_tracking_deadband_degrees
        ):
            return AxisMotion.STOPPED
        if error < 0.0:
            return (
                AxisMotion.STOPPED
                if telemetry.negative_limit
                else AxisMotion.NEGATIVE
            )
        return (
            AxisMotion.STOPPED
            if telemetry.positive_limit
            else AxisMotion.POSITIVE
        )

    async def _refresh_weather(
        self,
        *,
        site: SiteConfig | None = None,
        site_revision: int | None = None,
    ) -> None:
        target_site = site or self.site
        target_revision = (
            self._site_revision if site_revision is None else site_revision
        )
        calculation_time = target_site.calculation_time(utc_now())
        weather = await self.weather_service.get_weather(
            target_site, calculation_time
        )
        if target_revision != self._site_revision:
            logger.info(
                "Discarding weather result for superseded site revision %s",
                target_revision,
            )
            return
        self.weather = weather

    async def _publish_snapshot(self) -> None:
        async with self._state_lock:
            now = utc_now()
            calculation_time = self.site.calculation_time(now)
            self.prediction = self.predictor.predict(
                site=self.site,
                now=calculation_time,
                solar=self.solar,
                weather=self.weather,
                thermal=self.thermal,
            )
            self._sequence += 1
            self.snapshot = self._assemble(now)
        async with self._snapshot_condition:
            self._snapshot_condition.notify_all()

    def _assemble(self, now: datetime) -> SystemSnapshot:
        return self.snapshot_service.assemble(
            generated_at=now,
            sequence=self._sequence,
            requested_mode=self.requested_mode,
            site=self.site,
            solar=self.solar,
            weather=self.weather,
            prediction=self.prediction,
            thermal=self.thermal,
            plc=self.plc,
            camera_online=self.camera_gateway.online,
            camera_status=self.camera_gateway.status,
            frame_available=self.frame_store.latest() is not None,
            automatic_rearm_required=self._automatic_rearm_required,
        )
