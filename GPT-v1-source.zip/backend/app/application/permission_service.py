from __future__ import annotations

from app.config import AppSettings


class PermissionService:
    """Explicit authorization gate pending integration with a site identity provider."""

    def __init__(self, settings: AppSettings) -> None:
        self._settings = settings

    def denial_reason(
        self,
        *,
        operator: str,
        session_id: str,
        action: str,
    ) -> str | None:
        if not operator.strip() or not session_id.strip():
            return "operator and session identity are required"
        mode = self._settings.control_access_mode
        if mode == "deny":
            return (
                "control access is denied by safe default; configure authenticated "
                "operator authorization or explicitly isolated trusted_network mode"
            )
        if mode == "operator_allowlist" and (
            operator not in self._settings.allowed_control_operators
        ):
            return f"operator is not authorized for {action}"
        return None
