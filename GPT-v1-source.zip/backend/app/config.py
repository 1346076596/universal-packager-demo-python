from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from app.domain.settings import SiteConfig
from app.domain.thermal import ThermalCalibration

EnvironmentName = Literal["development", "test", "production"]
GatewayKind = Literal["unconfigured", "development_simulation"]
MediaAccessMode = Literal["deny", "trusted_network", "bearer"]
ControlAccessMode = Literal["deny", "trusted_network", "operator_allowlist"]


def _read_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be a boolean")


def _read_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    return default if raw is None else float(raw)


def _read_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    return default if raw is None else int(raw)


def _load_dotenv_if_present() -> None:
    """Load a repo-root .env file without overriding real environment variables.

    Lets local development (VS Code run button, direct uvicorn) share .env.example
    ergonomics without adding a third-party dependency. ``os.environ.setdefault`` is
    used so explicitly exported env vars and production/test configuration always win.
    """
    env_path = Path(__file__).resolve().parents[2] / ".env"
    if not env_path.is_file():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        if key:
            os.environ.setdefault(key, value)


@dataclass(frozen=True)
class MechanicalLimits:
    """Mechanics are intentionally disabled until commissioned values are supplied."""

    configured: bool = False
    azimuth_min: float = 0.0
    azimuth_max: float = 0.0
    elevation_min: float = 0.0
    elevation_max: float = 0.0
    parking_calibrated: bool = False
    parking_azimuth: float = 0.0
    parking_elevation: float = 0.0

    def __post_init__(self) -> None:
        if self.configured:
            if self.azimuth_min >= self.azimuth_max:
                raise ValueError("azimuth_min must be below azimuth_max")
            if self.elevation_min >= self.elevation_max:
                raise ValueError("elevation_min must be below elevation_max")
            if self.parking_calibrated and not (
                self.azimuth_min <= self.parking_azimuth <= self.azimuth_max
                and self.elevation_min <= self.parking_elevation <= self.elevation_max
            ):
                raise ValueError("parking angles must be inside commissioned ranges")

    def contains(self, azimuth: float, elevation: float) -> bool:
        return (
            self.configured
            and self.azimuth_min <= azimuth <= self.azimuth_max
            and self.elevation_min <= elevation <= self.elevation_max
        )


@dataclass(frozen=True)
class ControlSettings:
    command_ttl_seconds: float = 3.0
    allowed_future_clock_skew_seconds: float = 2.0
    max_manual_step_degrees: float = 2.0
    max_manual_duration_seconds: float = 2.0
    plc_poll_seconds: float = 0.25
    plc_telemetry_max_age_seconds: float = 1.0
    plc_heartbeat_max_stall_seconds: float = 3.0
    solar_tracking_deadband_degrees: float = 0.5
    snapshot_publish_seconds: float = 0.5
    solar_update_seconds: float = 1.0
    thermal_analysis_seconds: float = 0.2
    weather_update_seconds: float = 600.0
    websocket_heartbeat_seconds: float = 1.0

    def __post_init__(self) -> None:
        positive = {
            "command_ttl_seconds": self.command_ttl_seconds,
            "allowed_future_clock_skew_seconds": self.allowed_future_clock_skew_seconds,
            "max_manual_step_degrees": self.max_manual_step_degrees,
            "max_manual_duration_seconds": self.max_manual_duration_seconds,
            "plc_poll_seconds": self.plc_poll_seconds,
            "plc_telemetry_max_age_seconds": self.plc_telemetry_max_age_seconds,
            "plc_heartbeat_max_stall_seconds": self.plc_heartbeat_max_stall_seconds,
            "solar_tracking_deadband_degrees": self.solar_tracking_deadband_degrees,
            "snapshot_publish_seconds": self.snapshot_publish_seconds,
            "solar_update_seconds": self.solar_update_seconds,
            "thermal_analysis_seconds": self.thermal_analysis_seconds,
            "weather_update_seconds": self.weather_update_seconds,
            "websocket_heartbeat_seconds": self.websocket_heartbeat_seconds,
        }
        for name, value in positive.items():
            if value <= 0:
                raise ValueError(f"{name} must be positive")


@dataclass(frozen=True)
class WeatherSettings:
    timeout_seconds: float = 5.0
    cache_ttl_seconds: float = 600.0
    stale_max_age_seconds: float = 3600.0
    forecast_days: int = 7
    # Open-Meteo's 16-day forecast includes today, so the largest date offset
    # accepted by the API is today + 15 days.
    maximum_future_days: int = 15
    prediction_cloud_threshold: float = 55.0
    prediction_dni_threshold: float = 120.0
    minimum_prediction_confidence: float = 0.35


@dataclass(frozen=True)
class AppSettings:
    environment: EnvironmentName = "development"
    enable_development_simulation: bool = False
    plc_gateway_kind: GatewayKind = "unconfigured"
    camera_gateway_kind: GatewayKind = "unconfigured"
    thermal_hardware_approved: bool = False
    media_access_mode: MediaAccessMode = "deny"
    media_bearer_token: str | None = None
    control_access_mode: ControlAccessMode = "deny"
    allowed_control_operators: tuple[str, ...] = ()
    site_config_path: Path = Path("data/site_config.json")
    audit_log_path: Path = Path("data/audit.jsonl")
    default_site: SiteConfig = field(default_factory=SiteConfig)
    mechanics: MechanicalLimits = field(default_factory=MechanicalLimits)
    control: ControlSettings = field(default_factory=ControlSettings)
    weather: WeatherSettings = field(default_factory=WeatherSettings)
    thermal: ThermalCalibration = field(default_factory=ThermalCalibration)

    def __post_init__(self) -> None:
        if self.environment == "production" and (
            self.enable_development_simulation
            or self.plc_gateway_kind == "development_simulation"
            or self.camera_gateway_kind == "development_simulation"
        ):
            raise ValueError(
                "development simulation is forbidden in production; no automatic "
                "fallback is permitted"
            )
        if (
            self.plc_gateway_kind == "development_simulation"
            or self.camera_gateway_kind == "development_simulation"
        ) and not self.enable_development_simulation:
            raise ValueError(
                "development_simulation gateways require the explicit "
                "SOLAR_TRACKER_ENABLE_DEVELOPMENT_SIMULATION=true opt-in"
            )
        if self.thermal_hardware_approved and not self.thermal.configured:
            raise ValueError(
                "thermal hardware approval also requires completed thermal calibration"
            )
        if self.media_access_mode == "bearer" and not self.media_bearer_token:
            raise ValueError("bearer media access requires a non-empty token")
        if (
            self.control_access_mode == "operator_allowlist"
            and not self.allowed_control_operators
        ):
            raise ValueError(
                "operator_allowlist control access requires at least one operator"
            )

    @property
    def simulation_active(self) -> bool:
        return self.enable_development_simulation and (
            self.plc_gateway_kind == "development_simulation"
            or self.camera_gateway_kind == "development_simulation"
        )

    @classmethod
    def from_env(cls, *, base_dir: Path | None = None) -> "AppSettings":
        _load_dotenv_if_present()
        base = (base_dir or Path(__file__).resolve().parents[1]).resolve()
        environment = (
            os.getenv("SOLAR_TRACKER_ENVIRONMENT", "development").strip().lower()
        )
        if environment not in {"development", "test", "production"}:
            raise ValueError("SOLAR_TRACKER_ENVIRONMENT is invalid")

        simulation = _read_bool("SOLAR_TRACKER_ENABLE_DEVELOPMENT_SIMULATION", False)
        default_gateway = "development_simulation" if simulation else "unconfigured"
        plc_kind = (
            os.getenv("SOLAR_TRACKER_PLC_GATEWAY", default_gateway).strip().lower()
        )
        camera_kind = (
            os.getenv("SOLAR_TRACKER_CAMERA_GATEWAY", default_gateway).strip().lower()
        )
        media_access_mode = (
            os.getenv("SOLAR_TRACKER_MEDIA_ACCESS_MODE", "deny").strip().lower()
        )
        control_access_mode = (
            os.getenv("SOLAR_TRACKER_CONTROL_ACCESS_MODE", "deny").strip().lower()
        )
        if plc_kind not in {"unconfigured", "development_simulation"}:
            raise ValueError(
                "PLC protocol/mapping is not commissioned; supported gateway kinds are "
                "unconfigured and explicitly opted-in development_simulation"
            )
        if camera_kind not in {"unconfigured", "development_simulation"}:
            raise ValueError(
                "camera SDK/stream is not commissioned; supported gateway kinds are "
                "unconfigured and explicitly opted-in development_simulation"
            )
        if media_access_mode not in {"deny", "trusted_network", "bearer"}:
            raise ValueError("SOLAR_TRACKER_MEDIA_ACCESS_MODE is invalid")
        if control_access_mode not in {
            "deny",
            "trusted_network",
            "operator_allowlist",
        }:
            raise ValueError("SOLAR_TRACKER_CONTROL_ACCESS_MODE is invalid")

        mechanics = MechanicalLimits(
            configured=_read_bool("SOLAR_TRACKER_MECHANICS_CONFIGURED", False),
            azimuth_min=_read_float("SOLAR_TRACKER_AZIMUTH_MIN", 0.0),
            azimuth_max=_read_float("SOLAR_TRACKER_AZIMUTH_MAX", 0.0),
            elevation_min=_read_float("SOLAR_TRACKER_ELEVATION_MIN", 0.0),
            elevation_max=_read_float("SOLAR_TRACKER_ELEVATION_MAX", 0.0),
            parking_calibrated=_read_bool("SOLAR_TRACKER_PARKING_CALIBRATED", False),
            parking_azimuth=_read_float("SOLAR_TRACKER_PARKING_AZIMUTH", 0.0),
            parking_elevation=_read_float("SOLAR_TRACKER_PARKING_ELEVATION", 0.0),
        )
        thermal_configured = _read_bool("SOLAR_TRACKER_THERMAL_CALIBRATED", False)
        thermal = ThermalCalibration(
            configured=thermal_configured,
            center_x_normalized=_read_float("SOLAR_TRACKER_THERMAL_CENTER_X", 0.5),
            center_y_normalized=_read_float("SOLAR_TRACKER_THERMAL_CENTER_Y", 0.5),
            enter_deadband_x=_read_float(
                "SOLAR_TRACKER_THERMAL_ENTER_DEADBAND_X", 0.05
            ),
            enter_deadband_y=_read_float(
                "SOLAR_TRACKER_THERMAL_ENTER_DEADBAND_Y", 0.05
            ),
            exit_deadband_x=_read_float("SOLAR_TRACKER_THERMAL_EXIT_DEADBAND_X", 0.08),
            exit_deadband_y=_read_float("SOLAR_TRACKER_THERMAL_EXIT_DEADBAND_Y", 0.08),
            horizontal_sign=_read_int("SOLAR_TRACKER_THERMAL_HORIZONTAL_SIGN", 1),
            vertical_sign=_read_int("SOLAR_TRACKER_THERMAL_VERTICAL_SIGN", 1),
            hot_threshold=_read_float("SOLAR_TRACKER_THERMAL_HOT_THRESHOLD", 50.0),
            max_frame_age_seconds=_read_float(
                "SOLAR_TRACKER_THERMAL_MAX_FRAME_AGE_SECONDS", 2.0
            ),
        )
        control = ControlSettings(
            command_ttl_seconds=_read_float("SOLAR_TRACKER_COMMAND_TTL_SECONDS", 3.0),
            plc_telemetry_max_age_seconds=_read_float(
                "SOLAR_TRACKER_PLC_TELEMETRY_MAX_AGE_SECONDS", 1.0
            ),
            plc_heartbeat_max_stall_seconds=_read_float(
                "SOLAR_TRACKER_PLC_HEARTBEAT_MAX_STALL_SECONDS", 3.0
            ),
            solar_tracking_deadband_degrees=_read_float(
                "SOLAR_TRACKER_SOLAR_TRACKING_DEADBAND_DEGREES", 0.5
            ),
            max_manual_step_degrees=_read_float(
                "SOLAR_TRACKER_MAX_MANUAL_STEP_DEGREES", 2.0
            ),
            max_manual_duration_seconds=_read_float(
                "SOLAR_TRACKER_MAX_MANUAL_DURATION_SECONDS", 2.0
            ),
        )
        weather = WeatherSettings(
            timeout_seconds=_read_float("SOLAR_TRACKER_WEATHER_TIMEOUT_SECONDS", 5.0),
            cache_ttl_seconds=_read_float(
                "SOLAR_TRACKER_WEATHER_CACHE_TTL_SECONDS", 600.0
            ),
            stale_max_age_seconds=_read_float(
                "SOLAR_TRACKER_WEATHER_STALE_MAX_AGE_SECONDS", 3600.0
            ),
            forecast_days=_read_int("SOLAR_TRACKER_WEATHER_FORECAST_DAYS", 7),
        )

        site_path = Path(
            os.getenv(
                "SOLAR_TRACKER_SITE_CONFIG_PATH",
                str(base / "data" / "site_config.json"),
            )
        )
        audit_path = Path(
            os.getenv(
                "SOLAR_TRACKER_AUDIT_LOG_PATH",
                str(base / "data" / "audit.jsonl"),
            )
        )

        return cls(
            environment=environment,  # type: ignore[arg-type]
            enable_development_simulation=simulation,
            plc_gateway_kind=plc_kind,  # type: ignore[arg-type]
            camera_gateway_kind=camera_kind,  # type: ignore[arg-type]
            thermal_hardware_approved=_read_bool(
                "SOLAR_TRACKER_THERMAL_HARDWARE_APPROVED", False
            ),
            media_access_mode=media_access_mode,  # type: ignore[arg-type]
            media_bearer_token=os.getenv("SOLAR_TRACKER_MEDIA_BEARER_TOKEN"),
            control_access_mode=control_access_mode,  # type: ignore[arg-type]
            allowed_control_operators=tuple(
                item.strip()
                for item in os.getenv(
                    "SOLAR_TRACKER_ALLOWED_CONTROL_OPERATORS", ""
                ).split(",")
                if item.strip()
            ),
            site_config_path=site_path,
            audit_log_path=audit_path,
            mechanics=mechanics,
            control=control,
            weather=weather,
            thermal=thermal,
        )
