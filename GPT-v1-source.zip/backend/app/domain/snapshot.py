from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from .common import AwareDatetime, ControlMode, ServiceHealth
from .settings import SiteConfig
from .solar import SolarState
from .telemetry import PlcTelemetry
from .thermal import ThermalMetadata
from .weather import PredictionState, WeatherState


class Alarm(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    code: str
    severity: str
    message: str
    source: str


class ConnectionState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    web: ServiceHealth = ServiceHealth.ONLINE
    plc: ServiceHealth = ServiceHealth.OFFLINE
    camera: ServiceHealth = ServiceHealth.OFFLINE
    thermal_algorithm: ServiceHealth = ServiceHealth.DISABLED
    weather: ServiceHealth = ServiceHealth.OFFLINE
    prediction: ServiceHealth = ServiceHealth.OFFLINE


class SimulationState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    active: bool = False
    clearly_labeled: bool = True
    label: str | None = None
    production_fallback_allowed: bool = False


class SystemSnapshot(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    generated_at: AwareDatetime
    sequence: int
    requested_mode: ControlMode | None
    confirmed_mode: ControlMode
    mode_switch_pending: bool
    site: SiteConfig
    solar: SolarState
    weather: WeatherState
    prediction: PredictionState
    thermal: ThermalMetadata
    plc: PlcTelemetry
    connections: ConnectionState
    simulation: SimulationState
    alarms: tuple[Alarm, ...] = ()
