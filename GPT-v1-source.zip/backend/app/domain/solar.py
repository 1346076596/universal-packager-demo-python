from __future__ import annotations

from pydantic import BaseModel, ConfigDict

from .common import AwareDatetime


class SolarState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    calculated_at: AwareDatetime
    calculation_time: AwareDatetime
    altitude: float
    azimuth: float
    sunrise: AwareDatetime | None
    sunset: AwareDatetime | None
    is_day: bool
    target_valid: bool
    target_azimuth: float | None = None
    target_altitude: float | None = None
    target_invalid_reason: str | None = None
