from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .common import AwareDatetime, utc_now


class HorizontalDirection(str, Enum):
    LEFT = "left"
    RIGHT = "right"
    NONE = "none"


class VerticalDirection(str, Enum):
    DOWN = "down"
    UP = "up"
    NONE = "none"


class AxisPriority(str, Enum):
    AZIMUTH = "azimuth"
    ELEVATION = "elevation"
    NONE = "none"


class ThermalCalibration(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    configured: bool = False
    center_x_normalized: float = Field(default=0.5, ge=0.0, le=1.0)
    center_y_normalized: float = Field(default=0.5, ge=0.0, le=1.0)
    enter_deadband_x: float = Field(default=0.05, gt=0.0, lt=1.0)
    enter_deadband_y: float = Field(default=0.05, gt=0.0, lt=1.0)
    exit_deadband_x: float = Field(default=0.08, gt=0.0, lt=1.0)
    exit_deadband_y: float = Field(default=0.08, gt=0.0, lt=1.0)
    horizontal_sign: int = Field(default=1, ge=-1, le=1)
    vertical_sign: int = Field(default=1, ge=-1, le=1)
    hot_threshold: float = 50.0
    min_hot_pixels: int = Field(default=4, ge=1)
    saturation_temperature: float = 150.0
    max_saturation_ratio: float = Field(default=0.25, ge=0.0, le=1.0)
    minimum_confidence: float = Field(default=0.25, ge=0.0, le=1.0)
    max_frame_age_seconds: float = Field(default=2.0, gt=0.0)

    @model_validator(mode="after")
    def validate_calibration(self) -> "ThermalCalibration":
        if self.horizontal_sign not in (-1, 1) or self.vertical_sign not in (-1, 1):
            raise ValueError("thermal direction signs must be -1 or 1")
        if self.exit_deadband_x < self.enter_deadband_x:
            raise ValueError("exit_deadband_x must be >= enter_deadband_x")
        if self.exit_deadband_y < self.enter_deadband_y:
            raise ValueError("exit_deadband_y must be >= enter_deadband_y")
        return self


class ThermalGuidance(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    frame_id: int = 0
    captured_at: AwareDatetime = Field(default_factory=utc_now)
    processed_at: AwareDatetime = Field(default_factory=utc_now)
    valid: bool = False
    hotspot_valid: bool = False
    aligned: bool = False
    dx_normalized: float = 0.0
    dy_normalized: float = 0.0
    centroid_x: float | None = None
    centroid_y: float | None = None
    horizontal_direction: HorizontalDirection = HorizontalDirection.NONE
    vertical_direction: VerticalDirection = VerticalDirection.NONE
    priority_axis: AxisPriority = AxisPriority.NONE
    confidence: float = 0.0
    stale: bool = True
    invalid_reason: str | None = "camera_unavailable"
    simulated: bool = False

    @classmethod
    def invalid(
        cls,
        reason: str,
        *,
        frame_id: int = 0,
        captured_at: datetime | None = None,
        now: datetime | None = None,
        stale: bool = True,
        simulated: bool = False,
    ) -> "ThermalGuidance":
        timestamp = captured_at or now or utc_now()
        return cls(
            frame_id=frame_id,
            captured_at=timestamp,
            processed_at=now or utc_now(),
            invalid_reason=reason,
            stale=stale,
            simulated=simulated,
        )


class ThermalMetadata(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    guidance: ThermalGuidance
    original_media_url: str = "/media/thermal/original.mjpeg"
    annotated_media_url: str = "/media/thermal/annotated.mjpeg"
    stream_available: bool = False
    camera_online: bool = False
    camera_status: str = "unconfigured"
    frame_age_seconds: float | None = None
    simulation_active: bool = False
    display_warning: str | None = None
