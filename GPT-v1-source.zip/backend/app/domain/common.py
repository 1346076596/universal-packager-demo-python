from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Annotated

from pydantic import AfterValidator


class ControlMode(str, Enum):
    MANUAL = "manual"
    SOLAR = "solar"
    THERMAL = "thermal"


class ServiceHealth(str, Enum):
    ONLINE = "online"
    DEGRADED = "degraded"
    OFFLINE = "offline"
    DISABLED = "disabled"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def require_aware(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("datetime must include a timezone")
    return value


AwareDatetime = Annotated[datetime, AfterValidator(require_aware)]
