from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from .common import AwareDatetime


class WeatherSample(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    valid_time: AwareDatetime
    temperature_2m: float | None = Field(default=None, ge=-150.0, le=100.0)
    weather_code: int | None = Field(default=None, ge=0, le=99)
    cloud_cover: float | None = Field(default=None, ge=0.0, le=100.0)
    cloud_cover_low: float | None = Field(default=None, ge=0.0, le=100.0)
    cloud_cover_mid: float | None = Field(default=None, ge=0.0, le=100.0)
    cloud_cover_high: float | None = Field(default=None, ge=0.0, le=100.0)
    visibility: float | None = Field(default=None, ge=0.0)
    wind_speed: float | None = Field(default=None, ge=0.0)
    wind_direction: float | None = Field(default=None, ge=0.0, le=360.0)
    wind_gusts: float | None = Field(default=None, ge=0.0)
    shortwave_radiation: float | None = Field(default=None, ge=0.0)
    direct_normal_irradiance: float | None = Field(default=None, ge=0.0)
    is_day: bool | None = None
    source_fetched_at: AwareDatetime


class WeatherHistoryPoint(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    valid_time: AwareDatetime
    temperature_2m: float | None = Field(default=None, ge=-150.0, le=100.0)
    weather_code: int | None = Field(default=None, ge=0, le=99)
    cloud_cover: float | None = Field(default=None, ge=0.0, le=100.0)
    wind_speed: float | None = Field(default=None, ge=0.0)
    source: str = "none"
    data_kind: str = "unavailable"
    source_fetched_at: AwareDatetime | None = None


class WeatherHistoryUnits(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    temperature_2m: str = "°C"
    cloud_cover: str = "%"
    wind_speed: str = "km/h"


class WeatherHistoryState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    latitude: float = Field(ge=-90.0, le=90.0)
    longitude: float = Field(ge=-180.0, le=180.0)
    timezone: str
    as_of: AwareDatetime
    days: int = Field(ge=1, le=31)
    generated_at: AwareDatetime
    units: WeatherHistoryUnits = Field(default_factory=WeatherHistoryUnits)
    source: str = "none"
    data_kind: str = "unavailable"
    points: tuple[WeatherHistoryPoint, ...] = ()
    partial: bool = True
    error: str | None = "weather_history_not_loaded"


class WeatherState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    valid: bool = False
    selected: WeatherSample | None = None
    hourly: tuple[WeatherSample, ...] = ()
    stale: bool = False
    cache_age_seconds: float | None = None
    source: str = "none"
    selection_method: str = "none"
    source_fetched_at: AwareDatetime | None = None
    error: str | None = "weather_not_loaded"


class PredictionState(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    valid: bool = False
    generated_at: AwareDatetime
    input_weather_time: AwareDatetime | None = None
    estimated_from: AwareDatetime | None = None
    estimated_to: AwareDatetime | None = None
    best_estimate: AwareDatetime | None = None
    minutes_from_now: float | None = None
    predicted_altitude: float | None = None
    predicted_azimuth: float | None = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    evidence: tuple[str, ...] = ()
    invalid_reason: str | None = "prediction_not_loaded"
    stale: bool = False
    current_obstruction: str = "unknown"
