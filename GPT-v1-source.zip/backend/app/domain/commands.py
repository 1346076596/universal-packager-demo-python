from __future__ import annotations

from enum import Enum
from typing import Self
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .common import AwareDatetime, ControlMode, utc_now
from .telemetry import AxisMotion


class ManualDirection(str, Enum):
    AZ_LEFT = "az_left"
    AZ_RIGHT = "az_right"
    ALT_DOWN = "alt_down"
    ALT_UP = "alt_up"

    @property
    def axis(self) -> str:
        return "azimuth" if self.value.startswith("az_") else "elevation"


class CommandStatus(str, Enum):
    ACCEPTED = "accepted"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    UNCONFIRMED = "unconfirmed"


class ModeChangeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    command_id: UUID = Field(default_factory=uuid4)
    mode: ControlMode
    issued_at: AwareDatetime = Field(default_factory=utc_now)
    operator: str = Field(default="local-operator", min_length=1, max_length=128)
    session_id: str = Field(default="local-session", min_length=1, max_length=128)


class ManualJogRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    command_id: UUID = Field(default_factory=uuid4)
    direction: ManualDirection
    step_degrees: float | None = Field(default=None, gt=0)
    max_duration_seconds: float | None = Field(default=None, gt=0)
    issued_at: AwareDatetime = Field(default_factory=utc_now)
    operator: str = Field(default="local-operator", min_length=1, max_length=128)
    session_id: str = Field(default="local-session", min_length=1, max_length=128)

    @model_validator(mode="after")
    def require_exactly_one_bound(self) -> Self:
        provided = sum(
            value is not None
            for value in (self.step_degrees, self.max_duration_seconds)
        )
        if provided != 1:
            raise ValueError(
                "exactly one of step_degrees or max_duration_seconds is required"
            )
        return self


class SolarTargetCommand(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    command_id: UUID = Field(default_factory=uuid4)
    issued_at: AwareDatetime = Field(default_factory=utc_now)
    valid: bool
    target_azimuth: float | None = None
    target_altitude: float | None = None
    azimuth_error: float | None = None
    elevation_error: float | None = None
    azimuth_direction: AxisMotion = AxisMotion.STOPPED
    elevation_direction: AxisMotion = AxisMotion.STOPPED
    feedback_sampled_at: AwareDatetime | None = None
    feedback_fresh: bool = False

    @model_validator(mode="after")
    def validate_target(self) -> Self:
        if self.valid and (
            self.target_azimuth is None
            or self.target_altitude is None
            or self.azimuth_error is None
            or self.elevation_error is None
            or self.feedback_sampled_at is None
            or not self.feedback_fresh
        ):
            raise ValueError(
                "valid solar target requires angles, deviations, and fresh feedback"
            )
        return self


class ThermalControlCommand(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    command_id: UUID = Field(default_factory=uuid4)
    issued_at: AwareDatetime = Field(default_factory=utc_now)
    image_valid: bool
    hotspot_valid: bool
    aligned: bool
    dx_normalized: float
    dy_normalized: float
    horizontal_direction: str
    vertical_direction: str
    priority_axis: str
    confidence: float = Field(ge=0.0, le=1.0)
    frame_id: int = Field(ge=0)
    frame_captured_at: AwareDatetime


class CommandReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    command_id: UUID
    accepted: bool
    status: CommandStatus
    requested_mode: ControlMode | None = None
    confirmed_mode: ControlMode
    acknowledged_at: AwareDatetime | None = None
    reason: str | None = None
    duplicate: bool = False
