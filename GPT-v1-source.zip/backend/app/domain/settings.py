from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .common import AwareDatetime


class SiteConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    latitude: float = Field(default=30.25, ge=-90.0, le=90.0)
    longitude: float = Field(default=120.15, ge=-180.0, le=180.0)
    timezone: str = "Asia/Shanghai"
    calculation_time_override: AwareDatetime | None = None

    @field_validator("timezone")
    @classmethod
    def validate_timezone(cls, value: str) -> str:
        try:
            ZoneInfo(value)
        except ZoneInfoNotFoundError as exc:
            raise ValueError(f"unknown IANA timezone: {value}") from exc
        return value

    def calculation_time(self, now: datetime) -> datetime:
        if now.tzinfo is None or now.utcoffset() is None:
            raise ValueError("now must include a timezone")
        zone = ZoneInfo(self.timezone)
        selected = self.calculation_time_override or now
        return selected.astimezone(zone)


class SiteConfigUpdate(SiteConfig):
    model_config = ConfigDict(extra="forbid")

    operator: str = Field(min_length=1, max_length=128)
    session_id: str = Field(min_length=1, max_length=128)

    def site_config(self) -> SiteConfig:
        return SiteConfig(
            latitude=self.latitude,
            longitude=self.longitude,
            timezone=self.timezone,
            calculation_time_override=self.calculation_time_override,
        )


class SiteConfigEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")

    config: SiteConfig
    persisted: bool
    updated_at: AwareDatetime
