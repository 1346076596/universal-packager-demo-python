from __future__ import annotations

from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, computed_field

from .common import AwareDatetime, ControlMode, utc_now

PLC_DATA_VERSION = 3


class AxisMotion(str, Enum):
    NEGATIVE = "negative"
    POSITIVE = "positive"
    STOPPED = "stopped"


class AxisTelemetry(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    # An offline or invalid PLC must not fabricate a physical zero-angle reading.
    actual_angle: float | None = None
    negative_limit: bool = False
    positive_limit: bool = False
    moving: bool = False
    motion_stopped: bool = False
    direction: AxisMotion = AxisMotion.STOPPED
    at_target: bool = False
    timed_out: bool = False
    position_valid: bool = False
    fault: bool = False
    fault_reason: str | None = None


class SafetyTelemetry(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    emergency_stop: bool = False
    safety_chain_ok: bool = False
    communication_fault: bool = True
    position_feedback_valid: bool = False
    drive_fault: bool = False
    fault_code: str | None = "PLC_UNCONFIGURED"

    @computed_field
    @property
    def safety_ok(self) -> bool:
        return (
            not self.emergency_stop
            and self.safety_chain_ok
            and not self.communication_fault
            and self.position_feedback_valid
            and not self.drive_fault
            and self.fault_code is None
        )


class CommandAcknowledgement(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    command_id: UUID
    accepted: bool
    completed: bool
    result: str
    acknowledged_at: AwareDatetime = Field(default_factory=utc_now)
    reason: str | None = None


class PlcTelemetry(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    sampled_at: AwareDatetime = Field(default_factory=utc_now)
    online: bool = False
    heartbeat: int = 0
    data_version: int = PLC_DATA_VERSION
    confirmed_mode: ControlMode = ControlMode.MANUAL
    requested_mode: ControlMode | None = None
    running_state: str = "disabled"
    night_parked: bool = False
    azimuth: AxisTelemetry = Field(default_factory=AxisTelemetry)
    elevation: AxisTelemetry = Field(default_factory=AxisTelemetry)
    safety: SafetyTelemetry = Field(default_factory=SafetyTelemetry)
    last_ack: CommandAcknowledgement | None = None
    mode_rejection_reason: str | None = None
    simulated: bool = False
    simulation_label: str | None = None
