"""Solar tracker backend package."""
