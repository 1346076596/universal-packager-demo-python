import type {
  CommandReceipt,
  ManualJogRequest,
  ModeRequest,
  ReappearancePrediction,
  SiteConfig,
  SiteConfigEnvelope,
  SiteConfigUpdate,
  SystemSnapshot,
  ThermalState,
  WeatherHistoryResponse,
} from './contracts'

const API_BASE = (import.meta.env.VITE_API_BASE_URL || '/api/v1').replace(/\/$/, '')

export class ApiError extends Error {
  readonly status: number
  readonly detail: unknown

  constructor(message: string, status: number, detail?: unknown) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.detail = detail
  }
}

async function request<T>(
  path: string,
  init: RequestInit = {},
  timeoutMs = 8_000,
): Promise<T> {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...init.headers,
      },
      cache: 'no-store',
      signal: controller.signal,
    })
    const contentType = response.headers.get('content-type') || ''
    const detail = contentType.includes('application/json')
      ? await response.json()
      : await response.text()
    if (!response.ok) {
      const message =
        typeof detail === 'object' &&
        detail !== null &&
        'detail' in detail &&
        typeof detail.detail === 'string'
          ? detail.detail
          : `请求失败（HTTP ${response.status}）`
      throw new ApiError(message, response.status, detail)
    }
    return detail as T
  } catch (error) {
    if (error instanceof ApiError) throw error
    if (error instanceof DOMException && error.name === 'AbortError') {
      throw new ApiError('请求超时，请检查 Python 服务连接', 0)
    }
    throw new ApiError(error instanceof Error ? error.message : '网络请求失败', 0)
  } finally {
    window.clearTimeout(timeout)
  }
}

export const systemApi = {
  getState: () => request<SystemSnapshot>('/state'),
  requestMode: (payload: ModeRequest) =>
    request<CommandReceipt>('/mode', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  manualJog: (payload: ManualJogRequest) =>
    request<CommandReceipt>('/manual-jog', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getSiteConfig: async () => {
    const response = await request<SiteConfig | SiteConfigEnvelope>('/site-config')
    return 'latitude' in response ? response : response.config
  },
  updateSiteConfig: async (site: SiteConfigUpdate) => {
    const response = await request<SiteConfig | SiteConfigEnvelope>('/site-config', {
      method: 'PUT',
      body: JSON.stringify(site),
    })
    return 'latitude' in response ? response : response.config
  },
  getReappearance: () => request<ReappearancePrediction>('/reappearance'),
  getThermalMetadata: () => request<ThermalState>('/thermal/metadata'),
  getWeatherHistory: (asOf: string, days = 10) => {
    const query = new URLSearchParams({ as_of: asOf, days: String(days) })
    return request<WeatherHistoryResponse>(`/weather/history?${query.toString()}`, {}, 12_000)
  },
}
