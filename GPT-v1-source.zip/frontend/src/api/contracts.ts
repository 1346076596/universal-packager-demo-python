export type ControlMode = 'manual' | 'solar' | 'thermal'
export type AxisName = 'azimuth' | 'elevation'
export type ManualDirection = 'az_left' | 'az_right' | 'alt_down' | 'alt_up'
export type AxisDirection = 'negative' | 'positive' | 'stopped' | 'unknown'
export type Severity = 'info' | 'warning' | 'critical'
export type ServiceHealth = 'online' | 'degraded' | 'offline' | 'disabled'

export interface SiteConfig {
  latitude: number
  longitude: number
  timezone: string
  calculation_time_override: string | null
}

export interface SolarTrajectoryPoint {
  time: string
  altitude: number
  azimuth: number
}

export interface SolarState {
  calculated_at: string
  calculation_time: string
  is_day: boolean
  altitude: number
  azimuth: number
  sunrise: string | null
  sunset: string | null
  target_valid: boolean
  target_azimuth: number | null
  target_altitude: number | null
  target_invalid_reason: string | null
  trajectory?: SolarTrajectoryPoint[]
}

export interface WeatherSample {
  valid_time: string
  weather_code: number | null
  temperature_2m: number | null
  cloud_cover: number | null
  cloud_cover_low: number | null
  cloud_cover_mid: number | null
  cloud_cover_high: number | null
  visibility: number | null
  wind_speed: number | null
  wind_direction: number | null
  wind_gusts: number | null
  shortwave_radiation: number | null
  direct_normal_irradiance: number | null
  is_day: boolean | null
  source_fetched_at: string
}

export interface WeatherHistoryPoint {
  valid_time: string
  cloud_cover: number | null
  wind_speed: number | null
  temperature_2m: number | null
  weather_code: number | null
  source: string
  data_kind: string
  source_fetched_at: string | null
}

export interface WeatherHistoryResponse {
  latitude: number
  longitude: number
  timezone: string
  as_of: string
  days: number
  generated_at: string
  units: {
    cloud_cover: '%'
    wind_speed: 'km/h'
    temperature_2m: '°C'
  }
  source: string
  data_kind: string
  points: WeatherHistoryPoint[]
  partial: boolean
  error: string | null
}

export interface WeatherState {
  valid: boolean
  selected: WeatherSample | null
  hourly: WeatherSample[]
  stale: boolean
  cache_age_seconds: number | null
  source: string
  source_fetched_at: string | null
  error: string | null
}

export interface ReappearancePrediction {
  valid: boolean
  generated_at: string | null
  input_weather_time: string | null
  estimated_from: string | null
  estimated_to: string | null
  best_estimate: string | null
  minutes_from_now: number | null
  predicted_altitude: number | null
  predicted_azimuth: number | null
  confidence: number
  evidence: string[]
  invalid_reason: string | null
  stale: boolean
  current_obstruction: string
}

export interface ThermalGuidance {
  frame_id: number
  captured_at: string
  processed_at: string
  valid: boolean
  hotspot_valid: boolean
  aligned: boolean
  dx_normalized: number
  dy_normalized: number
  centroid_x: number | null
  centroid_y: number | null
  horizontal_direction: 'left' | 'right' | 'none'
  vertical_direction: 'down' | 'up' | 'none'
  priority_axis: AxisName | 'none'
  confidence: number
  stale: boolean
  invalid_reason: string | null
  simulated: boolean
}

export interface ThermalState {
  guidance: ThermalGuidance
  original_media_url: string
  annotated_media_url: string
  stream_available: boolean
  camera_online: boolean
  camera_status: string
  frame_age_seconds: number | null
  simulation_active: boolean
  display_warning: string | null
}

export interface AxisTelemetry {
  actual_angle: number | null
  negative_limit: boolean
  positive_limit: boolean
  moving: boolean
  motion_stopped: boolean
  direction: AxisDirection | string
  at_target: boolean
  timed_out: boolean
  position_valid: boolean
  fault: boolean
  fault_reason: string | null
}

export interface PlcSafetyState {
  safety_ok: boolean
  emergency_stop: boolean
  safety_chain_ok: boolean
  communication_fault: boolean
  position_feedback_valid: boolean
  drive_fault: boolean
  fault_code: string | null
}

export interface CommandAcknowledgement {
  command_id: string
  accepted: boolean
  completed: boolean
  result: string
  acknowledged_at: string
  reason: string | null
}

export interface PlcState {
  sampled_at: string
  online: boolean
  heartbeat: number
  data_version: number
  confirmed_mode: ControlMode
  requested_mode: ControlMode | null
  running_state: string
  night_parked: boolean
  azimuth: AxisTelemetry
  elevation: AxisTelemetry
  safety: PlcSafetyState
  last_ack: CommandAcknowledgement | null
  mode_rejection_reason: string | null
  simulated: boolean
  simulation_label: string | null
}

export interface ConnectionState {
  web: ServiceHealth
  plc: ServiceHealth
  camera: ServiceHealth
  thermal_algorithm: ServiceHealth
  weather: ServiceHealth
  prediction: ServiceHealth
}

export interface Alarm {
  code: string
  severity: Severity
  message: string
  source: string
}

export interface SimulationState {
  active: boolean
  clearly_labeled: boolean
  label: string | null
  production_fallback_allowed: boolean
}

export interface SystemSnapshot {
  generated_at: string
  sequence: number
  requested_mode: ControlMode | null
  confirmed_mode: ControlMode
  mode_switch_pending: boolean
  site: SiteConfig
  solar: SolarState
  weather: WeatherState
  prediction: ReappearancePrediction
  thermal: ThermalState
  plc: PlcState
  connections: ConnectionState
  simulation: SimulationState
  alarms: Alarm[]
}

export interface ModeRequest {
  mode: ControlMode
  command_id: string
  issued_at: string
  operator: string
  session_id: string
}

export type CommandStatus = 'accepted' | 'confirmed' | 'rejected' | 'unconfirmed'

export interface CommandReceipt {
  command_id: string
  accepted: boolean
  status: CommandStatus
  requested_mode: ControlMode | null
  confirmed_mode: ControlMode
  acknowledged_at: string | null
  reason: string | null
  duplicate: boolean
}

export interface ManualJogRequest {
  command_id: string
  direction: ManualDirection
  step_degrees?: number
  max_duration_seconds?: number
  issued_at: string
  operator: string
  session_id: string
}

export interface SiteConfigUpdate extends SiteConfig {
  operator: string
  session_id: string
}

export interface SiteConfigEnvelope {
  config: SiteConfig
  persisted: boolean
  updated_at: string
}

export type SystemSocketMessage =
  | SystemSnapshot
  | { type: 'snapshot'; data: SystemSnapshot }
  | { type: 'system_snapshot'; payload: SystemSnapshot }

export function isSystemSnapshot(value: unknown): value is SystemSnapshot {
  if (!value || typeof value !== 'object') return false
  const candidate = value as Partial<SystemSnapshot>
  return (
    typeof candidate.sequence === 'number' &&
    typeof candidate.generated_at === 'string' &&
    typeof candidate.confirmed_mode === 'string' &&
    (candidate.requested_mode === null ||
      typeof candidate.requested_mode === 'string')
  )
}

export function unwrapSystemSnapshot(value: unknown): SystemSnapshot | null {
  if (isSystemSnapshot(value)) return value
  if (!value || typeof value !== 'object') return null
  const wrapped = value as {
    type?: string
    data?: unknown
    payload?: unknown
  }
  if (isSystemSnapshot(wrapped.data)) return wrapped.data
  if (isSystemSnapshot(wrapped.payload)) return wrapped.payload
  return null
}
