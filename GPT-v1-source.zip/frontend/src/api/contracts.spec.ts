import { describe, expect, it } from 'vitest'
import { unwrapSystemSnapshot } from './contracts'
import { makeSnapshot } from '../test/fixtures'

describe('SystemSnapshot 契约', () => {
  it('接受后端实际 JSON 的直接快照', () => {
    const snapshot = makeSnapshot()
    expect(unwrapSystemSnapshot(snapshot)).toBe(snapshot)
  })

  it('接受尚未请求模式时 requested_mode 为 null 的初始快照', () => {
    const snapshot = makeSnapshot({ requested_mode: null })
    expect(unwrapSystemSnapshot(snapshot)).toBe(snapshot)
  })

  it('兼容 WebSocket 的 data 与 payload 包装', () => {
    const snapshot = makeSnapshot()
    expect(unwrapSystemSnapshot({ type: 'snapshot', data: snapshot })).toBe(
      snapshot,
    )
    expect(
      unwrapSystemSnapshot({ type: 'system_snapshot', payload: snapshot }),
    ).toBe(snapshot)
  })

  it('拒绝缺少序列号的非契约消息', () => {
    expect(unwrapSystemSnapshot({ generated_at: new Date().toISOString() })).toBe(
      null,
    )
  })
})
