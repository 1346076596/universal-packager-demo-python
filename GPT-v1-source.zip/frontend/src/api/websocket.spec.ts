import { afterEach, describe, expect, it, vi } from 'vitest'
import { connectSystemSocket } from './websocket'

class FakeWebSocket extends EventTarget {
  static instances: FakeWebSocket[] = []
  readonly url: string

  constructor(url: string) {
    super()
    this.url = url
    FakeWebSocket.instances.push(this)
  }

  close(): void {
    this.dispatchEvent(new Event('close'))
  }
}

describe('WebSocket 重连', () => {
  afterEach(() => {
    vi.useRealTimers()
    vi.restoreAllMocks()
    FakeWebSocket.instances = []
  })

  it('断线后指数退避重连并上报状态', () => {
    vi.useFakeTimers()
    vi.spyOn(Math, 'random').mockReturnValue(0)
    vi.stubGlobal('WebSocket', FakeWebSocket)
    const states: Array<[string, number]> = []
    const connection = connectSystemSocket(
      {
        onMessage: vi.fn(),
        onStatus: (status, attempt) => states.push([status, attempt]),
      },
      'ws://localhost/ws/v1/system',
    )

    expect(FakeWebSocket.instances).toHaveLength(1)
    FakeWebSocket.instances[0]?.dispatchEvent(new Event('close'))
    expect(states.at(-1)).toEqual(['reconnecting', 1])

    vi.advanceTimersByTime(750)
    expect(FakeWebSocket.instances).toHaveLength(2)
    FakeWebSocket.instances[1]?.dispatchEvent(new Event('open'))
    expect(states.at(-1)).toEqual(['online', 0])

    connection.close()
    expect(states.at(-1)?.[0]).toBe('offline')
  })
})
