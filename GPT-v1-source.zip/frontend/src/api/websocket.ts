export type SocketStatus = 'connecting' | 'online' | 'reconnecting' | 'offline'

export interface SocketHandlers {
  onMessage: (message: unknown) => void
  onStatus: (status: SocketStatus, attempt: number) => void
  onError?: (message: string) => void
}

export interface SystemSocket {
  close: () => void
}

function defaultSocketUrl(): string {
  if (import.meta.env.VITE_WS_URL) return import.meta.env.VITE_WS_URL
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  return `${protocol}//${window.location.host}/ws/v1/system`
}

export function connectSystemSocket(
  handlers: SocketHandlers,
  url = defaultSocketUrl(),
): SystemSocket {
  let socket: WebSocket | null = null
  let reconnectTimer: number | null = null
  let attempt = 0
  let closed = false

  const scheduleReconnect = () => {
    if (closed) return
    attempt += 1
    handlers.onStatus('reconnecting', attempt)
    const base = Math.min(750 * 2 ** Math.max(0, attempt - 1), 15_000)
    const jitter = Math.round(base * 0.15 * Math.random())
    reconnectTimer = window.setTimeout(open, base + jitter)
  }

  const open = () => {
    if (closed) return
    handlers.onStatus(attempt === 0 ? 'connecting' : 'reconnecting', attempt)
    try {
      socket = new WebSocket(url)
    } catch (error) {
      handlers.onError?.(error instanceof Error ? error.message : 'WebSocket 创建失败')
      scheduleReconnect()
      return
    }

    socket.addEventListener('open', () => {
      attempt = 0
      handlers.onStatus('online', 0)
    })
    socket.addEventListener('message', (event) => {
      try {
        handlers.onMessage(JSON.parse(String(event.data)))
      } catch {
        handlers.onError?.('收到无法解析的状态消息')
      }
    })
    socket.addEventListener('error', () => {
      handlers.onError?.('实时状态连接发生错误')
    })
    socket.addEventListener('close', () => {
      socket = null
      scheduleReconnect()
    })
  }

  open()

  return {
    close() {
      closed = true
      handlers.onStatus('offline', attempt)
      if (reconnectTimer !== null) window.clearTimeout(reconnectTimer)
      socket?.close()
      socket = null
    },
  }
}
