const WEATHER_CODE_LABELS: Readonly<Record<number, string>> = {
  0: '晴',
  1: '主要晴朗',
  2: '局部多云',
  3: '阴',
  45: '雾',
  48: '雾凇',
  51: '小毛毛雨',
  53: '中等毛毛雨',
  55: '强毛毛雨',
  56: '轻度冻毛毛雨',
  57: '强冻毛毛雨',
  61: '小雨',
  63: '中雨',
  65: '大雨',
  66: '轻度冻雨',
  67: '强冻雨',
  71: '小雪',
  73: '中雪',
  75: '大雪',
  77: '雪粒',
  80: '小阵雨',
  81: '中等阵雨',
  82: '强阵雨',
  85: '小阵雪',
  86: '强阵雪',
  95: '雷暴',
  96: '雷暴伴小冰雹',
  99: '雷暴伴大冰雹',
}

export function formatWeatherCode(
  weatherCode: number | null | undefined,
): string {
  if (!Number.isInteger(weatherCode)) return '未知'
  return WEATHER_CODE_LABELS[Number(weatherCode)] ?? '未知'
}
