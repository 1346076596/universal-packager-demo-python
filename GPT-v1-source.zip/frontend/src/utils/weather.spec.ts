import { describe, expect, it } from 'vitest'
import { formatWeatherCode } from './weather'

describe('formatWeatherCode', () => {
  it.each([
    [0, '晴'],
    [1, '主要晴朗'],
    [2, '局部多云'],
    [3, '阴'],
    [45, '雾'],
    [48, '雾凇'],
    [53, '中等毛毛雨'],
    [57, '强冻毛毛雨'],
    [63, '中雨'],
    [67, '强冻雨'],
    [75, '大雪'],
    [77, '雪粒'],
    [81, '中等阵雨'],
    [86, '强阵雪'],
    [95, '雷暴'],
    [99, '雷暴伴大冰雹'],
  ])('将 WMO 天气码 %i 映射为 %s', (code, expected) => {
    expect(formatWeatherCode(code)).toBe(expected)
  })

  it.each([null, undefined, -1, 4, 999, Number.NaN])(
    '未知或缺失的天气码 %s 显示为未知',
    (code) => {
      expect(formatWeatherCode(code)).toBe('未知')
    },
  )
})
