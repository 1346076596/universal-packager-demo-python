export function formatAngle(value: number | null | undefined, digits = 1): string {
  return Number.isFinite(value) ? `${Number(value).toFixed(digits)}°` : '—'
}

export function formatPercent(value: number | null | undefined): string {
  if (!Number.isFinite(value)) return '—'
  return `${Math.round(Number(value))}%`
}

export function formatRatioPercent(value: number | null | undefined): string {
  if (!Number.isFinite(value)) return '—'
  return `${Math.round(Number(value) * 100)}%`
}

export function formatTimestamp(
  value: string | null | undefined,
  timezone?: string,
): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return '—'
  try {
    return new Intl.DateTimeFormat('zh-CN', {
      timeZone: timezone,
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    }).format(date)
  } catch {
    return date.toLocaleString('zh-CN', { hour12: false })
  }
}

export function secondsSince(value: string | null | undefined, now = Date.now()): number {
  if (!value) return Number.POSITIVE_INFINITY
  const timestamp = new Date(value).getTime()
  if (!Number.isFinite(timestamp)) return Number.POSITIVE_INFINITY
  return Math.max(0, Math.floor((now - timestamp) / 1_000))
}

export function formatAge(seconds: number): string {
  if (!Number.isFinite(seconds)) return '无时间戳'
  if (seconds < 2) return '刚刚'
  if (seconds < 60) return `${seconds} 秒前`
  if (seconds < 3_600) return `${Math.floor(seconds / 60)} 分钟前`
  return `${Math.floor(seconds / 3_600)} 小时前`
}

export function formatCountdown(
  target: string | null | undefined,
  now = Date.now(),
): string {
  if (!target) return '—'
  const milliseconds = new Date(target).getTime() - now
  if (!Number.isFinite(milliseconds)) return '—'
  if (milliseconds <= 0) return '预计时间已到'
  const totalMinutes = Math.ceil(milliseconds / 60_000)
  const hours = Math.floor(totalMinutes / 60)
  const minutes = totalMinutes % 60
  return hours > 0 ? `${hours} 小时 ${minutes} 分` : `${minutes} 分钟`
}

export function makeCommandId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID()
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (token) => {
    const random = Math.floor(Math.random() * 16)
    const value = token === 'x' ? random : (random & 0x3) | 0x8
    return value.toString(16)
  })
}

export function localSessionId(): string {
  const fallback = 'local-session'
  if (typeof sessionStorage === 'undefined') return fallback
  const key = 'solar-tracker.session-id'
  const stored = sessionStorage.getItem(key)
  if (stored) return stored
  const value = makeCommandId()
  sessionStorage.setItem(key, value)
  return value
}
