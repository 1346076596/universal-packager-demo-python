import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { systemApi } from '../api/http'
import type { SiteConfig } from '../api/contracts'
import { localSessionId } from '../utils/format'
import { useSystemStore } from './system'

export type ThermalVariant = 'original' | 'annotated'

const MEDIA_PREFERENCE_KEY = 'solar-tracker.thermal-variant'

function initialVariant(): ThermalVariant {
  if (typeof localStorage === 'undefined') return 'annotated'
  return localStorage.getItem(MEDIA_PREFERENCE_KEY) === 'original'
    ? 'original'
    : 'annotated'
}

export const useSettingsStore = defineStore('settings', () => {
  const system = useSystemStore()
  const site = ref<SiteConfig | null>(null)
  const loading = ref(false)
  const saving = ref(false)
  const error = ref<string | null>(null)
  const savedNotice = ref<string | null>(null)
  const thermalVariant = ref<ThermalVariant>(initialVariant())

  const timeOverridden = computed(() => Boolean(site.value?.calculation_time_override))

  function hydrate(nextSite: SiteConfig): void {
    if (!saving.value) site.value = { ...nextSite }
  }

  async function load(): Promise<void> {
    loading.value = true
    error.value = null
    try {
      const response = await systemApi.getSiteConfig()
      if (response) hydrate(response)
    } catch (reason) {
      error.value = reason instanceof Error ? reason.message : '站点配置加载失败'
    } finally {
      loading.value = false
    }
  }

  async function save(nextSite: SiteConfig): Promise<void> {
    saving.value = true
    error.value = null
    savedNotice.value = null
    try {
      const response = await systemApi.updateSiteConfig({
        ...nextSite,
        operator: 'local-operator',
        session_id: localSessionId(),
      })
      site.value = { ...response }
      savedNotice.value = '站点与计算时间已保存，已按新配置刷新太阳轨迹与天气数据'
      await system.fetchSnapshot().catch(() => undefined)
    } catch (reason) {
      error.value = reason instanceof Error ? reason.message : '站点配置保存失败'
      throw reason
    } finally {
      saving.value = false
    }
  }

  async function restoreAutomaticTime(): Promise<void> {
    if (!site.value) return
    await save({ ...site.value, calculation_time_override: null })
  }

  function setThermalVariant(variant: ThermalVariant): void {
    thermalVariant.value = variant
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(MEDIA_PREFERENCE_KEY, variant)
    }
  }

  return {
    site,
    loading,
    saving,
    error,
    savedNotice,
    thermalVariant,
    timeOverridden,
    hydrate,
    load,
    save,
    restoreAutomaticTime,
    setThermalVariant,
  }
})
