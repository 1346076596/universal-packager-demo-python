import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { useSystemStore } from './system'
import { makeSnapshot } from '../test/fixtures'

describe('systemStore', () => {
  beforeEach(() => setActivePinia(createPinia()))

  it('忽略倒退的快照序号', () => {
    const store = useSystemStore()
    expect(store.applySnapshot(makeSnapshot({ sequence: 8 }))).toBe(true)
    expect(store.applySnapshot(makeSnapshot({ sequence: 7 }))).toBe(false)
    expect(store.snapshot?.sequence).toBe(8)
  })

  it('WebSocket 断线或快照过期时锁定为 stale', () => {
    const store = useSystemStore()
    const generated = '2026-07-31T04:00:00Z'
    store.applySnapshot(makeSnapshot({ generated_at: generated }))
    store.socketStatus = 'online'
    store.tick(new Date(generated).getTime() + 2_000)
    expect(store.dataStale).toBe(false)

    store.tick(new Date(generated).getTime() + 6_000)
    expect(store.dataStale).toBe(true)
    expect(store.displayAlarms.some((alarm) => alarm.code === 'UI_SNAPSHOT_STALE')).toBe(
      true,
    )

    store.socketStatus = 'reconnecting'
    expect(store.displayAlarms.some((alarm) => alarm.code === 'UI_WS_OFFLINE')).toBe(
      true,
    )
  })

  it('识别字符串连接态与模拟标识', () => {
    const store = useSystemStore()
    const snapshot = makeSnapshot({
      connections: {
        ...makeSnapshot().connections,
        plc: 'degraded',
      },
      simulation: {
        active: true,
        clearly_labeled: true,
        label: '台架仿真',
        production_fallback_allowed: false,
      },
    })
    store.applySnapshot(snapshot)
    expect(store.plcOnline).toBe(true)
    expect(store.simulationActive).toBe(true)
  })
})
