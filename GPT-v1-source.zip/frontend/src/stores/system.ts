import { computed, markRaw, ref } from 'vue'
import { defineStore } from 'pinia'
import { systemApi } from '../api/http'
import {
  type Alarm,
  type ServiceHealth,
  type SystemSnapshot,
  unwrapSystemSnapshot,
} from '../api/contracts'
import {
  connectSystemSocket,
  type SocketStatus,
  type SystemSocket,
} from '../api/websocket'
import { secondsSince } from '../utils/format'

const SNAPSHOT_STALE_AFTER_SECONDS = 4

function connectionOnline(health: ServiceHealth | undefined): boolean {
  return health === 'online' || health === 'degraded'
}

export const useSystemStore = defineStore('system', () => {
  const snapshot = ref<SystemSnapshot | null>(null)
  const initialLoading = ref(false)
  const initialError = ref<string | null>(null)
  const socketStatus = ref<SocketStatus>('offline')
  const socketAttempt = ref(0)
  const socketError = ref<string | null>(null)
  const lastMessageAt = ref<number | null>(null)
  const nowMs = ref(Date.now())
  let socket: SystemSocket | null = null

  const snapshotAgeSeconds = computed(() =>
    secondsSince(snapshot.value?.generated_at, nowMs.value),
  )
  const dataStale = computed(
    () =>
      !snapshot.value ||
      socketStatus.value !== 'online' ||
      snapshotAgeSeconds.value > SNAPSHOT_STALE_AFTER_SECONDS,
  )
  const plcOnline = computed(
    () =>
      Boolean(snapshot.value?.plc.online) &&
      connectionOnline(snapshot.value?.connections.plc),
  )
  const cameraOnline = computed(() =>
    connectionOnline(snapshot.value?.connections.camera),
  )
  const weatherOnline = computed(() =>
    connectionOnline(snapshot.value?.connections.weather),
  )
  const simulationActive = computed(() => {
    return Boolean(snapshot.value?.simulation.active)
  })

  const displayAlarms = computed<Alarm[]>(() => {
    const alarms = snapshot.value?.alarms || []
    const local: Alarm[] = []
    if (socketStatus.value !== 'online') {
      local.push({
        code: 'UI_WS_OFFLINE',
        severity: 'critical',
        message:
          socketStatus.value === 'reconnecting'
            ? `正在进行第 ${socketAttempt.value} 次重连，当前数据可能过期。`
            : '无法接收 PLC 实时状态，所有手动操作已锁定。',
        source: 'WebSocket：实时状态连接中断',
      })
    } else if (snapshotAgeSeconds.value > SNAPSHOT_STALE_AFTER_SECONDS) {
      local.push({
        code: 'UI_SNAPSHOT_STALE',
        severity: 'critical',
        message: `最近状态生成于 ${snapshotAgeSeconds.value} 秒前，手动操作已锁定。`,
        source: '状态流：系统快照已过期',
      })
    }
    if (snapshot.value && !snapshot.value.plc.online) {
      local.push({
        code: 'UI_PLC_OFFLINE',
        severity: 'critical',
        message: '未收到 PLC 遥测确认，运动控制不可用。',
        source: 'PLC：设备离线',
      })
    }
    if (
      snapshot.value?.thermal.guidance.stale &&
      snapshot.value?.thermal.stream_available
    ) {
      local.push({
        code: 'UI_THERMAL_STALE',
        severity: 'critical',
        message: '帧序号或时间戳停止更新，热成像指导应已撤销。',
        source: '相机：热成像画面过期',
      })
    }
    if (snapshot.value?.weather.stale) {
      local.push({
        code: 'UI_WEATHER_STALE',
        severity: 'warning',
        message: '太阳重现预测可能已降级，请查看数据更新时间。',
        source: '天气：缓存过期',
      })
    }
    const codes = new Set(alarms.map((alarm) => alarm.code))
    return [...local.filter((alarm) => !codes.has(alarm.code)), ...alarms]
  })

  function applySnapshot(incoming: SystemSnapshot): boolean {
    if (snapshot.value && incoming.sequence < snapshot.value.sequence) return false
    snapshot.value = incoming
    lastMessageAt.value = Date.now()
    initialError.value = null
    return true
  }

  function applySocketMessage(message: unknown): boolean {
    const incoming = unwrapSystemSnapshot(message)
    if (!incoming) {
      socketError.value = '收到不符合 SystemSnapshot 契约的消息'
      return false
    }
    socketError.value = null
    return applySnapshot(incoming)
  }

  async function fetchSnapshot(): Promise<SystemSnapshot> {
    const incoming = await systemApi.getState()
    applySnapshot(incoming)
    return incoming
  }

  async function initialize(): Promise<void> {
    initialLoading.value = true
    initialError.value = null
    try {
      await fetchSnapshot()
    } catch (error) {
      initialError.value =
        error instanceof Error ? error.message : '无法加载系统初始状态'
    } finally {
      initialLoading.value = false
      connectRealtime()
    }
  }

  function connectRealtime(): void {
    if (socket) return
    socket = markRaw(
      connectSystemSocket({
        onMessage: applySocketMessage,
        onStatus(status, attempt) {
          socketStatus.value = status
          socketAttempt.value = attempt
          if (status === 'online') socketError.value = null
        },
        onError(message) {
          socketError.value = message
        },
      }),
    )
  }

  function tick(timestamp = Date.now()): void {
    nowMs.value = timestamp
  }

  function shutdown(): void {
    socket?.close()
    socket = null
  }

  return {
    snapshot,
    initialLoading,
    initialError,
    socketStatus,
    socketAttempt,
    socketError,
    lastMessageAt,
    nowMs,
    snapshotAgeSeconds,
    dataStale,
    plcOnline,
    cameraOnline,
    weatherOnline,
    simulationActive,
    displayAlarms,
    applySnapshot,
    applySocketMessage,
    fetchSnapshot,
    initialize,
    connectRealtime,
    tick,
    shutdown,
  }
})
