import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { systemApi } from '../api/http'
import type {
  AxisName,
  ControlMode,
  ManualDirection,
  SystemSnapshot,
} from '../api/contracts'
import { localSessionId, makeCommandId } from '../utils/format'
import { useSystemStore } from './system'

export interface JogAvailability {
  allowed: boolean
  reason: string
}

interface PendingJog {
  commandId: string
  direction: ManualDirection
  startedAt: number
}

const JOG_ACK_TIMEOUT_MS = 10_000

export const useControlStore = defineStore('control', () => {
  const system = useSystemStore()
  const requestedMode = ref<ControlMode>('solar')
  const confirmedMode = ref<ControlMode>('solar')
  const modeSwitchPending = ref(false)
  const modeSubmitting = ref(false)
  const modeError = ref<string | null>(null)
  const pendingModeCommandId = ref<string | null>(null)
  const pendingJog = ref<PendingJog | null>(null)
  const jogError = ref<string | null>(null)
  const jogNotice = ref<string | null>(null)

  const isDay = computed(() => Boolean(system.snapshot?.solar.is_day))
  const calculationPreviewActive = computed(() =>
    Boolean(system.snapshot?.site.calculation_time_override),
  )
  const safetyOk = computed(() => {
    const safety = system.snapshot?.plc.safety
    return Boolean(
      safety?.safety_ok &&
        safety.safety_chain_ok &&
        !safety.emergency_stop &&
        !safety.communication_fault,
    )
  })
  const manualBaseEnabled = computed(
    () =>
      confirmedMode.value === 'manual' &&
      !modeSwitchPending.value &&
      !calculationPreviewActive.value &&
      isDay.value &&
      system.plcOnline &&
      safetyOk.value &&
      !system.dataStale &&
      !pendingJog.value,
  )

  function syncFromSnapshot(snapshot: SystemSnapshot): void {
    requestedMode.value = snapshot.requested_mode ?? snapshot.confirmed_mode
    confirmedMode.value = snapshot.confirmed_mode
    modeSwitchPending.value = snapshot.mode_switch_pending
    if (!snapshot.mode_switch_pending) {
      modeSubmitting.value = false
      pendingModeCommandId.value = null
      modeError.value = snapshot.plc.mode_rejection_reason
    }

    const ackId = snapshot.plc.last_ack?.command_id
    if (pendingJog.value && ackId === pendingJog.value.commandId) {
      const accepted = snapshot.plc.last_ack?.accepted !== false
      jogNotice.value = accepted
        ? 'PLC 已确认本次微调命令'
        : snapshot.plc.last_ack?.result || 'PLC 已拒绝本次微调命令'
      jogError.value = accepted ? null : jogNotice.value
      pendingJog.value = null
    }
  }

  function jogAvailability(
    axis: AxisName,
    direction: ManualDirection,
  ): JogAvailability {
    const snapshot = system.snapshot
    if (!snapshot) return { allowed: false, reason: '尚未收到系统状态' }
    if (system.dataStale) return { allowed: false, reason: '实时数据已过期' }
    if (modeSwitchPending.value) return { allowed: false, reason: '等待 PLC 确认模式' }
    if (calculationPreviewActive.value) {
      return { allowed: false, reason: '历史/未来计算时间仅供预览，禁止真实运动' }
    }
    if (confirmedMode.value !== 'manual') {
      return { allowed: false, reason: '仅手动模式允许微调' }
    }
    if (!snapshot.solar.is_day) return { allowed: false, reason: '夜间禁止网页微调' }
    if (!system.plcOnline) return { allowed: false, reason: 'PLC 离线' }
    if (!safetyOk.value) return { allowed: false, reason: '安全链未就绪' }
    if (pendingJog.value) return { allowed: false, reason: '上一条命令尚未确认' }

    const axes = [snapshot.plc.azimuth, snapshot.plc.elevation]
    if (axes.some((item) => item.moving)) {
      return { allowed: false, reason: '执行机构仍在运动' }
    }
    if (axes.some((item) => !item.motion_stopped)) {
      return { allowed: false, reason: '执行机构尚未确认停稳' }
    }
    if (axes.some((item) => item.fault || item.timed_out)) {
      return { allowed: false, reason: '轴故障或动作超时尚未复位' }
    }

    const telemetry = axis === 'azimuth' ? snapshot.plc.azimuth : snapshot.plc.elevation
    if (!telemetry.position_valid) return { allowed: false, reason: '位置反馈无效' }
    if (telemetry.fault) {
      return { allowed: false, reason: telemetry.fault_reason || '轴故障未复位' }
    }
    const negativeDirection =
      direction === 'az_left' || direction === 'alt_down'
    if (negativeDirection && telemetry.negative_limit) {
      return { allowed: false, reason: '负方向硬限位已触发' }
    }
    if (!negativeDirection && telemetry.positive_limit) {
      return { allowed: false, reason: '正方向硬限位已触发' }
    }
    return { allowed: true, reason: '允许一次有界微调' }
  }

  async function requestMode(mode: ControlMode): Promise<void> {
    if (modeSubmitting.value || mode === requestedMode.value) return
    if (mode !== 'manual' && calculationPreviewActive.value) {
      const reason = '历史/未来计算时间仅供预览，不能启用自动追踪控制'
      modeError.value = reason
      throw new Error(reason)
    }
    const previous = requestedMode.value
    const commandId = makeCommandId()
    requestedMode.value = mode
    modeSwitchPending.value = true
    modeSubmitting.value = true
    modeError.value = null
    pendingModeCommandId.value = commandId
    try {
      const response = await systemApi.requestMode({
        mode,
        command_id: commandId,
        issued_at: new Date().toISOString(),
        operator: 'local-operator',
        session_id: localSessionId(),
      })
      if (!response.accepted) {
        throw new Error(response.reason || 'Python 服务拒绝模式请求')
      }
      jogNotice.value = '模式请求已接收，正在等待 PLC 安全停止并确认'
    } catch (error) {
      requestedMode.value = previous
      modeSwitchPending.value = false
      modeSubmitting.value = false
      pendingModeCommandId.value = null
      modeError.value = error instanceof Error ? error.message : '模式请求失败'
      throw error
    }
  }

  async function jog(axis: AxisName, direction: ManualDirection): Promise<void> {
    const availability = jogAvailability(axis, direction)
    if (!availability.allowed) {
      jogError.value = availability.reason
      return
    }
    const commandId = makeCommandId()
    pendingJog.value = { commandId, direction, startedAt: Date.now() }
    jogError.value = null
    jogNotice.value = '微调命令已提交，等待 PLC 确认'
    try {
      const response = await systemApi.manualJog({
        command_id: commandId,
        direction,
        step_degrees: 0.5,
        issued_at: new Date().toISOString(),
        operator: 'local-operator',
        session_id: localSessionId(),
      })
      if (!response.accepted) {
        throw new Error(response.reason || 'Python 服务拒绝微调命令')
      }
    } catch (error) {
      pendingJog.value = null
      jogError.value = error instanceof Error ? error.message : '微调请求失败'
      throw error
    }
  }

  function reconcilePending(now = Date.now()): void {
    if (
      pendingJog.value &&
      now - pendingJog.value.startedAt > JOG_ACK_TIMEOUT_MS
    ) {
      jogError.value = '命令未在 10 秒内得到 PLC 确认，不能假定动作成功'
      pendingJog.value = null
    }
  }

  function clearMessages(): void {
    jogError.value = null
    jogNotice.value = null
    modeError.value = null
  }

  return {
    requestedMode,
    confirmedMode,
    modeSwitchPending,
    modeSubmitting,
    modeError,
    pendingModeCommandId,
    pendingJog,
    jogError,
    jogNotice,
    isDay,
    calculationPreviewActive,
    safetyOk,
    manualBaseEnabled,
    syncFromSnapshot,
    jogAvailability,
    requestMode,
    jog,
    reconcilePending,
    clearMessages,
  }
})
