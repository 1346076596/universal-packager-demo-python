import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { systemApi } from '../api/http'
import { makeSnapshot } from '../test/fixtures'
import { useControlStore } from './control'
import { useSystemStore } from './system'

vi.mock('../api/http', () => ({
  systemApi: {
    getState: vi.fn(),
    requestMode: vi.fn(),
    manualJog: vi.fn(),
    getSiteConfig: vi.fn(),
    updateSiteConfig: vi.fn(),
    getReappearance: vi.fn(),
    getThermalMetadata: vi.fn(),
  },
}))

describe('controlStore 安全联动', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.mocked(systemApi.requestMode).mockResolvedValue({
      command_id: '11111111-1111-4111-8111-111111111111',
      accepted: true,
      status: 'accepted',
      requested_mode: 'solar',
      confirmed_mode: 'manual',
      acknowledged_at: null,
      reason: null,
      duplicate: false,
    })
    vi.mocked(systemApi.manualJog).mockResolvedValue({
      command_id: '22222222-2222-4222-8222-222222222222',
      accepted: true,
      status: 'accepted',
      requested_mode: 'manual',
      confirmed_mode: 'manual',
      acknowledged_at: null,
      reason: null,
      duplicate: false,
    })
  })

  function prepare(snapshot = makeSnapshot()) {
    const system = useSystemStore()
    system.applySnapshot(snapshot)
    system.socketStatus = 'online'
    system.tick(new Date(snapshot.generated_at).getTime() + 1_000)
    const control = useControlStore()
    control.syncFromSnapshot(snapshot)
    return { system, control }
  }

  it('仅白天、手动、安全且在线时允许微调', () => {
    const { control } = prepare()
    expect(control.jogAvailability('azimuth', 'az_left')).toEqual({
      allowed: true,
      reason: '允许一次有界微调',
    })

    const night = makeSnapshot({
      solar: { ...makeSnapshot().solar, is_day: false },
    })
    control.syncFromSnapshot(night)
    useSystemStore().applySnapshot(night)
    expect(control.jogAvailability('azimuth', 'az_left').reason).toBe(
      '夜间禁止网页微调',
    )
  })

  it('限位只禁用危险方向并保留反向退出', () => {
    const snapshot = makeSnapshot({
      plc: {
        ...makeSnapshot().plc,
        azimuth: {
          ...makeSnapshot().plc.azimuth,
          negative_limit: true,
        },
      },
    })
    const { control } = prepare(snapshot)
    expect(control.jogAvailability('azimuth', 'az_left').allowed).toBe(false)
    expect(control.jogAvailability('azimuth', 'az_right').allowed).toBe(true)
  })

  it('现场停稳反馈未确认时禁止新的微调', () => {
    const snapshot = makeSnapshot({
      plc: {
        ...makeSnapshot().plc,
        elevation: {
          ...makeSnapshot().plc.elevation,
          motion_stopped: false,
        },
      },
    })
    const { control } = prepare(snapshot)

    expect(control.jogAvailability('azimuth', 'az_right')).toEqual({
      allowed: false,
      reason: '执行机构尚未确认停稳',
    })
  })

  it('历史时间覆盖只允许预览并锁定真实运动', async () => {
    const snapshot = makeSnapshot({
      site: {
        ...makeSnapshot().site,
        calculation_time_override: '2020-06-21T12:00:00+08:00',
      },
    })
    const { control } = prepare(snapshot)

    expect(control.jogAvailability('azimuth', 'az_right')).toEqual({
      allowed: false,
      reason: '历史/未来计算时间仅供预览，禁止真实运动',
    })
    const callsBefore = vi.mocked(systemApi.requestMode).mock.calls.length
    await expect(control.requestMode('solar')).rejects.toThrow(
      '历史/未来计算时间仅供预览，不能启用自动追踪控制',
    )
    expect(vi.mocked(systemApi.requestMode).mock.calls).toHaveLength(callsBefore)
  })

  it('模式请求只发送后端允许字段且不提前改变 confirmedMode', async () => {
    const { control } = prepare()
    await control.requestMode('solar')
    const payload = vi.mocked(systemApi.requestMode).mock.calls[0]?.[0]
    expect(payload).toEqual({
      command_id: expect.any(String),
      mode: 'solar',
      issued_at: expect.any(String),
      operator: 'local-operator',
      session_id: expect.any(String),
    })
    expect(control.requestedMode).toBe('solar')
    expect(control.confirmedMode).toBe('manual')
    expect(control.modeSwitchPending).toBe(true)
  })

  it('微调 payload 使用 direction 和唯一有界量，不发送 axis', async () => {
    const { control } = prepare()
    await control.jog('azimuth', 'az_left')
    const payload = vi.mocked(systemApi.manualJog).mock.calls[0]?.[0]
    expect(payload).toMatchObject({
      command_id: expect.any(String),
      direction: 'az_left',
      step_degrees: 0.5,
      issued_at: expect.any(String),
      operator: 'local-operator',
      session_id: expect.any(String),
    })
    expect(payload).not.toHaveProperty('axis')
    expect(payload).not.toHaveProperty('max_duration_seconds')
  })
})
