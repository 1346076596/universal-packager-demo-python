import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import SolarTrajectory from './SolarTrajectory.vue'
import { makeAxis, makeSnapshot } from '../test/fixtures'

function createCanvasContext(): CanvasRenderingContext2D {
  const gradient = { addColorStop: vi.fn() }
  return {
    arc: vi.fn(),
    beginPath: vi.fn(),
    clearRect: vi.fn(),
    clip: vi.fn(),
    createRadialGradient: vi.fn(() => gradient),
    fill: vi.fn(),
    fillRect: vi.fn(),
    lineTo: vi.fn(),
    moveTo: vi.fn(),
    restore: vi.fn(),
    save: vi.fn(),
    setLineDash: vi.fn(),
    setTransform: vi.fn(),
    stroke: vi.fn(),
    strokeRect: vi.fn(),
  } as unknown as CanvasRenderingContext2D
}

describe('SolarTrajectory', () => {
  beforeEach(() => {
    vi.spyOn(HTMLCanvasElement.prototype, 'getContext').mockImplementation(
      () => createCanvasContext(),
    )
  })

  afterEach(() => vi.restoreAllMocks())

  function mountTrajectory() {
    const snapshot = makeSnapshot()
    return mount(SolarTrajectory, {
      props: {
        solar: snapshot.solar,
        azimuth: makeAxis({ actual_angle: 128.4 }),
        elevation: makeAxis({ actual_angle: 58.1 }),
        timezone: 'Asia/Shanghai',
        latitude: snapshot.site.latitude,
        longitude: snapshot.site.longitude,
      },
    })
  }

  it('以当前坐标为本地原点，并默认保持北上南下、东右西左', () => {
    const wrapper = mountTrajectory()
    const globe = wrapper.get('[data-test="trajectory-globe"]')
    const markers = wrapper.findAll('[data-direction]')

    expect(globe.attributes('tabindex')).toBe('0')
    expect(globe.attributes('aria-describedby')).toBe(
      'trajectory-interaction-hint',
    )
    expect(markers).toHaveLength(4)
    expect(markers.map((marker) => marker.text())).toEqual([
      '北N',
      '东E',
      '南S',
      '西W',
    ])
    expect(globe.attributes('data-view-yaw')).toBe('0')
    expect(globe.attributes('data-view-pitch')).toBe('24')
    expect(globe.attributes('data-view-zoom')).toBe('100')
    expect(wrapper.get('.trajectory__local-origin').text()).toContain(
      '30.2500°N · 120.1500°E',
    )
    expect(globe.attributes('aria-label')).toContain(
      '默认北上南下、东右西左',
    )

    const top = (direction: string, property: 'left' | 'top') =>
      Number.parseFloat(
        wrapper
          .get(`[data-direction="${direction}"]`)
          .attributes('style')
          ?.match(new RegExp(`${property}: ([\\d.]+)px`))?.[1] ?? '0',
      )
    expect(top('north', 'top')).toBeLessThan(top('south', 'top'))
    expect(top('west', 'left')).toBeLessThan(top('east', 'left'))
  })

  it('在方位图上按实时方位角和高度角更新太阳位置', async () => {
    const wrapper = mountTrajectory()
    const marker = wrapper.get('.trajectory__sun-position')
    const initialStyle = marker.attributes('style')

    expect(marker.attributes('data-sun-azimuth')).toBe('128.4')
    expect(marker.attributes('data-sun-altitude')).toBe('58.2')
    expect(marker.text()).toContain('当前太阳位置')
    expect(marker.text()).toContain('方位 128.4° · 高度 58.2°')

    await wrapper.setProps({
      solar: {
        ...wrapper.props('solar'),
        azimuth: 220,
        altitude: 18,
      },
    })

    const movedMarker = wrapper.get('.trajectory__sun-position')
    expect(movedMarker.attributes('data-sun-azimuth')).toBe('220.0')
    expect(movedMarker.attributes('data-sun-altitude')).toBe('18.0')
    expect(movedMarker.attributes('style')).not.toBe(initialStyle)
  })

  it('拖动或触控时同步旋转球面、方位标记与当前位置标记', async () => {
    const wrapper = mountTrajectory()
    const globe = wrapper.get('[data-test="trajectory-globe"]')
    const northBefore = wrapper
      .get('[data-direction="north"]')
      .attributes('style')
    const sunBefore = wrapper
      .get('.trajectory__sun-position')
      .attributes('style')
    const origin = wrapper.get('.trajectory__local-origin')
    const originBefore = origin.attributes('style')
    const originXBefore = origin.attributes('data-origin-x')
    const coordinateBefore = origin.text()

    expect(origin.attributes('data-origin-depth')).toBe('1.000')

    await globe.trigger('pointerdown', {
      pointerId: 7,
      pointerType: 'touch',
      isPrimary: true,
      clientX: 100,
      clientY: 120,
    })
    await globe.trigger('pointermove', {
      pointerId: 7,
      pointerType: 'touch',
      isPrimary: true,
      clientX: 140,
      clientY: 100,
    })

    expect(globe.classes()).toContain('trajectory__canvas-wrap--dragging')
    expect(globe.attributes('data-view-yaw')).toBe('18')
    expect(globe.attributes('data-view-pitch')).toBe('31')
    expect(
      wrapper.get('[data-direction="north"]').attributes('style'),
    ).not.toBe(northBefore)
    expect(
      wrapper.get('.trajectory__sun-position').attributes('style'),
    ).not.toBe(sunBefore)
    expect(
      wrapper.get('.trajectory__local-origin').attributes('style'),
    ).not.toBe(originBefore)
    expect(
      wrapper.get('.trajectory__local-origin').attributes('data-origin-x'),
    ).not.toBe(originXBefore)
    expect(wrapper.get('.trajectory__local-origin').text()).toBe(
      coordinateBefore,
    )

    await globe.trigger('pointerup', { pointerId: 7 })
    expect(globe.classes()).not.toContain('trajectory__canvas-wrap--dragging')
  })

  it('支持方向键微调并可重置默认视角', async () => {
    const wrapper = mountTrajectory()
    const globe = wrapper.get('[data-test="trajectory-globe"]')

    await globe.trigger('keydown', { key: 'ArrowRight' })
    await globe.trigger('keydown', { key: 'ArrowUp' })
    expect(globe.attributes('data-view-yaw')).toBe('10')
    expect(globe.attributes('data-view-pitch')).toBe('34')

    await wrapper.get('.trajectory__reset').trigger('click')
    expect(globe.attributes('data-view-yaw')).toBe('0')
    expect(globe.attributes('data-view-pitch')).toBe('24')

    await globe.trigger('keydown', { key: 'ArrowLeft', shiftKey: true })
    expect(globe.attributes('data-view-yaw')).toBe('-3')
    await globe.trigger('keydown', { key: 'Home' })
    expect(globe.attributes('data-view-yaw')).toBe('0')
  })

  it('支持按钮、滚轮和键盘缩放，并随重置恢复 100%', async () => {
    const wrapper = mountTrajectory()
    const globe = wrapper.get('[data-test="trajectory-globe"]')

    await wrapper.get('[data-test="zoom-in"]').trigger('click')
    expect(globe.attributes('data-view-zoom')).toBe('110')
    expect(wrapper.get('[data-test="zoom-level"]').text()).toContain('110%')

    await globe.trigger('wheel', { deltaY: -100 })
    expect(globe.attributes('data-view-zoom')).toBe('120')

    await globe.trigger('keydown', { key: '-' })
    expect(globe.attributes('data-view-zoom')).toBe('110')

    await wrapper.get('.trajectory__reset').trigger('click')
    expect(globe.attributes('data-view-zoom')).toBe('100')
  })

  it('控制目标无效时仍显示当前太阳位置，不把目标有效性当作位置有效性', async () => {
    const wrapper = mountTrajectory()

    await wrapper.setProps({
      solar: {
        ...wrapper.props('solar'),
        target_valid: false,
        target_azimuth: null,
        target_altitude: null,
        target_invalid_reason: 'night',
        azimuth: 285.2,
        altitude: -8.6,
      },
    })

    const marker = wrapper.get('.trajectory__sun-position')
    expect(marker.attributes('data-sun-azimuth')).toBe('285.2')
    expect(marker.attributes('data-sun-altitude')).toBe('-8.6')
    expect(marker.classes()).toContain(
      'trajectory__sun-position--below-horizon',
    )
    expect(marker.text()).toContain('当前太阳位置')
    expect(wrapper.get('[data-test="trajectory-globe"]').attributes('aria-label')).toContain(
      'PLC 控制目标无效，不得据此执行运动',
    )
  })
})
