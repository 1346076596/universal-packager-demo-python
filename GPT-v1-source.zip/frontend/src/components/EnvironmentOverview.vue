<script setup lang="ts">
import { computed } from 'vue'
import type { WeatherState } from '../api/contracts'
import { formatTimestamp } from '../utils/format'
import { formatWeatherCode } from '../utils/weather'
import MetricIcon from './MetricIcon.vue'

const props = defineProps<{
  weather: WeatherState
  calculationTime: string
  timezone: string
}>()

const sample = computed(() => props.weather.selected)

function percent(value: number | null | undefined): string {
  return value == null ? '—' : `${Math.round(value)}%`
}

function number(value: number | null | undefined, digits = 1): string {
  return value == null ? '—' : value.toFixed(digits)
}
</script>

<template>
  <section class="panel environment-panel" aria-labelledby="environment-title">
    <header class="compact-panel-header">
      <h2 id="environment-title">环境概览</h2>
      <span :class="weather.valid ? 'text-normal' : 'text-warning'">
        {{ weather.valid ? 'Open-Meteo' : '数据不可用' }}
      </span>
    </header>
    <div class="environment-grid">
      <div class="environment-metric">
        <MetricIcon name="cloud" />
        <span>云量<strong>{{ percent(sample?.cloud_cover) }}</strong></span>
      </div>
      <div class="environment-metric">
        <MetricIcon name="wind" />
        <span>风速<strong>{{ number(sample?.wind_speed) }} <small>km/h</small></strong></span>
      </div>
      <div class="environment-metric">
        <MetricIcon name="weather" />
        <span>天气<strong>{{ formatWeatherCode(sample?.weather_code) }}</strong></span>
      </div>
      <div class="environment-metric">
        <MetricIcon name="radiation" />
        <span>太阳辐射<strong>{{ number(sample?.shortwave_radiation, 0) }} <small>W/m²</small></strong></span>
      </div>
      <div class="environment-metric">
        <MetricIcon name="visibility" />
        <span>能见度<strong>{{ sample?.visibility == null ? '—' : number(sample.visibility / 1000) }} <small>km</small></strong></span>
      </div>
      <div class="environment-metric">
        <MetricIcon name="temperature" />
        <span>气温<strong>{{ number(sample?.temperature_2m) }} <small>°C</small></strong></span>
      </div>
    </div>
    <p class="environment-time">
      <MetricIcon name="clock" />
      截止 {{ formatTimestamp(calculationTime, timezone) }}
    </p>
  </section>
</template>

<style scoped>
.environment-panel {
  display: grid;
  grid-template-rows: auto minmax(0, 1fr) auto;
  padding: 0.7rem;
  overflow: hidden;
}

.compact-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  padding-bottom: 0.45rem;
}

.compact-panel-header span {
  font-size: 0.62rem;
}

.environment-grid {
  min-height: 0;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 0.38rem;
}

.environment-metric {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 0.45rem;
  padding: 0.45rem 0.5rem;
  border: 1px solid var(--line);
  border-radius: var(--radius-sm);
  color: var(--text-3);
  background: var(--bg-1);
}

.environment-metric span,
.environment-metric strong {
  min-width: 0;
  display: block;
}

.environment-metric span {
  font-size: 0.61rem;
}

.environment-metric strong {
  margin-top: 0.12rem;
  overflow: hidden;
  color: var(--text-1);
  font-family: var(--mono);
  font-size: clamp(0.72rem, 0.8vw, 0.9rem);
  font-weight: 600;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.environment-metric small {
  color: var(--text-3);
  font-size: 0.55rem;
}

.environment-time {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  padding-top: 0.42rem;
  overflow: hidden;
  color: var(--text-3);
  font-family: var(--mono);
  font-size: 0.59rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.environment-time :deep(.metric-icon) {
  width: 0.85rem;
  height: 0.85rem;
}
</style>
