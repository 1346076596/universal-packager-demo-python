import { mount } from '@vue/test-utils'
import { describe, expect, it } from 'vitest'
import ReappearanceCard from './ReappearanceCard.vue'
import { makeSnapshot } from '../test/fixtures'

describe('ReappearanceCard', () => {
  it('简化天气标签且不展示预测依据', () => {
    const snapshot = makeSnapshot()
    const wrapper = mount(ReappearanceCard, {
      props: {
        prediction: snapshot.prediction,
        weather: snapshot.weather,
        timezone: snapshot.site.timezone,
        now: Date.parse(snapshot.generated_at),
      },
    })

    expect(wrapper.findAll('.weather-strip span')[2]?.text()).toBe('天气')
    expect(wrapper.findAll('.weather-strip strong')[2]?.text()).toBe('局部多云')
    expect(wrapper.text()).not.toContain('天气有效时间')
    expect(wrapper.text()).not.toContain('预测依据')
    expect(wrapper.text()).not.toContain('云量下降')
  })

  it('天气码缺失时显示未知而不是根据云量推断', () => {
    const snapshot = makeSnapshot()
    if (snapshot.weather.selected) {
      snapshot.weather.selected.weather_code = null
      snapshot.weather.selected.cloud_cover = 0
    }

    const wrapper = mount(ReappearanceCard, {
      props: {
        prediction: snapshot.prediction,
        weather: snapshot.weather,
        timezone: snapshot.site.timezone,
        now: Date.parse(snapshot.generated_at),
      },
    })

    expect(wrapper.findAll('.weather-strip strong')[2]?.text()).toBe('未知')
  })

  it('历史回看倒计时以所选计算时间为基准', () => {
    const snapshot = makeSnapshot()
    const selected = '2026-07-17T13:03:00+08:00'
    const prediction = {
      ...snapshot.prediction,
      best_estimate: '2026-07-19T04:00:00+08:00',
    }
    const wrapper = mount(ReappearanceCard, {
      props: {
        prediction,
        weather: snapshot.weather,
        timezone: 'Asia/Shanghai',
        now: Date.parse(selected),
        previewKind: 'historical',
      },
    })

    expect(wrapper.text()).toContain('38 小时 57 分')
    expect(wrapper.text()).toContain('相对所选计算时间的历史回看结果')
  })

  it('未来覆盖时间使用未来预报文案且云量按 0 到 100 显示', () => {
    const snapshot = makeSnapshot()
    if (snapshot.weather.selected) snapshot.weather.selected.cloud_cover = 1
    const wrapper = mount(ReappearanceCard, {
      props: {
        prediction: snapshot.prediction,
        weather: snapshot.weather,
        timezone: snapshot.site.timezone,
        now: Date.parse(snapshot.generated_at),
        previewKind: 'future',
      },
    })

    expect(wrapper.text()).toContain('相对所选计算时间的未来预报结果')
    expect(wrapper.findAll('.weather-strip strong')[0]?.text()).toBe('1%')
  })
})
