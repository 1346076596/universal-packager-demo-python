import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import ModeSelector from './ModeSelector.vue'

describe('ModeSelector', () => {
  it('分开显示请求模式与 PLC 已确认模式', () => {
    const wrapper = mount(ModeSelector, {
      props: {
        requestedMode: 'thermal',
        confirmedMode: 'solar',
        pending: true,
        thermalAvailable: true,
      },
    })
    expect(wrapper.text()).toContain('等待 PLC 安全停止并确认模式')
    expect(wrapper.text()).toContain('太阳轨迹')
    expect(wrapper.find('.mode-button--confirmed').text()).toContain('PLC 已确认')
    expect(wrapper.find('.mode-button--requested').text()).toContain('已请求')
  })

  it('硬件未授权时明确禁用热成像模式', () => {
    const wrapper = mount(ModeSelector, {
      props: {
        requestedMode: 'solar',
        confirmedMode: 'solar',
        pending: false,
        thermalAvailable: false,
      },
    })
    const thermal = wrapper.findAll('.mode-button')[2]
    expect(thermal?.attributes('disabled')).toBeDefined()
    expect(thermal?.text()).toContain('硬件未授权')
  })

  it('左右按钮只浏览三个页面，不伪装成 PLC 请求或确认', async () => {
    const wrapper = mount(ModeSelector, {
      props: {
        requestedMode: 'solar',
        confirmedMode: 'solar',
        viewMode: 'solar',
        pending: false,
        disabled: true,
        thermalAvailable: false,
      },
    })

    await wrapper.find('[data-test="mode-next"]').trigger('click')
    expect(wrapper.emitted('browse')).toEqual([['thermal']])
    expect(wrapper.emitted('request')).toBeUndefined()

    await wrapper.setProps({ viewMode: 'thermal' })
    expect(wrapper.find('.mode-button--viewing').text()).toContain(
      '正在查看 · 未改变 PLC 模式',
    )
    expect(wrapper.find('.mode-button--confirmed').text()).toContain('太阳轨迹')

    await wrapper.find('[data-test="mode-previous"]').trigger('click')
    expect(wrapper.emitted('browse')).toEqual([['thermal'], ['solar']])
    expect(wrapper.emitted('request')).toBeUndefined()
  })

  it('键盘方向键和触控横滑循环浏览，但模式卡仍走 request', async () => {
    const wrapper = mount(ModeSelector, {
      props: {
        requestedMode: 'manual',
        confirmedMode: 'manual',
        viewMode: 'manual',
        pending: false,
        thermalAvailable: true,
      },
    })

    await wrapper.find('.mode-control').trigger('keydown', { key: 'ArrowLeft' })
    expect(wrapper.emitted('browse')).toEqual([['thermal']])

    await wrapper.setProps({ viewMode: 'thermal' })
    const buttons = wrapper.find('.mode-control__buttons')
    await buttons.trigger('touchstart', {
      touches: [{ clientX: 180, clientY: 20 }],
    })
    await buttons.trigger('touchend', {
      changedTouches: [{ clientX: 80, clientY: 24 }],
    })
    expect(wrapper.emitted('browse')).toEqual([['thermal'], ['manual']])
    expect(wrapper.emitted('request')).toBeUndefined()

    await wrapper.findAll('.mode-button')[1]?.trigger('click')
    expect(wrapper.emitted('request')).toEqual([['solar']])
  })
})
