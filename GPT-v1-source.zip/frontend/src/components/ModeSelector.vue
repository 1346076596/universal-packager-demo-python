<script setup lang="ts">
import { computed, ref } from 'vue'
import type { ControlMode } from '../api/contracts'

const props = withDefaults(
  defineProps<{
    requestedMode: ControlMode
    confirmedMode: ControlMode
    pending: boolean
    viewMode?: ControlMode
    disabled?: boolean
    thermalAvailable?: boolean
  }>(),
  {
    disabled: false,
    thermalAvailable: true,
  },
)

const emit = defineEmits<{
  request: [mode: ControlMode]
  browse: [mode: ControlMode]
}>()

const modes: Array<{
  value: ControlMode
  label: string
  description: string
}> = [
  { value: 'manual', label: '手动微调', description: '单次有界动作' },
  { value: 'solar', label: '太阳轨迹', description: '目标角闭环' },
  { value: 'thermal', label: '热成像', description: '热点中心对齐' },
]

const touchStart = ref<{ x: number; y: number } | null>(null)

const activeViewMode = computed(() => props.viewMode ?? props.confirmedMode)

function isDisabled(mode: ControlMode): boolean {
  return (
    props.disabled ||
    props.pending ||
    mode === props.requestedMode ||
    (mode === 'thermal' && !props.thermalAvailable)
  )
}

function requestMode(mode: ControlMode): void {
  if (!isDisabled(mode)) emit('request', mode)
}

function adjacentMode(direction: -1 | 1): ControlMode {
  const currentIndex = modes.findIndex(
    (mode) => mode.value === activeViewMode.value,
  )
  const startIndex = currentIndex >= 0 ? currentIndex : 0
  const nextIndex = (startIndex + direction + modes.length) % modes.length
  return modes[nextIndex]?.value ?? 'manual'
}

function browseAdjacent(direction: -1 | 1): void {
  emit('browse', adjacentMode(direction))
}

function handleKeydown(event: KeyboardEvent): void {
  if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return
  event.preventDefault()
  browseAdjacent(event.key === 'ArrowLeft' ? -1 : 1)
}

function handleTouchStart(event: TouchEvent): void {
  const touch = event.touches[0]
  if (!touch) return
  touchStart.value = { x: touch.clientX, y: touch.clientY }
}

function handleTouchEnd(event: TouchEvent): void {
  const start = touchStart.value
  const touch = event.changedTouches[0]
  touchStart.value = null
  if (!start || !touch) return

  const dx = touch.clientX - start.x
  const dy = touch.clientY - start.y
  if (Math.abs(dx) < 48 || Math.abs(dx) <= Math.abs(dy)) return

  event.preventDefault()
  browseAdjacent(dx < 0 ? 1 : -1)
}
</script>

<template>
  <div
    class="mode-control"
    aria-label="追踪模式选择"
    tabindex="0"
    @keydown="handleKeydown"
  >
    <div class="mode-control__carousel">
      <button
        type="button"
        class="mode-control__step mode-control__step--previous"
        aria-label="切换到上一个追踪模式"
        data-test="mode-previous"
        @click="browseAdjacent(-1)"
      >
        <span aria-hidden="true">‹</span>
      </button>

      <div
        class="mode-control__buttons"
        role="group"
        aria-label="三个追踪模式"
        @touchstart="handleTouchStart"
        @touchend="handleTouchEnd"
      >
      <button
        v-for="mode in modes"
        :key="mode.value"
        type="button"
        class="mode-button"
        :class="{
          'mode-button--requested': requestedMode === mode.value,
          'mode-button--confirmed': confirmedMode === mode.value,
          'mode-button--viewing':
            activeViewMode === mode.value && confirmedMode !== mode.value,
        }"
        :disabled="isDisabled(mode.value)"
        :aria-pressed="confirmedMode === mode.value"
        :aria-label="`${mode.label}：${mode.description}${
          confirmedMode === mode.value ? '，PLC 已确认' : ''
        }`"
        @click="requestMode(mode.value)"
      >
        <span class="mode-button__label">{{ mode.label }}</span>
        <span class="mode-button__description">{{ mode.description }}</span>
        <span
          v-if="confirmedMode === mode.value"
          class="mode-button__state"
        >
          PLC 已确认
        </span>
        <span
          v-if="activeViewMode === mode.value && confirmedMode !== mode.value"
          class="mode-button__state mode-button__state--viewing"
        >
          正在查看 · 未改变 PLC 模式
        </span>
        <span
          v-if="requestedMode === mode.value && confirmedMode !== mode.value"
          class="mode-button__state mode-button__state--pending"
        >
          已请求
        </span>
        <span
          v-if="mode.value === 'thermal' && !thermalAvailable"
          class="mode-button__state mode-button__state--blocked"
        >
          硬件未授权
        </span>
      </button>
      </div>

      <button
        type="button"
        class="mode-control__step mode-control__step--next"
        aria-label="切换到下一个追踪模式"
        data-test="mode-next"
        @click="browseAdjacent(1)"
      >
        <span aria-hidden="true">›</span>
      </button>
    </div>
    <p
      v-if="pending"
      class="mode-control__pending"
      role="status"
      aria-live="polite"
    >
      <span class="activity-dot" aria-hidden="true"></span>
      等待 PLC 安全停止并确认模式；当前模式仍为
      <strong>{{ modes.find((item) => item.value === confirmedMode)?.label }}</strong>
    </p>
  </div>
</template>

<style scoped>
.mode-control__carousel {
  display: grid;
  grid-template-columns: 36px minmax(0, 1fr) 36px;
  align-items: stretch;
  gap: 8px;
}

.mode-control__buttons {
  min-width: 0;
  touch-action: pan-y;
}

.mode-control__step {
  display: grid;
  place-items: center;
  min-width: 36px;
  padding: 0;
  border: 1px solid var(--line);
  border-radius: var(--radius-sm);
  color: var(--cyan);
  background: var(--bg-1);
  cursor: pointer;
}

.mode-control__step span {
  font-size: 1.8rem;
  line-height: 1;
  transform: translateY(-1px);
}

.mode-control__step:hover:not(:disabled),
.mode-control__step:focus-visible {
  border-color: var(--cyan);
  background: var(--cyan-dim);
}

.mode-control__step:disabled {
  color: var(--text-3);
  cursor: not-allowed;
  opacity: 0.45;
}

.mode-button--viewing {
  box-shadow: inset 0 0 0 1px var(--blue);
}

.mode-button__state--viewing {
  color: var(--blue);
}

.mode-control:focus-visible {
  outline: 1px solid var(--cyan);
  outline-offset: 4px;
}

@media (max-width: 700px) {
  .mode-control__carousel {
    grid-template-columns: 32px minmax(0, 1fr) 32px;
    gap: 5px;
  }

  .mode-control__step {
    min-width: 32px;
  }
}
</style>
