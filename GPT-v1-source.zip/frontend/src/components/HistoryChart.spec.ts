import { flushPromises, mount } from '@vue/test-utils'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import type { WeatherHistoryResponse } from '../api/contracts'
import { systemApi } from '../api/http'
import HistoryChart from './HistoryChart.vue'

vi.mock('../api/http', () => ({
  systemApi: {
    getWeatherHistory: vi.fn(),
  },
}))

function makeHistory(): WeatherHistoryResponse {
  const points = Array.from({ length: 10 }, (_, index) => ({
    valid_time: `2026-07-${String(8 + index).padStart(2, '0')}T13:03:00+08:00`,
    cloud_cover: 20 + index * 7,
    wind_speed: 10 + index,
    temperature_2m: 24 + index * 0.5,
    weather_code: index % 2,
    source: 'open_meteo_archive',
    data_kind: 'model_reanalysis',
    source_fetched_at: '2026-08-11T08:00:00Z',
  }))
  return {
    latitude: 30.25,
    longitude: 120.15,
    timezone: 'Asia/Shanghai',
    as_of: '2026-07-17T13:03:00+08:00',
    days: 10,
    generated_at: '2026-08-11T08:00:00Z',
    units: {
      cloud_cover: '%',
      wind_speed: 'km/h',
      temperature_2m: '°C',
    },
    source: 'open_meteo_archive',
    data_kind: 'model_reanalysis',
    points,
    partial: false,
    error: null,
  }
}

describe('HistoryChart', () => {
  beforeEach(() => {
    vi.mocked(systemApi.getWeatherHistory).mockReset()
  })

  it('按所选截止时间读取前10天，并绘制云量、风速和气温三条曲线', async () => {
    vi.mocked(systemApi.getWeatherHistory).mockResolvedValue(makeHistory())
    const wrapper = mount(HistoryChart, {
      props: {
        latitude: 30.25,
        longitude: 120.15,
        timezone: 'Asia/Shanghai',
        asOf: '2026-07-17T13:03:00+08:00',
      },
    })
    await flushPromises()

    expect(systemApi.getWeatherHistory).toHaveBeenCalledWith(
      '2026-07-17T13:03:00+08:00',
      10,
    )
    expect(wrapper.get('.history-chart').attributes('aria-label')).toContain(
      '截止所选时间的十日',
    )
    expect(wrapper.findAll('.history-chart circle')).toHaveLength(30)
    expect(wrapper.get('.series--cloud').attributes('d')).toMatch(/^M.+L/)
    expect(wrapper.get('.series--wind').attributes('d')).toMatch(/^M.+L/)
    expect(wrapper.get('.series--temperature').attributes('d')).toMatch(/^M.+L/)
    expect(wrapper.text()).toContain('过去9天 + 截止日')
    expect(wrapper.text()).toContain('历史再分析')
    expect(wrapper.get('.latest-values__wind').text()).toBe('19.0 km/h')
    expect(wrapper.get('.latest-values__temperature').text()).toBe('28.5°C')
  })

  it('接口失败时明确显示原因和重新加载按钮，不渲染空白曲线', async () => {
    vi.mocked(systemApi.getWeatherHistory).mockRejectedValue(
      new Error('请求失败（HTTP 404）'),
    )
    const wrapper = mount(HistoryChart, {
      props: {
        latitude: 30.25,
        longitude: 120.15,
        timezone: 'Asia/Shanghai',
        asOf: '2026-07-17T13:03:00+08:00',
      },
    })
    await flushPromises()

    expect(wrapper.find('.history-chart').exists()).toBe(false)
    expect(wrapper.get('.chart-state--error').text()).toContain(
      '请求失败（HTTP 404）',
    )
    expect(wrapper.get('.chart-state--error button').text()).toBe('重新加载')
  })
})
