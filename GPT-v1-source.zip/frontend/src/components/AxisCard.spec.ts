import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import AxisCard from './AxisCard.vue'
import { makeAxis } from '../test/fixtures'

const allowed = { allowed: true, reason: '允许一次有界微调' }
const blocked = { allowed: false, reason: '负方向硬限位已触发' }

describe('AxisCard', () => {
  it('显示 Python 太阳目标、PLC 反馈角及目标减反馈的偏差', () => {
    const wrapper = mount(AxisCard, {
      props: {
        axis: 'azimuth',
        title: '方位轴',
        telemetry: makeAxis({ actual_angle: 128.4, position_valid: true }),
        targetAngle: 130,
        targetVisible: true,
        controlMode: 'solar',
        confirmedMode: 'solar',
        targetValid: true,
        negativeLabel: '左',
        positiveLabel: '右',
        negativeDirection: 'az_left',
        positiveDirection: 'az_right',
        negativeAvailability: allowed,
        positiveAvailability: allowed,
      },
    })

    expect(wrapper.text()).toContain('PLC 反馈方位角')
    expect(wrapper.find('[data-test="actual-angle"]').text()).toBe('128.40°')
    expect(wrapper.text()).toContain('来自 PLC 的有效位置反馈')
    expect(wrapper.text()).toContain('Python 目标方位角')
    expect(wrapper.find('[data-test="target-angle"]').text()).toBe('130.00°')
    expect(wrapper.find('[data-test="axis-deviation"]').text()).toBe('+1.60°')
    expect(wrapper.text()).toContain('Python 目标 − PLC 反馈')
  })

  it('限位触发后只禁危险方向，允许反向退出', () => {
    const wrapper = mount(AxisCard, {
      props: {
        axis: 'azimuth',
        title: '方位轴',
        telemetry: makeAxis({ negative_limit: true }),
        targetAngle: 130,
        targetVisible: true,
        controlMode: 'solar',
        confirmedMode: 'solar',
        targetValid: true,
        negativeLabel: '左',
        positiveLabel: '右',
        negativeDirection: 'az_left',
        positiveDirection: 'az_right',
        negativeAvailability: blocked,
        positiveAvailability: allowed,
      },
    })
    expect(
      wrapper
        .find('[data-test="azimuth-negative-jog"]')
        .attributes('disabled'),
    ).toBeDefined()
    expect(
      wrapper
        .find('[data-test="azimuth-positive-jog"]')
        .attributes('disabled'),
    ).toBeUndefined()
    expect(wrapper.text()).toContain('硬限位已触发')
  })

  it('PLC 位置反馈无效时不把占位角用于偏差计算', () => {
    const wrapper = mount(AxisCard, {
      props: {
        axis: 'azimuth',
        title: '方位轴',
        telemetry: makeAxis({ actual_angle: 0, position_valid: false }),
        targetAngle: 130,
        targetVisible: true,
        controlMode: 'solar',
        confirmedMode: 'solar',
        targetValid: true,
        negativeLabel: '左',
        positiveLabel: '右',
        negativeDirection: 'az_left',
        positiveDirection: 'az_right',
        negativeAvailability: blocked,
        positiveAvailability: blocked,
      },
    })

    expect(wrapper.find('[data-test="actual-angle"]').text()).toBe('—')
    expect(wrapper.find('[data-test="axis-deviation"]').text()).toBe('—')
    expect(wrapper.text()).toContain('PLC 位置反馈无效')
  })

  it('热成像模式隐藏目标角和偏差，保留 PLC 实际角', () => {
    const wrapper = mount(AxisCard, {
      props: {
        axis: 'elevation',
        title: '高度轴',
        telemetry: makeAxis({ actual_angle: 42.3 }),
        targetAngle: 45,
        targetVisible: false,
        controlMode: 'thermal',
        confirmedMode: 'thermal',
        targetValid: true,
        negativeLabel: '下',
        positiveLabel: '上',
        negativeDirection: 'alt_down',
        positiveDirection: 'alt_up',
        negativeAvailability: blocked,
        positiveAvailability: blocked,
      },
    })
    expect(wrapper.find('[data-test="actual-angle"]').text()).toContain('42.30')
    expect(wrapper.find('[data-test="target-angle"]').exists()).toBe(false)
    expect(wrapper.find('[data-test="axis-deviation"]').exists()).toBe(false)
    expect(wrapper.find('[data-test="thermal-target-hidden"]').text()).toContain(
      '热点偏移',
    )
  })

  it('手动模式不会把控制依据误标成热点偏移', () => {
    const wrapper = mount(AxisCard, {
      props: {
        axis: 'azimuth',
        title: '方位轴',
        telemetry: makeAxis({ actual_angle: 42.3 }),
        targetAngle: 45,
        targetVisible: false,
        controlMode: 'manual',
        confirmedMode: 'manual',
        targetValid: true,
        negativeLabel: '左',
        positiveLabel: '右',
        negativeDirection: 'az_left',
        positiveDirection: 'az_right',
        negativeAvailability: blocked,
        positiveAvailability: blocked,
      },
    })

    expect(wrapper.text()).toContain('单次有界微调')
    expect(wrapper.text()).toContain('手动模式不使用自动目标角')
    expect(wrapper.text()).not.toContain('热点偏移')
  })

  it('无效控制目标只显示太阳位置且不计算偏差', () => {
    const wrapper = mount(AxisCard, {
      props: {
        axis: 'azimuth',
        title: '方位轴',
        telemetry: makeAxis({ actual_angle: 128.4, position_valid: true }),
        targetAngle: 130,
        targetVisible: true,
        controlMode: 'solar',
        confirmedMode: 'manual',
        targetValid: false,
        negativeLabel: '左',
        positiveLabel: '右',
        negativeDirection: 'az_left',
        positiveDirection: 'az_right',
        negativeAvailability: blocked,
        positiveAvailability: blocked,
      },
    })

    expect(wrapper.text()).toContain('Python 太阳方位角（仅显示）')
    expect(wrapper.text()).toContain('未进入控制链')
    expect(wrapper.text()).toContain('PLC 当前为手动微调')
    expect(wrapper.find('[data-test="axis-deviation"]').text()).toBe('—')
  })
})
