<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import type { ThermalState } from '../api/contracts'
import type { ThermalVariant } from '../stores/settings'
import { formatAge, formatRatioPercent, formatTimestamp } from '../utils/format'

const props = defineProps<{
  thermal: ThermalState
  variant: ThermalVariant
  timezone: string
}>()

const emit = defineEmits<{
  'update:variant': [variant: ThermalVariant]
}>()

const mediaLoading = ref(true)
const mediaError = ref(false)
const mediaRevision = ref(0)

const guidance = computed(() => props.thermal.guidance)
const mediaUrl = computed(() => {
  const configured =
    props.variant === 'annotated'
      ? props.thermal.annotated_media_url
      : props.thermal.original_media_url
  const fallback =
    props.variant === 'annotated'
      ? '/media/thermal/annotated.mjpeg'
      : '/media/thermal/original.mjpeg'
  const path = configured || fallback
  if (/^https?:\/\//i.test(path)) return path
  const base = (import.meta.env.VITE_MEDIA_BASE_URL || '').replace(/\/$/, '')
  return `${base}${path.startsWith('/') ? path : `/${path}`}`
})
const streamUsable = computed(
  () => props.thermal.camera_online && props.thermal.stream_available,
)
const freshnessLabel = computed(() => {
  if (guidance.value.stale) return '过期'
  const age = props.thermal.frame_age_seconds
  return Number.isFinite(age) ? formatAge(Math.floor(Number(age))) : '未知'
})

watch(
  () => [props.variant, props.thermal.camera_online, props.thermal.stream_available],
  () => {
    mediaLoading.value = true
    mediaError.value = false
    mediaRevision.value += 1
  },
)

function setVariant(variant: ThermalVariant): void {
  if (variant !== props.variant) emit('update:variant', variant)
}

function directionLabel(): string {
  const horizontal = {
    left: '向左',
    right: '向右',
    none: '水平停止',
  }[guidance.value.horizontal_direction]
  const vertical = {
    up: '向上',
    down: '向下',
    none: '垂直停止',
  }[guidance.value.vertical_direction]
  return `${horizontal} / ${vertical}`
}
</script>

<template>
  <figure class="thermal-view" aria-labelledby="thermal-title">
    <header class="visual-header">
      <div>
        <p class="eyebrow">LIVE THERMAL FEED</p>
        <h2 id="thermal-title">固定热成像相机 · 实际画面</h2>
      </div>
      <div class="segmented" aria-label="热成像画面类型">
        <button
          type="button"
          :aria-pressed="variant === 'annotated'"
          :class="{ active: variant === 'annotated' }"
          @click="setVariant('annotated')"
        >
          算法标注
        </button>
        <button
          type="button"
          :aria-pressed="variant === 'original'"
          :class="{ active: variant === 'original' }"
          @click="setVariant('original')"
        >
          原始画面
        </button>
      </div>
    </header>

    <div
      class="thermal-stage"
      :class="{ 'thermal-stage--offline': !streamUsable || mediaError }"
    >
      <img
        v-if="streamUsable && !mediaError"
        :key="mediaRevision"
        class="thermal-stage__media"
        :src="mediaUrl"
        :alt="variant === 'annotated' ? 'Python 输出的实时热成像标注画面' : 'Python 输出的实时热成像原始画面'"
        @load="mediaLoading = false"
        @error="
          mediaError = true;
          mediaLoading = false
        "
      />

      <div
        v-if="!streamUsable || mediaError"
        class="thermal-placeholder"
        role="status"
        data-test="thermal-offline"
      >
        <strong>请连接摄像头</strong>
      </div>

      <div
        v-else-if="mediaLoading"
        class="thermal-stage__overlay"
        role="status"
      >
        正在连接 Python 媒体流…
      </div>

      <div
        v-if="
          streamUsable &&
          !mediaError &&
          (guidance.stale || thermal.frame_age_seconds === null)
        "
        class="thermal-stage__stale"
        role="alert"
      >
        画面数据已过期或新鲜度未知 · 热成像动作应停止
      </div>
      <div
        v-if="
          streamUsable &&
          !mediaError &&
          (thermal.simulation_active || guidance.simulated)
        "
        class="thermal-stage__simulation"
      >
        模拟输入 · 非现场真实画面
      </div>
    </div>

    <figcaption class="thermal-metadata">
      <div>
        <span>帧序号</span>
        <strong>{{ guidance.frame_id }}</strong>
      </div>
      <div>
        <span>帧时间</span>
        <strong>{{ formatTimestamp(guidance.captured_at, timezone) }}</strong>
      </div>
      <div>
        <span>画面新鲜度</span>
        <strong :class="{ 'text-danger': guidance.stale }">{{ freshnessLabel }}</strong>
      </div>
      <div>
        <span>热点有效</span>
        <strong>{{ guidance.hotspot_valid ? '有效' : '无效' }}</strong>
      </div>
      <div>
        <span>水平偏移</span>
        <strong>{{ guidance.hotspot_valid ? guidance.dx_normalized.toFixed(3) : '—' }}</strong>
      </div>
      <div>
        <span>垂直偏移</span>
        <strong>{{ guidance.hotspot_valid ? guidance.dy_normalized.toFixed(3) : '—' }}</strong>
      </div>
      <div>
        <span>热点置信度</span>
        <strong>{{ formatRatioPercent(guidance.confidence) }}</strong>
      </div>
      <div>
        <span>对齐状态</span>
        <strong>{{ guidance.aligned ? '已对齐 · 两轴停止' : directionLabel() }}</strong>
      </div>
    </figcaption>
  </figure>
</template>

<style scoped>
.thermal-stage--offline {
  background: #000;
}

.thermal-stage--offline .thermal-placeholder {
  position: absolute;
  inset: 0;
  max-width: none;
  justify-content: center;
  padding: 24px;
  background: #000;
}

.thermal-stage--offline .thermal-placeholder strong {
  color: #fff;
  font-size: clamp(1rem, 2vw, 1.35rem);
  font-weight: 600;
  letter-spacing: 0.08em;
}
</style>
