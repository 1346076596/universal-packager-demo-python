<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import type { Alarm } from '../api/contracts'
import { formatTimestamp } from '../utils/format'

const props = defineProps<{
  alarms: Alarm[]
  timezone?: string
}>()

const hidden = ref(new Set<string>())
const visibleAlarms = computed(() =>
  props.alarms.filter((alarm) => !hidden.value.has(alarm.code)),
)

watch(
  () => props.alarms.map((alarm) => alarm.code),
  (activeIds) => {
    const active = new Set(activeIds)
    hidden.value = new Set([...hidden.value].filter((id) => active.has(id)))
  },
)

function dismiss(id: string): void {
  hidden.value = new Set(hidden.value).add(id)
}

function severityLabel(alarm: Alarm): string {
  if (alarm.severity === 'critical') return '严重'
  if (alarm.severity === 'warning') return '警告'
  return '提示'
}

function alarmTitle(alarm: Alarm): string {
  const sourceTitle = alarm.source.split('：')[1]
  return sourceTitle || alarm.source || alarm.code
}
</script>

<template>
  <section
    v-if="visibleAlarms.length"
    class="alarm-stack"
    aria-label="当前系统报警"
    aria-live="assertive"
  >
    <article
      v-for="alarm in visibleAlarms"
      :key="alarm.code"
      class="alarm"
      :class="`alarm--${alarm.severity}`"
    >
      <span class="alarm__marker" aria-hidden="true">!</span>
      <div class="alarm__body">
        <div class="alarm__heading">
          <strong>{{ severityLabel(alarm) }} · {{ alarmTitle(alarm) }}</strong>
          <span>{{ alarm.code }}</span>
        </div>
        <p>{{ alarm.message }}</p>
      </div>
      <button
        v-if="alarm.severity === 'info'"
        type="button"
        class="alarm__dismiss"
        :aria-label="`隐藏提示：${alarmTitle(alarm)}`"
        @click="dismiss(alarm.code)"
      >
        知道了
      </button>
    </article>
  </section>
</template>
