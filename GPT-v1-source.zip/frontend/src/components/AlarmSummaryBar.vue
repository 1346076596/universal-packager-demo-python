<script setup lang="ts">
import { computed, ref } from 'vue'
import type { Alarm } from '../api/contracts'

const props = defineProps<{
  alarms: Alarm[]
  statusText: string
}>()

const expanded = ref(false)
const criticalCount = computed(() => props.alarms.filter((alarm) => alarm.severity === 'critical').length)
const warningCount = computed(() => props.alarms.filter((alarm) => alarm.severity === 'warning').length)
const lead = computed(() => props.alarms[0])
</script>

<template>
  <section class="alarm-summary" aria-label="报警摘要">
    <span class="alarm-summary__bell" aria-hidden="true">♢</span>
    <span class="alarm-count alarm-count--critical"><b>{{ criticalCount }}</b> 严重</span>
    <span class="alarm-count alarm-count--warning"><b>{{ warningCount }}</b> 警告</span>
    <p>{{ lead?.message || statusText }}</p>
    <button type="button" :disabled="!alarms.length" @click="expanded = !expanded">
      查看全部报警 <span aria-hidden="true">›</span>
    </button>
    <div v-if="expanded" class="alarm-drawer" role="dialog" aria-label="活动报警详情">
      <header><strong>活动报警</strong><button type="button" aria-label="关闭" @click="expanded = false">×</button></header>
      <ul>
        <li v-for="alarm in alarms" :key="alarm.code" :class="`alarm-drawer__${alarm.severity}`">
          <strong>{{ alarm.source }}</strong><span>{{ alarm.code }}</span><p>{{ alarm.message }}</p>
        </li>
      </ul>
    </div>
  </section>
</template>

<style scoped>
.alarm-summary {
  min-width: 0;
  height: 100%;
  display: grid;
  grid-template-columns: auto auto auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 0.75rem;
  position: relative;
  margin: 0 var(--console-edge);
  padding: 0 0.9rem;
  border: 1px solid var(--line);
  border-left: 2px solid var(--red);
  border-radius: var(--radius-sm);
  background: linear-gradient(90deg, rgb(75 32 40 / 30%), var(--bg-2) 30%);
}

.alarm-summary__bell {
  color: var(--amber);
  font-size: 1.1rem;
}

.alarm-count {
  padding: 0.35rem 0.65rem;
  border: 1px solid var(--line);
  border-radius: 4px;
  font-size: 0.68rem;
  white-space: nowrap;
}

.alarm-count b {
  margin-right: 0.25rem;
  font-family: var(--mono);
  font-size: 0.82rem;
}

.alarm-count--critical { color: #ff9da2; background: rgb(75 32 40 / 60%); }
.alarm-count--warning { color: var(--amber); background: rgb(74 56 23 / 58%); }

.alarm-summary > p {
  overflow: hidden;
  color: var(--text-2);
  font-size: 0.72rem;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.alarm-summary > button,
.alarm-drawer button {
  border: 0;
  color: var(--text-2);
  background: transparent;
  cursor: pointer;
}

.alarm-summary > button {
  font-size: 0.66rem;
}

.alarm-summary > button:disabled { opacity: 0.45; }

.alarm-drawer {
  width: min(36rem, 88vw);
  max-height: min(30rem, 70vh);
  position: absolute;
  top: calc(100% + 0.35rem);
  right: 0;
  z-index: 40;
  overflow: auto;
  border: 1px solid var(--line-strong);
  border-radius: var(--radius-md);
  background: #0c141d;
  box-shadow: 0 24px 60px rgb(0 0 0 / 60%);
}

.alarm-drawer header {
  display: flex;
  justify-content: space-between;
  padding: 0.75rem 0.9rem;
  border-bottom: 1px solid var(--line);
}

.alarm-drawer ul { margin: 0; padding: 0.45rem; list-style: none; }
.alarm-drawer li { padding: 0.65rem; border-left: 3px solid var(--line); }
.alarm-drawer li + li { margin-top: 0.4rem; }
.alarm-drawer li span { margin-left: 0.5rem; color: var(--text-3); font-family: var(--mono); font-size: 0.62rem; }
.alarm-drawer li p { margin-top: 0.25rem; color: var(--text-2); font-size: 0.7rem; }
.alarm-drawer__critical { border-color: var(--red) !important; }
.alarm-drawer__warning { border-color: var(--amber) !important; }
</style>
