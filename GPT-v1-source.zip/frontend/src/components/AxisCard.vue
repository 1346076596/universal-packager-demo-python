<script setup lang="ts">
import { computed } from 'vue'
import type {
  AxisName,
  AxisTelemetry,
  ControlMode,
  ManualDirection,
} from '../api/contracts'
import type { JogAvailability } from '../stores/control'
import { formatAngle } from '../utils/format'

const props = withDefaults(defineProps<{
  axis: AxisName
  title: string
  telemetry: AxisTelemetry
  targetAngle: number | null
  targetVisible: boolean
  controlMode: ControlMode
  confirmedMode: ControlMode
  targetValid: boolean
  negativeLabel: string
  positiveLabel: string
  negativeDirection: ManualDirection
  positiveDirection: ManualDirection
  negativeAvailability: JogAvailability
  positiveAvailability: JogAvailability
  commandPending?: boolean
  compact?: boolean
}>(), {
  commandPending: false,
  compact: false,
})

const emit = defineEmits<{
  jog: [axis: AxisName, direction: ManualDirection]
}>()

const deviation = computed(() => {
  if (
    !props.targetVisible ||
    !props.targetValid ||
    !props.telemetry.position_valid ||
    !Number.isFinite(props.targetAngle) ||
    !Number.isFinite(props.telemetry.actual_angle)
  ) {
    return null
  }
  return Number(props.targetAngle) - Number(props.telemetry.actual_angle)
})

const actualAngleLabel = computed(() =>
  props.axis === 'azimuth' ? 'PLC 反馈方位角' : 'PLC 反馈高度角',
)

const targetAngleLabel = computed(() =>
  props.axis === 'azimuth'
    ? props.targetValid
      ? 'Python 目标方位角'
      : 'Python 太阳方位角（仅显示）'
    : props.targetValid
      ? 'Python 目标高度角'
      : 'Python 太阳高度角（仅显示）',
)

const viewingConfirmedMode = computed(
  () => props.controlMode === props.confirmedMode,
)

const modeLabel = (mode: ControlMode): string =>
  ({ manual: '手动微调', solar: '太阳轨迹', thermal: '热成像追踪' })[mode]

const axisState = computed(() => {
  const axis = props.telemetry
  if (axis.negative_limit && axis.positive_limit) {
    return { level: 'critical', text: '两端限位冲突 · 轴已锁定' }
  }
  if (axis.fault) {
    return {
      level: 'critical',
      text: `轴故障 · ${axis.fault_reason || '等待人工复位'}`,
    }
  }
  if (!axis.position_valid) {
    return { level: 'critical', text: '位置反馈无效 · 禁止动作' }
  }
  if (axis.timed_out) return { level: 'critical', text: '动作超时 · 已停止' }
  if (axis.moving) {
    return {
      level: 'active',
      text: `运行中 · ${directionText(axis.direction)}`,
    }
  }
  if (axis.at_target) return { level: 'normal', text: '已到位 · 输出停止' }
  return { level: 'idle', text: '待机 · 输出停止' }
})

function directionText(direction: string): string {
  if (direction === 'negative') return `向${props.negativeLabel}`
  if (direction === 'positive') return `向${props.positiveLabel}`
  if (direction === 'stopped') return '停止'
  return direction || '状态未知'
}
</script>

<template>
  <article
    class="panel axis-card"
    :class="{ 'axis-card--compact': compact }"
    :aria-labelledby="`${axis}-axis-title`"
  >
    <header class="panel__header axis-card__header">
      <div>
        <p class="eyebrow">{{ axis === 'azimuth' ? 'AZIMUTH' : 'ELEVATION' }}</p>
        <h2 :id="`${axis}-axis-title`">{{ title }}</h2>
      </div>
      <span class="state-label" :class="`state-label--${axisState.level}`">
        {{ axisState.text }}
      </span>
    </header>

    <div class="axis-readouts">
      <div class="readout readout--primary">
        <span>{{ actualAngleLabel }}</span>
        <strong data-test="actual-angle">
          {{ formatAngle(telemetry.position_valid ? telemetry.actual_angle : null, 2) }}
        </strong>
        <small>
          {{ telemetry.position_valid ? '来自 PLC 的有效位置反馈' : 'PLC 位置反馈无效' }}
        </small>
      </div>
      <template v-if="targetVisible">
        <div class="readout">
          <span>{{ targetAngleLabel }}</span>
          <strong data-test="target-angle">{{ formatAngle(targetAngle, 2) }}</strong>
          <small>
            {{
              !targetValid
                ? viewingConfirmedMode
                  ? 'Python 太阳位置仅供显示，未进入控制链'
                  : `Python 太阳位置仅供显示，未进入控制链；仅查看，PLC 当前为${modeLabel(confirmedMode)}`
                : viewingConfirmedMode
                  ? '来自 Python 太阳轨迹控制目标'
                  : `仅查看；PLC 当前为${modeLabel(confirmedMode)}，未采用该目标`
            }}
          </small>
        </div>
        <div class="readout">
          <span>跟踪偏差</span>
          <strong data-test="axis-deviation">
            {{ deviation === null ? '—' : `${deviation >= 0 ? '+' : ''}${deviation.toFixed(2)}°` }}
          </strong>
          <small>
            {{
              viewingConfirmedMode
                ? 'Python 目标 − PLC 反馈'
                : '仅供查看：Python 目标 − PLC 反馈'
            }}
          </small>
        </div>
      </template>
      <div v-else class="readout readout--notice" data-test="thermal-target-hidden">
        <span>控制依据</span>
        <strong>{{ controlMode === 'manual' ? '单次有界微调' : '热点偏移' }}</strong>
        <small>
          {{
            !viewingConfirmedMode
              ? `仅查看；PLC 当前为${modeLabel(confirmedMode)}`
              : controlMode === 'manual'
                ? '手动模式不使用自动目标角'
                : '热成像模式不使用目标角'
          }}
        </small>
      </div>
    </div>

    <div class="limit-grid" aria-label="限位状态">
      <div
        class="limit-state"
        :class="{ 'limit-state--triggered': telemetry.negative_limit }"
      >
        <span class="status-dot" aria-hidden="true"></span>
        <div>
          <strong>{{ negativeLabel }}限位</strong>
          <span>{{ telemetry.negative_limit ? '硬限位已触发' : '未触发，方向可用' }}</span>
        </div>
      </div>
      <div
        class="limit-state"
        :class="{ 'limit-state--triggered': telemetry.positive_limit }"
      >
        <span class="status-dot" aria-hidden="true"></span>
        <div>
          <strong>{{ positiveLabel }}限位</strong>
          <span>{{ telemetry.positive_limit ? '硬限位已触发' : '未触发，方向可用' }}</span>
        </div>
      </div>
    </div>

    <div class="axis-actions" aria-label="单次微调">
      <button
        type="button"
        class="control-button"
        :data-test="`${axis}-negative-jog`"
        :disabled="!negativeAvailability.allowed || commandPending"
        :title="negativeAvailability.reason"
        @click="emit('jog', axis, negativeDirection)"
      >
        <span aria-hidden="true">−</span>
        向{{ negativeLabel }}微调
      </button>
      <button
        type="button"
        class="control-button"
        :data-test="`${axis}-positive-jog`"
        :disabled="!positiveAvailability.allowed || commandPending"
        :title="positiveAvailability.reason"
        @click="emit('jog', axis, positiveDirection)"
      >
        <span aria-hidden="true">＋</span>
        向{{ positiveLabel }}微调
      </button>
    </div>
    <p class="axis-card__guard">
      {{
        negativeAvailability.allowed || positiveAvailability.allowed
          ? '每次点击只提交一次有界动作，仍由 Python 与 PLC 再次校验。'
          : negativeAvailability.reason
      }}
    </p>
  </article>
</template>
