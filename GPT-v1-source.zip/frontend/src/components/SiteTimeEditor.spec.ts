import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import SiteTimeEditor from './SiteTimeEditor.vue'

const config = {
  latitude: 30.25,
  longitude: 120.15,
  timezone: 'Asia/Shanghai',
  calculation_time_override: null,
}

describe('SiteTimeEditor', () => {
  it('校验经纬度范围并阻止无效保存', async () => {
    const wrapper = mount(SiteTimeEditor, {
      props: {
        open: true,
        config,
        saving: false,
      },
      global: {
        stubs: { Teleport: true },
      },
    })
    const latitude = wrapper.find('input[name="latitude"]')
    await latitude.setValue('-91')
    expect(wrapper.text()).toContain('纬度必须在 -90° 到 90° 之间')
    expect(wrapper.find('button[type="submit"]').attributes('disabled')).toBeDefined()
  })

  it('保存临时计算时间时发出带时区的 ISO 时间', async () => {
    const wrapper = mount(SiteTimeEditor, {
      props: {
        open: true,
        config,
        saving: false,
      },
      global: {
        stubs: { Teleport: true },
      },
    })
    const radios = wrapper.findAll('input[type="radio"]')
    await radios[1]?.setValue()
    await wrapper.find('input[name="calculation-time"]').setValue(
      '2026-07-31T12:30',
    )
    await wrapper.find('form').trigger('submit')
    const emitted = wrapper.emitted('save')?.[0]?.[0] as
      | typeof config
      | undefined
    expect(emitted?.latitude).toBe(30.25)
    expect(emitted?.calculation_time_override).toMatch(
      /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:00\.000Z$/,
    )
  })

  it('实时快照替换配置对象时保留尚未保存的表单输入', async () => {
    const wrapper = mount(SiteTimeEditor, {
      props: {
        open: true,
        config,
        saving: false,
      },
      global: {
        stubs: { Teleport: true },
      },
    })

    await wrapper.find('input[name="longitude"]').setValue('169')
    const radios = wrapper.findAll('input[type="radio"]')
    await radios[1]?.setValue()

    await wrapper.setProps({ config: { ...config } })

    expect(
      (wrapper.find('input[name="longitude"]').element as HTMLInputElement)
        .value,
    ).toBe('169')
    expect(
      (wrapper.find('input[type="radio"][value="override"]')
        .element as HTMLInputElement).checked,
    ).toBe(true)
    expect(wrapper.find('input[name="calculation-time"]').exists()).toBe(true)
  })

  it('拒绝夏令时跳变中不存在的当地时间', async () => {
    const wrapper = mount(SiteTimeEditor, {
      props: {
        open: true,
        config: { ...config, timezone: 'America/New_York' },
        saving: false,
      },
      global: {
        stubs: { Teleport: true },
      },
    })

    const radios = wrapper.findAll('input[type="radio"]')
    await radios[1]?.setValue()
    await wrapper
      .find('input[name="calculation-time"]')
      .setValue('2026-03-08T02:30')

    expect(wrapper.text()).toContain('所选当地时间不存在或无效')
    expect(wrapper.find('button[type="submit"]').attributes('disabled')).toBeDefined()
  })
})
