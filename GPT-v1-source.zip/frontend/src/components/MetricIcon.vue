<script setup lang="ts">
defineProps<{
  name: 'cloud' | 'wind' | 'weather' | 'radiation' | 'visibility' | 'clock' | 'temperature'
}>()
</script>

<template>
  <svg class="metric-icon" viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <g v-if="name === 'cloud' || name === 'weather'">
      <path d="M6.5 18h10.2a4.3 4.3 0 0 0 .3-8.6 6 6 0 0 0-11.3 1.8A3.4 3.4 0 0 0 6.5 18Z" />
    </g>
    <g v-else-if="name === 'wind'">
      <path d="M3 8h11.5c2.8 0 2.8-4 0-4-1.4 0-2.2.8-2.2 2M3 12h16c2.8 0 2.8 4 0 4-1.4 0-2.2-.8-2.2-2M3 16h8" />
    </g>
    <g v-else-if="name === 'radiation'">
      <circle cx="12" cy="12" r="3.5" />
      <path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2.1 2.1M16.9 16.9 19 19M19 5l-2.1 2.1M7.1 16.9 5 19" />
    </g>
    <g v-else-if="name === 'visibility'">
      <path d="M2.5 12s3.2-5 9.5-5 9.5 5 9.5 5-3.2 5-9.5 5-9.5-5-9.5-5Z" />
      <circle cx="12" cy="12" r="2.5" />
    </g>
    <g v-else-if="name === 'clock'">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5l3.5 2" />
    </g>
    <g v-else>
      <path d="M10 5a2 2 0 0 1 4 0v8.2a4 4 0 1 1-4 0V5Z" />
      <path d="M12 8v7" />
    </g>
  </svg>
</template>

<style scoped>
.metric-icon {
  width: 1.45rem;
  height: 1.45rem;
  flex: 0 0 auto;
  stroke: currentColor;
  stroke-width: 1.55;
  stroke-linecap: round;
  stroke-linejoin: round;
}
</style>
