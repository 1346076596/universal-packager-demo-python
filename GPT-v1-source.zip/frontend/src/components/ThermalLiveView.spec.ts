import { describe, expect, it } from 'vitest'
import { mount } from '@vue/test-utils'
import ThermalLiveView from './ThermalLiveView.vue'
import { makeThermal } from '../test/fixtures'

describe('ThermalLiveView', () => {
  it('只使用 Python 提供的真实媒体 URL，并切换原始/标注画面', async () => {
    const wrapper = mount(ThermalLiveView, {
      props: {
        thermal: makeThermal({
          original_media_url: '/media/thermal/original.mjpeg',
          annotated_media_url: '/media/thermal/annotated.mjpeg',
        }),
        variant: 'annotated',
        timezone: 'Asia/Shanghai',
      },
    })
    expect(wrapper.find('img').attributes('src')).toBe(
      '/media/thermal/annotated.mjpeg',
    )
    await wrapper.findAll('.segmented button')[1]?.trigger('click')
    expect(wrapper.emitted('update:variant')).toEqual([['original']])
  })

  it('相机离线或未配置时显示纯黑画面并居中提示连接摄像头', () => {
    const wrapper = mount(ThermalLiveView, {
      props: {
        thermal: makeThermal({
          camera_online: false,
          stream_available: false,
          camera_status: 'offline',
          display_warning: '固定热像仪未连接',
        }),
        variant: 'annotated',
        timezone: 'Asia/Shanghai',
      },
    })
    expect(wrapper.find('img').exists()).toBe(false)
    expect(wrapper.find('.thermal-stage').classes()).toContain(
      'thermal-stage--offline',
    )
    expect(wrapper.find('[data-test="thermal-offline"]').text()).toBe(
      '请连接摄像头',
    )
    expect(wrapper.find('.thermal-stage__simulation').exists()).toBe(false)
    expect(wrapper.find('.thermal-stage__stale').exists()).toBe(false)
  })

  it('媒体流加载失败后移除坏图并显示同一连接提示', async () => {
    const wrapper = mount(ThermalLiveView, {
      props: {
        thermal: makeThermal(),
        variant: 'annotated',
        timezone: 'Asia/Shanghai',
      },
    })

    await wrapper.find('img').trigger('error')
    expect(wrapper.find('img').exists()).toBe(false)
    expect(wrapper.find('.thermal-stage').classes()).toContain(
      'thermal-stage--offline',
    )
    expect(wrapper.find('[data-test="thermal-offline"]').text()).toBe(
      '请连接摄像头',
    )
  })
})
