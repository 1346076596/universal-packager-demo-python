<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { formatTimestamp } from '../utils/format'

const props = defineProps<{
  latitude: number
  longitude: number
  timezone: string
  asOf: string
}>()

interface LayerChoice {
  layer: string
  matrix: string
  label: string
  precision: '10分钟级' | '日图降级'
  effectiveAt: string
}

interface BboxPiece {
  west: number
  east: number
  width: number
}

const GIBS = 'https://gibs.earthdata.nasa.gov'
const choice = ref<LayerChoice | null>(null)
const loading = ref(false)
const error = ref<string | null>(null)
let loadSequence = 0

const cutoffMs = computed(() => Date.parse(props.asOf))
const imageryRequestKey = computed(() => {
  const cutoff = cutoffMs.value
  const minute = Number.isFinite(cutoff) ? Math.floor(cutoff / 60_000) : props.asOf
  return `${props.latitude.toFixed(4)}|${props.longitude.toFixed(4)}|${props.timezone}|${minute}`
})
const latRange = computed(() => {
  const span = Math.min(52, 26 + Math.abs(props.latitude) * 0.22)
  let south = props.latitude - span / 2
  let north = props.latitude + span / 2
  if (south < -90) { north += -90 - south; south = -90 }
  if (north > 90) { south -= north - 90; north = 90 }
  return { south: Math.max(-90, south), north: Math.min(90, north) }
})

const bboxPieces = computed<BboxPiece[]>(() => {
  const cosine = Math.max(0.25, Math.cos((props.latitude * Math.PI) / 180))
  const span = Math.min(130, 38 / cosine)
  const west = props.longitude - span / 2
  const east = props.longitude + span / 2
  if (west < -180) {
    const firstWidth = -180 - west
    return [
      { west: west + 360, east: 180, width: firstWidth / span },
      { west: -180, east, width: (east + 180) / span },
    ]
  }
  if (east > 180) {
    return [
      { west, east: 180, width: (180 - west) / span },
      { west: -180, east: east - 360, width: (east - 180) / span },
    ]
  }
  return [{ west, east, width: 1 }]
})

const imageUrls = computed(() => {
  if (!choice.value) return []
  return bboxPieces.value.map((piece) => {
    const params = new URLSearchParams({
      SERVICE: 'WMS', REQUEST: 'GetMap', VERSION: '1.1.1',
      LAYERS: choice.value!.layer, STYLES: '', FORMAT: 'image/png',
      TRANSPARENT: 'TRUE', SRS: 'EPSG:4326',
      BBOX: `${piece.west.toFixed(4)},${latRange.value.south.toFixed(4)},${piece.east.toFixed(4)},${latRange.value.north.toFixed(4)}`,
      WIDTH: String(Math.max(256, Math.round(1024 * piece.width))), HEIGHT: '512',
      TIME:
        choice.value!.precision === '日图降级'
          ? choice.value!.effectiveAt.slice(0, 10)
          : choice.value!.effectiveAt.replace(/\.\d{3}Z$/, 'Z'),
    })
    return `${GIBS}/wms/epsg4326/best/wms.cgi?${params.toString()}`
  })
})

function durationMilliseconds(value: string): number {
  const match = value.match(/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/)
  if (!match) return 0
  return ((Number(match[1] || 0) * 24 * 60 + Number(match[2] || 0) * 60 + Number(match[3] || 0)) * 60 + Number(match[4] || 0)) * 1000
}

function latestDomainTime(xml: string, cutoff: number): string | null {
  const document = new DOMParser().parseFromString(xml, 'application/xml')
  const candidates: number[] = []
  const text = Array.from(document.querySelectorAll('Domain, Value')).map((node) => node.textContent || '').join(',')
  for (const token of text.split(',')) {
    const parts = token.trim().split('/')
    if (parts.length === 1) {
      const instant = Date.parse(parts[0] || '')
      if (Number.isFinite(instant) && instant <= cutoff) candidates.push(instant)
      continue
    }
    const start = Date.parse(parts[0] || '')
    const end = Date.parse(parts[1] || '')
    const step = durationMilliseconds(parts[2] || '')
    if (!Number.isFinite(start) || !Number.isFinite(end) || step <= 0 || start > cutoff) continue
    const bounded = Math.min(end, cutoff)
    candidates.push(start + Math.floor((bounded - start) / step) * step)
  }
  return candidates.length ? new Date(Math.max(...candidates)).toISOString() : null
}

async function domainTime(layer: string, matrix: string, from: number, to: number): Promise<string | null> {
  const isoSeconds = (value: number) =>
    new Date(value).toISOString().replace(/\.\d{3}Z$/, 'Z')
  const range = `${isoSeconds(from)}--${isoSeconds(to)}`
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), 5_000)
  try {
    const response = await fetch(`${GIBS}/wmts/epsg4326/best/1.0.0/${layer}/default/${matrix}/all/${range}.xml`, {
      cache: 'no-store',
      signal: controller.signal,
    })
    if (!response.ok) return null
    return latestDomainTime(await response.text(), to)
  } finally {
    window.clearTimeout(timeout)
  }
}

function recentLayers(): Array<Omit<LayerChoice, 'effectiveAt'>> {
  // 地球同步卫星在高纬区域接近或超出圆盘边界；直接使用全球极轨日图，
  // 避免把透明圆盘边缘误报为所选站点的有效云图。
  if (Math.abs(props.latitude) > 65) return []
  const longitude = ((props.longitude + 540) % 360) - 180
  if (longitude >= 75 || longitude <= -150) {
    return [
      { layer: 'Himawari_AHI_Band13_Clean_Infrared', matrix: '2km', label: 'Himawari-9 清洁红外', precision: '10分钟级' },
      { layer: 'GOES-West_ABI_GeoColor', matrix: '1km', label: 'GOES-West GeoColor', precision: '10分钟级' },
    ]
  }
  if (longitude < -25) {
    return [
      { layer: 'GOES-East_ABI_GeoColor', matrix: '1km', label: 'GOES-East GeoColor', precision: '10分钟级' },
      { layer: 'GOES-West_ABI_GeoColor', matrix: '1km', label: 'GOES-West GeoColor', precision: '10分钟级' },
    ]
  }
  return [
    { layer: 'Himawari_AHI_Band13_Clean_Infrared', matrix: '2km', label: 'Himawari-9 清洁红外', precision: '10分钟级' },
    { layer: 'GOES-East_ABI_GeoColor', matrix: '1km', label: 'GOES-East GeoColor', precision: '10分钟级' },
  ]
}

async function resolveImagery(): Promise<void> {
  const sequence = ++loadSequence
  choice.value = null
  error.value = null
  loading.value = true
  const cutoff = cutoffMs.value
  if (!Number.isFinite(cutoff)) {
    error.value = '所选截止时间无效'
    loading.value = false
    return
  }
  try {
    const recent = recentLayers()
    const recentTimes = await Promise.all(
      recent.map((layer) =>
        domainTime(layer.layer, layer.matrix, cutoff - 3 * 60 * 60 * 1000, cutoff).catch(() => null),
      ),
    )
    if (sequence !== loadSequence) return
    const recentIndex = recentTimes.findIndex(
      (effective) => effective != null && cutoff - Date.parse(effective) <= 30 * 60 * 1000,
    )
    if (recentIndex >= 0) {
      choice.value = { ...recent[recentIndex]!, effectiveAt: recentTimes[recentIndex]! }
      return
    }

    const dailyCutoff = new Date(cutoff)
    dailyCutoff.setUTCHours(0, 0, 0, 0)
    const latestCompletedDay = dailyCutoff.getTime() - 1
    const fallbackLayers = [
      ['VIIRS_NOAA21_CorrectedReflectance_TrueColor', 'NOAA-21 VIIRS 真彩'],
      ['VIIRS_NOAA20_CorrectedReflectance_TrueColor', 'NOAA-20 VIIRS 真彩'],
      ['VIIRS_SNPP_CorrectedReflectance_TrueColor', 'Suomi-NPP VIIRS 真彩'],
      ['MODIS_Aqua_CorrectedReflectance_TrueColor', 'Aqua MODIS 真彩'],
      ['MODIS_Terra_CorrectedReflectance_TrueColor', 'Terra MODIS 真彩'],
    ] as const
    const fallbackTimes = await Promise.all(
      fallbackLayers.map(([layer]) =>
        domainTime(layer, '250m', latestCompletedDay - 14 * 86_400_000, latestCompletedDay).catch(() => null),
      ),
    )
    if (sequence !== loadSequence) return
    const fallbackIndex = fallbackTimes.findIndex((effective) => effective != null)
    if (fallbackIndex >= 0) {
      const [layer, label] = fallbackLayers[fallbackIndex]!
      choice.value = {
        layer,
        matrix: '250m',
        label,
        precision: '日图降级',
        effectiveAt: fallbackTimes[fallbackIndex]!,
      }
      return
    }
    error.value = '该坐标与截止时间没有可用的历史卫星影像'
  } catch (reason) {
    if (sequence === loadSequence) error.value = reason instanceof Error ? reason.message : '卫星影像索引加载失败'
  } finally {
    if (sequence === loadSequence) loading.value = false
  }
}

watch(imageryRequestKey, resolveImagery, { immediate: true })
</script>

<template>
  <section class="panel satellite-panel" aria-labelledby="satellite-title">
    <header class="compact-panel-header">
      <div><h2 id="satellite-title">卫星云图</h2><span>所选坐标 · 所选截止时间（支持历史）</span></div>
      <span v-if="choice" class="satellite-mode">{{ choice.precision }}</span>
    </header>
    <div class="satellite-stage">
      <div v-if="loading" class="satellite-state"><i></i><span>正在定位截止时间之前的卫星观测…</span></div>
      <div v-else-if="error || !choice" class="satellite-state satellite-state--error"><strong>云图不可用</strong><span>{{ error }}</span></div>
      <template v-else>
        <div class="satellite-images">
          <img v-for="(url, index) in imageUrls" :key="url" :src="url" crossorigin="anonymous" :style="{ width: `${bboxPieces[index]!.width * 100}%` }" alt="NASA GIBS 卫星云图" @error="error = '卫星影像图片加载失败'" />
        </div>
        <span class="site-crosshair" aria-hidden="true"><i></i></span>
        <p class="site-label">{{ latitude.toFixed(4) }}°, {{ longitude.toFixed(4) }}°</p>
      </template>
    </div>
    <footer>
      <span v-if="choice">有效影像 {{ formatTimestamp(choice.effectiveAt, timezone) }} · {{ choice.label }}</span>
      <span>NASA GIBS / EOSDIS</span>
    </footer>
  </section>
</template>

<style scoped>
.satellite-panel { min-height: 0; display: grid; grid-template-rows: auto minmax(0, 1fr) auto; padding: 0.65rem; overflow: hidden; }
.compact-panel-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 0.6rem; padding-bottom: 0.42rem; }
.compact-panel-header > div { min-width: 0; }
.compact-panel-header span { display: block; margin-top: 0.12rem; overflow: hidden; color: var(--text-3); font-size: 0.56rem; text-overflow: ellipsis; white-space: nowrap; }
.compact-panel-header .satellite-mode { flex: 0 0 auto; margin: 0; padding: 0.2rem 0.4rem; border: 1px solid var(--cyan-dim); border-radius: 3px; color: var(--cyan); }
.satellite-stage { min-height: 0; position: relative; overflow: hidden; border: 1px solid var(--line); border-radius: 4px; background: radial-gradient(circle at center, #183345, #071018 70%); }
.satellite-images { width: 100%; height: 100%; display: flex; }
.satellite-images img { height: 100%; display: block; object-fit: fill; filter: saturate(.85) contrast(1.08) brightness(.82); }
.site-crosshair { width: 1.15rem; height: 1.15rem; position: absolute; left: 50%; top: 50%; border: 1px solid var(--cyan); border-radius: 50%; transform: translate(-50%, -50%); box-shadow: 0 0 12px var(--cyan); }
.site-crosshair::before, .site-crosshair::after { content: ''; position: absolute; background: var(--cyan); }
.site-crosshair::before { width: 1.7rem; height: 1px; left: -.3rem; top: .52rem; }
.site-crosshair::after { width: 1px; height: 1.7rem; left: .52rem; top: -.3rem; }
.site-label { position: absolute; left: 50%; top: calc(50% + 1rem); padding: .15rem .35rem; border-radius: 3px; color: var(--cyan); background: rgb(5 12 18 / 78%); font-family: var(--mono); font-size: .56rem; transform: translateX(-50%); white-space: nowrap; }
.satellite-state { height: 100%; display: grid; place-content: center; justify-items: center; gap: .5rem; color: var(--text-3); font-size: .68rem; text-align: center; }
.satellite-state i { width: 1.4rem; height: 1.4rem; border: 2px solid var(--line); border-top-color: var(--cyan); border-radius: 50%; animation: spin .8s linear infinite; }
.satellite-state--error strong { color: var(--text-2); font-size: .9rem; }
.satellite-state--error span { color: var(--amber); }
.satellite-panel footer { min-width: 0; display: flex; justify-content: space-between; gap: .5rem; padding-top: .35rem; color: var(--text-3); font-family: var(--mono); font-size: .52rem; }
.satellite-panel footer span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>
