<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { systemApi } from '../api/http'
import type { WeatherHistoryPoint, WeatherHistoryResponse } from '../api/contracts'
import { formatTimestamp } from '../utils/format'

const props = defineProps<{
  latitude: number
  longitude: number
  timezone: string
  asOf: string
}>()

type SeriesKey = 'cloud_cover' | 'wind_speed' | 'temperature_2m'

const data = ref<WeatherHistoryResponse | null>(null)
const loading = ref(false)
const error = ref<string | null>(null)
let requestSequence = 0

const requestKey = computed(() => {
  const parsed = Date.parse(props.asOf)
  const minuteBucket = Number.isFinite(parsed) ? Math.floor(parsed / 60_000) : props.asOf
  return `${props.latitude.toFixed(4)}|${props.longitude.toFixed(4)}|${props.timezone}|${minuteBucket}`
})

const points = computed(() => data.value?.points || [])
const hasPoints = computed(() => points.value.length > 0)
const chartLeft = 55
const chartRight = 650
const rowHeight = 51

const sourceLabel = computed(() => {
  const labels: Record<string, string> = {
    open_meteo_archive: '历史再分析',
    open_meteo_forecast: '天气预报',
    mixed: '历史 / 预报混合',
    none: '无可用数据',
  }
  return labels[data.value?.source || 'none'] || data.value?.source || '无可用数据'
})

function xAt(index: number): number {
  return points.value.length <= 1
    ? chartRight
    : chartLeft + (index / (points.value.length - 1)) * (chartRight - chartLeft)
}

function extent(key: SeriesKey): [number, number] {
  if (key === 'cloud_cover') return [0, 100]
  const values = points.value.map((point) => point[key]).filter((value): value is number => value != null)
  if (!values.length) return [0, key === 'wind_speed' ? 40 : 30]
  if (key === 'wind_speed') return [0, Math.max(10, Math.ceil(Math.max(...values) / 10) * 10)]
  const low = Math.floor((Math.min(...values) - 3) / 5) * 5
  const high = Math.ceil((Math.max(...values) + 3) / 5) * 5
  return low === high ? [low - 5, high + 5] : [low, high]
}

function yAt(value: number, key: SeriesKey, row: number): number {
  const [minimum, maximum] = extent(key)
  const top = 18 + row * rowHeight
  const bottom = top + 31
  const ratio = maximum === minimum ? 0.5 : (value - minimum) / (maximum - minimum)
  return bottom - Math.max(0, Math.min(1, ratio)) * (bottom - top)
}

function pathFor(key: SeriesKey, row: number): string {
  let path = ''
  let open = false
  points.value.forEach((point, index) => {
    const value = point[key]
    if (value == null) {
      open = false
      return
    }
    path += `${open ? 'L' : 'M'}${xAt(index).toFixed(1)},${yAt(value, key, row).toFixed(1)} `
    open = true
  })
  return path.trim()
}

function lastValue(key: SeriesKey): number | null {
  for (let index = points.value.length - 1; index >= 0; index -= 1) {
    const value = points.value[index]?.[key]
    if (value != null) return value
  }
  return null
}

function dateLabel(point: WeatherHistoryPoint): string {
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: props.timezone,
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(point.valid_time))
}

async function load(): Promise<void> {
  const sequence = ++requestSequence
  loading.value = true
  error.value = null
  try {
    const result = await systemApi.getWeatherHistory(props.asOf, 10)
    if (sequence !== requestSequence) return
    const sameSite =
      Math.abs(result.latitude - props.latitude) < 0.0001 &&
      Math.abs(result.longitude - props.longitude) < 0.0001 &&
      result.timezone === props.timezone
    if (!sameSite) return
    data.value = result
    error.value = result.error
  } catch (reason) {
    if (sequence !== requestSequence) return
    data.value = null
    error.value = reason instanceof Error ? reason.message : '历史数据加载失败'
  } finally {
    if (sequence === requestSequence) loading.value = false
  }
}

watch(requestKey, load, { immediate: true })
</script>

<template>
  <section class="panel history-panel" aria-labelledby="history-title">
    <header class="compact-panel-header">
      <div>
        <h2 id="history-title">历史曲线</h2>
        <span>近10天天气数据 · 过去9天 + 截止日 · {{ formatTimestamp(data?.as_of || asOf, timezone) }}</span>
      </div>
      <b v-if="data?.partial" class="text-warning" :title="error || undefined">
        部分数据 {{ points.length }}/10
      </b>
      <b v-else-if="data" class="text-normal">{{ sourceLabel }}</b>
    </header>

    <div v-if="loading && !hasPoints" class="chart-state">正在读取所选日期之前的 10 天天气…</div>
    <div v-else-if="!hasPoints" class="chart-state chart-state--error">
      <strong>历史曲线加载失败</strong>
      <span>{{ error || 'Open-Meteo 未返回这段日期的数据' }}</span>
      <button type="button" @click="load">重新加载</button>
    </div>
    <svg v-else class="history-chart" viewBox="0 0 720 185" role="img" aria-label="截止所选时间的十日云量、风速和气温曲线">
      <g v-if="points.length" class="cutoff-highlight">
        <rect :x="xAt(points.length - 1) - 16" y="7" width="32" height="148" rx="3" />
        <line :x1="xAt(points.length - 1)" y1="7" :x2="xAt(points.length - 1)" y2="155" />
        <text :x="xAt(points.length - 1)" y="12">截止日</text>
      </g>
      <g class="chart-grid">
        <line v-for="row in 3" :key="row" x1="55" :y1="row * rowHeight - 2" x2="650" :y2="row * rowHeight - 2" />
        <line v-for="(_, index) in points" :key="`v-${index}`" :x1="xAt(index)" y1="14" :x2="xAt(index)" y2="151" />
      </g>

      <g class="chart-labels">
        <text x="4" y="25">云量 %</text>
        <text x="4" y="76">风速 km/h</text>
        <text x="4" y="127">气温 °C</text>
        <text x="50" y="20" text-anchor="end">100</text>
        <text x="50" y="49" text-anchor="end">0</text>
        <text x="50" y="71" text-anchor="end">{{ extent('wind_speed')[1] }}</text>
        <text x="50" y="100" text-anchor="end">0</text>
        <text x="50" y="122" text-anchor="end">{{ extent('temperature_2m')[1] }}</text>
        <text x="50" y="151" text-anchor="end">{{ extent('temperature_2m')[0] }}</text>
      </g>

      <path class="series series--cloud" :d="pathFor('cloud_cover', 0)" />
      <path class="series series--wind" :d="pathFor('wind_speed', 1)" />
      <path class="series series--temperature" :d="pathFor('temperature_2m', 2)" />

      <g v-for="(point, index) in points" :key="point.valid_time">
        <circle v-if="point.cloud_cover != null" class="dot dot--cloud" :cx="xAt(index)" :cy="yAt(point.cloud_cover, 'cloud_cover', 0)" r="2.8"><title>{{ formatTimestamp(point.valid_time, timezone) }} · 云量 {{ point.cloud_cover.toFixed(0) }}%</title></circle>
        <circle v-if="point.wind_speed != null" class="dot dot--wind" :cx="xAt(index)" :cy="yAt(point.wind_speed, 'wind_speed', 1)" r="2.8"><title>{{ formatTimestamp(point.valid_time, timezone) }} · 风速 {{ point.wind_speed.toFixed(1) }} km/h</title></circle>
        <circle v-if="point.temperature_2m != null" class="dot dot--temperature" :cx="xAt(index)" :cy="yAt(point.temperature_2m, 'temperature_2m', 2)" r="2.8"><title>{{ formatTimestamp(point.valid_time, timezone) }} · 气温 {{ point.temperature_2m.toFixed(1) }}°C</title></circle>
        <text v-if="index === 0 || index === points.length - 1 || index % 3 === 0" class="date-label" :x="xAt(index)" y="172">{{ dateLabel(point) }}</text>
      </g>

      <g class="latest-values">
        <text x="662" y="31" class="latest-values__cloud">{{ lastValue('cloud_cover') == null ? '—' : `${lastValue('cloud_cover')!.toFixed(0)}%` }}</text>
        <text x="662" y="82" class="latest-values__wind">{{ lastValue('wind_speed') == null ? '—' : `${lastValue('wind_speed')!.toFixed(1)} km/h` }}</text>
        <text x="662" y="133" class="latest-values__temperature">{{ lastValue('temperature_2m') == null ? '—' : `${lastValue('temperature_2m')!.toFixed(1)}°C` }}</text>
      </g>
    </svg>
  </section>
</template>

<style scoped>
.history-panel {
  min-height: 0;
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  padding: 0.65rem 0.75rem 0.4rem;
  overflow: hidden;
}

.compact-panel-header {
  min-width: 0;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.5rem;
}

.compact-panel-header div { min-width: 0; }
.compact-panel-header span { display: block; margin-top: 0.12rem; overflow: hidden; color: var(--text-3); font-size: 0.56rem; text-overflow: ellipsis; white-space: nowrap; }
.compact-panel-header b { flex: 0 0 auto; font-family: var(--mono); font-size: 0.55rem; font-weight: 500; }

.history-chart { width: 100%; height: 100%; min-height: 0; overflow: visible; }
.chart-grid line { stroke: #233542; stroke-width: 0.75; }
.chart-grid line:nth-child(n + 4) { opacity: 0.45; }
.chart-labels text, .date-label { fill: var(--text-3); font-family: var(--mono); font-size: 8px; }
.date-label { text-anchor: middle; }
.cutoff-highlight rect { fill: rgb(81 214 198 / 8%); stroke: rgb(81 214 198 / 18%); }
.cutoff-highlight line { stroke: rgb(81 214 198 / 52%); stroke-width: 0.8; stroke-dasharray: 3 2; }
.cutoff-highlight text { fill: var(--cyan); font-family: var(--mono); font-size: 7px; text-anchor: middle; }
.series { fill: none; stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; }
.series--cloud, .dot--cloud { stroke: var(--cyan); }
.series--wind, .dot--wind { stroke: var(--amber); }
.series--temperature, .dot--temperature { stroke: var(--blue); }
.dot { fill: #0c141d; stroke-width: 1.5; }
.latest-values text { font-family: var(--mono); font-size: 10px; font-weight: 700; }
.latest-values__cloud { fill: var(--cyan); }
.latest-values__wind { fill: var(--amber); }
.latest-values__temperature { fill: var(--blue); }

.chart-state {
  min-height: 0;
  display: grid;
  place-items: center;
  color: var(--text-3);
  font-size: 0.7rem;
}
.chart-state--error { color: var(--amber); text-align: center; }
.chart-state--error strong,
.chart-state--error span { display: block; }
.chart-state--error span { max-width: 90%; font-size: 0.58rem; }
.chart-state--error button {
  margin-top: 0.2rem;
  padding: 0.28rem 0.55rem;
  border: 1px solid var(--line-strong);
  border-radius: 4px;
  color: var(--text-2);
  background: var(--bg-1);
  cursor: pointer;
}
</style>
