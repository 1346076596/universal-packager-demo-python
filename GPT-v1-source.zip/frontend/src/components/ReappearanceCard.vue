<script setup lang="ts">
import { computed } from 'vue'
import type {
  ReappearancePrediction,
  WeatherState,
} from '../api/contracts'
import {
  formatAngle,
  formatCountdown,
  formatPercent,
  formatRatioPercent,
  formatTimestamp,
} from '../utils/format'
import { formatWeatherCode } from '../utils/weather'

const props = defineProps<{
  prediction: ReappearancePrediction
  weather: WeatherState
  timezone: string
  now: number
  previewKind?: 'historical' | 'future' | 'preview' | null
}>()

const weather = computed(() => props.weather.selected)
const predictionReady = computed(() => props.prediction.valid)

const previewDescription = computed(() => {
  if (props.previewKind === 'historical') {
    return '相对所选计算时间的历史回看结果，仅供信息参考'
  }
  if (props.previewKind === 'future') {
    return '相对所选计算时间的未来预报结果，仅供信息参考'
  }
  if (props.previewKind === 'preview') {
    return '相对所选计算时间的预览结果，仅供信息参考'
  }
  return '预计倒计时，仅供信息参考'
})

function obstructionLabel(value: string): string {
  const labels: Record<string, string> = {
    clear: '当前无遮挡',
    cloud: '当前云层遮挡',
    visible: '太阳当前可见',
    obscured: '当前云层遮挡',
    likely_visible: '太阳可能可见',
    thermal_unavailable: '相机状态未知',
    night: '当前为夜间',
    unknown: '遮挡状态未知',
  }
  return labels[value] || value
}

function invalidReasonLabel(value: string | null): string {
  if (!value) return '当前数据不足或预测置信度低于展示阈值。'
  const labels: Record<string, string> = {
    no_reappearance_candidate_in_weather_window: '所选天气窗口内没有找到满足条件的日间晴朗时段。',
    candidate_outside_daylight: '天气候选时段均不在当地日照时间内。',
    confidence_below_display_threshold: '预测置信度低于展示阈值。',
    weather_too_stale: '天气数据过期，无法可靠计算。',
    weather_not_loaded: '天气数据尚未加载。',
    calculation_time_outside_forecast_range: '所选时间超出可用天气范围。',
    calculation_time_before_historical_weather_range: '历史天气仅支持 1940 年及之后的日期。',
  }
  return labels[value] || `暂不可预测：${value}`
}
</script>

<template>
  <article class="panel prediction-card" aria-labelledby="prediction-title">
    <header class="panel__header">
      <div>
        <p class="eyebrow">REAPPEARANCE FORECAST</p>
        <h2 id="prediction-title">下次太阳出现预测</h2>
      </div>
      <span
        class="state-label"
        :class="predictionReady ? 'state-label--normal' : 'state-label--idle'"
      >
        {{ predictionReady ? '预测可用' : '暂不可预测' }}
      </span>
    </header>

    <template v-if="predictionReady">
      <div class="prediction-hero">
        <span>{{ obstructionLabel(prediction.current_obstruction) }}</span>
        <strong>{{ formatCountdown(prediction.best_estimate, now) }}</strong>
        <small>
          {{ previewDescription }}
        </small>
      </div>

      <dl class="prediction-data">
        <div>
          <dt>预计时间范围</dt>
          <dd>
            {{ formatTimestamp(prediction.estimated_from, timezone) }}
            <span aria-hidden="true">—</span>
            {{ formatTimestamp(prediction.estimated_to, timezone) }}
          </dd>
        </div>
        <div>
          <dt>中心估计</dt>
          <dd>{{ formatTimestamp(prediction.best_estimate, timezone) }}</dd>
        </div>
        <div>
          <dt>预计高度角</dt>
          <dd>{{ formatAngle(prediction.predicted_altitude, 1) }}</dd>
        </div>
        <div>
          <dt>预计方位角</dt>
          <dd>{{ formatAngle(prediction.predicted_azimuth, 1) }}</dd>
        </div>
        <div>
          <dt>预测置信度</dt>
          <dd>{{ formatRatioPercent(prediction.confidence) }}</dd>
        </div>
      </dl>

    </template>

    <div v-else class="empty-state" role="status">
      <strong>暂不可预测</strong>
      <p>
        {{
          invalidReasonLabel(prediction.invalid_reason)
        }}
      </p>
      <small>预测结果不会写入 PLC 控制链。</small>
    </div>

    <footer class="weather-strip">
      <div>
        <span>云量</span>
        <strong>{{ formatPercent(weather?.cloud_cover) }}</strong>
      </div>
      <div>
        <span>风速</span>
        <strong>
          {{ weather?.wind_speed == null ? '—' : `${weather.wind_speed.toFixed(1)} km/h` }}
        </strong>
      </div>
      <div>
        <span>天气</span>
        <strong>{{ formatWeatherCode(weather?.weather_code) }}</strong>
      </div>
      <div>
        <span>缓存状态</span>
        <strong :class="{ 'text-warning': weather?.source_fetched_at && props.weather.stale }">
          {{ props.weather.stale ? '过期缓存' : props.weather.valid ? '新鲜' : '无有效数据' }}
        </strong>
      </div>
    </footer>
  </article>
</template>
