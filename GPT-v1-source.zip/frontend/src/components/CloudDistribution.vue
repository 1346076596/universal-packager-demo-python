<script setup lang="ts">
import { computed } from 'vue'
import type { WeatherState } from '../api/contracts'

const props = defineProps<{ weather: WeatherState }>()
const sample = computed(() => props.weather.selected)

function value(input: number | null | undefined): number {
  return input == null ? 0 : Math.max(0, Math.min(100, input))
}

const total = computed(() => value(sample.value?.cloud_cover))
const layers = computed(() => [
  { label: '低层云', value: value(sample.value?.cloud_cover_low) },
  { label: '中层云', value: value(sample.value?.cloud_cover_mid) },
  { label: '高层云', value: value(sample.value?.cloud_cover_high) },
])
</script>

<template>
  <section class="panel cloud-panel" aria-labelledby="cloud-title">
    <h2 id="cloud-title">云量分布</h2>
    <div class="cloud-content">
      <div
        class="cloud-ring"
        :style="{ '--cloud-total': `${total * 3.6}deg` }"
        role="img"
        :aria-label="`总云量 ${Math.round(total)}%`"
      >
        <span><strong>{{ Math.round(total) }}%</strong>总云量</span>
      </div>
      <div class="cloud-layers">
        <div v-for="layer in layers" :key="layer.label">
          <p><span>{{ layer.label }}</span><strong>{{ Math.round(layer.value) }}%</strong></p>
          <i><b :style="{ width: `${layer.value}%` }"></b></i>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.cloud-panel {
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  padding: 0.65rem 0.75rem;
  overflow: hidden;
}

.cloud-content {
  min-height: 0;
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 0.8rem;
}

.cloud-ring {
  width: clamp(3.7rem, 5vw, 5.2rem);
  aspect-ratio: 1;
  display: grid;
  place-items: center;
  position: relative;
  border-radius: 50%;
  background: conic-gradient(var(--cyan) var(--cloud-total), #1a2a38 0);
}

.cloud-ring::after {
  content: '';
  position: absolute;
  inset: 0.42rem;
  border-radius: inherit;
  background: var(--bg-1);
}

.cloud-ring span {
  z-index: 1;
  color: var(--text-3);
  font-size: 0.52rem;
  text-align: center;
}

.cloud-ring strong {
  display: block;
  color: var(--text-1);
  font-family: var(--mono);
  font-size: 0.92rem;
}

.cloud-layers {
  display: grid;
  gap: 0.35rem;
}

.cloud-layers p {
  display: flex;
  justify-content: space-between;
  color: var(--text-3);
  font-size: 0.58rem;
}

.cloud-layers strong {
  color: var(--text-2);
  font-family: var(--mono);
}

.cloud-layers i {
  height: 0.26rem;
  display: block;
  margin-top: 0.14rem;
  overflow: hidden;
  border-radius: 1rem;
  background: #172634;
}

.cloud-layers b {
  height: 100%;
  display: block;
  border-radius: inherit;
  background: linear-gradient(90deg, #1c8c87, var(--cyan));
}
</style>
