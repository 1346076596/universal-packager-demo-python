<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import type {
  AxisTelemetry,
  SolarState,
  SolarTrajectoryPoint,
} from '../api/contracts'
import { formatAngle, formatTimestamp } from '../utils/format'

const props = defineProps<{
  solar: SolarState
  azimuth: AxisTelemetry
  elevation: AxisTelemetry
  timezone: string
  latitude: number
  longitude: number
}>()

interface CanvasMetrics {
  width: number
  height: number
  centerX: number
  centerY: number
  radius: number
}

interface ProjectedPoint {
  x: number
  y: number
  depth: number
}

interface ActivePointer {
  id: number
  startX: number
  startY: number
  startYaw: number
  startPitch: number
}

const DEFAULT_YAW = 0
const DEFAULT_PITCH = 24
const LOCAL_ORIGIN_AZIMUTH = 180
const LOCAL_ORIGIN_ALTITUDE = DEFAULT_PITCH
const MIN_PITCH = -60
const MAX_PITCH = 60
const POINTER_YAW_FACTOR = 0.45
const POINTER_PITCH_FACTOR = 0.35
const DEFAULT_ZOOM = 100
const MIN_ZOOM = 70
const MAX_ZOOM = 220
const ZOOM_STEP = 10

const DIRECTIONS = [
  { key: 'north', label: '北', abbreviation: 'N', azimuth: 0 },
  { key: 'east', label: '东', abbreviation: 'E', azimuth: 90 },
  { key: 'south', label: '南', abbreviation: 'S', azimuth: 180 },
  { key: 'west', label: '西', abbreviation: 'W', azimuth: 270 },
] as const

const canvas = ref<HTMLCanvasElement | null>(null)
const wrapper = ref<HTMLElement | null>(null)
const viewYaw = ref(DEFAULT_YAW)
const viewPitch = ref(DEFAULT_PITCH)
const viewZoom = ref(DEFAULT_ZOOM)
const dragging = ref(false)
const viewMetrics = ref<CanvasMetrics>({
  width: 760,
  height: 340,
  centerX: 380,
  centerY: 172,
  radius: 136,
})

let resizeObserver: ResizeObserver | null = null
let activePointer: ActivePointer | null = null

const targetAzimuth = computed(
  () => props.solar.target_azimuth ?? props.solar.azimuth,
)
const targetAltitude = computed(
  () => props.solar.target_altitude ?? props.solar.altitude,
)

const currentSunPositionAvailable = computed(
  () =>
    Number.isFinite(props.solar.azimuth) &&
    Number.isFinite(props.solar.altitude),
)

const displayedSunAzimuth = computed(() => {
  return currentSunPositionAvailable.value
    ? props.solar.azimuth
    : Number(targetAzimuth.value)
})

const displayedSunAltitude = computed(() => {
  return currentSunPositionAvailable.value
    ? props.solar.altitude
    : Number(targetAltitude.value)
})

const sunPositionAvailable = computed(
  () =>
    Number.isFinite(displayedSunAzimuth.value) &&
    Number.isFinite(displayedSunAltitude.value),
)

const usingTargetPositionFallback = computed(
  () => !currentSunPositionAvailable.value && sunPositionAvailable.value,
)

const coordinateDescription = computed(
  () =>
    `${formatCoordinate(props.latitude, 'N', 'S')} · ${formatCoordinate(
      props.longitude,
      'E',
      'W',
    )}`,
)

const viewDescription = computed(
  () =>
    `水平 ${formatSignedAngle(viewYaw.value)}，俯仰 ${formatSignedAngle(
      viewPitch.value,
    )}，缩放 ${viewZoom.value}%`,
)

const localOriginMarker = computed(() => {
  const point = projectSolarPoint(
    LOCAL_ORIGIN_AZIMUTH,
    LOCAL_ORIGIN_ALTITUDE,
    viewMetrics.value,
  )
  const depthRatio = clamp((point.depth + 1) / 2, 0, 1)

  return {
    point,
    style: {
      left: `${point.x}px`,
      top: `${point.y}px`,
      opacity: (0.48 + depthRatio * 0.52).toFixed(3),
      zIndex: point.depth >= 0 ? '6' : '2',
    },
  }
})

const sunMarker = computed(() => {
  if (!sunPositionAvailable.value) return null
  const point = projectSolarPoint(
    displayedSunAzimuth.value,
    displayedSunAltitude.value,
    viewMetrics.value,
  )
  const depthRatio = clamp((point.depth + 1) / 2, 0, 1)

  return {
    point,
    style: {
      left: `${point.x}px`,
      top: `${point.y}px`,
      opacity: (0.58 + depthRatio * 0.42).toFixed(3),
      transform: `translate(-50%, -50%) scale(${(
        0.9 +
        depthRatio * 0.18
      ).toFixed(3)})`,
    },
  }
})

const directionMarkers = computed(() =>
  DIRECTIONS.map((direction) => {
    const point = projectSolarPoint(
      direction.azimuth,
      0,
      viewMetrics.value,
    )
    const depthRatio = (point.depth + 1) / 2
    const scale = 0.84 + depthRatio * 0.16
    const opacity = 0.52 + depthRatio * 0.43

    return {
      ...direction,
      style: {
        left: `${point.x}px`,
        top: `${point.y}px`,
        opacity: opacity.toFixed(3),
        transform: `translate(-50%, -50%) scale(${scale.toFixed(3)})`,
        zIndex: point.depth >= 0 ? '4' : '2',
      },
    }
  }),
)

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.max(minimum, Math.min(maximum, value))
}

function normalizeYaw(value: number): number {
  return ((value + 180) % 360 + 360) % 360 - 180
}

function formatSignedAngle(value: number): string {
  const rounded = Math.round(value)
  return `${rounded > 0 ? '+' : ''}${rounded}°`
}

function formatCoordinate(
  value: number,
  positiveSuffix: string,
  negativeSuffix: string,
): string {
  if (!Number.isFinite(value)) return '坐标不可用'
  return `${Math.abs(value).toFixed(4)}°${
    value >= 0 ? positiveSuffix : negativeSuffix
  }`
}

function projectSolarPoint(
  azimuth: number,
  altitude: number,
  metrics: CanvasMetrics,
): ProjectedPoint {
  const azimuthRadians = (azimuth * Math.PI) / 180
  const altitudeRadians = (altitude * Math.PI) / 180
  const horizontalRadius = Math.cos(altitudeRadians)

  const worldX = horizontalRadius * Math.sin(azimuthRadians)
  const worldY = Math.sin(altitudeRadians)
  const worldZ = -horizontalRadius * Math.cos(azimuthRadians)

  // 负号让拖动方向与模型在屏幕上的移动方向保持一致。
  const yawRadians = (-viewYaw.value * Math.PI) / 180
  const yawCosine = Math.cos(yawRadians)
  const yawSine = Math.sin(yawRadians)
  const yawX = worldX * yawCosine + worldZ * yawSine
  const yawZ = -worldX * yawSine + worldZ * yawCosine

  const pitchRadians = (viewPitch.value * Math.PI) / 180
  const pitchCosine = Math.cos(pitchRadians)
  const pitchSine = Math.sin(pitchRadians)
  const pitchedY = worldY * pitchCosine - yawZ * pitchSine
  const depth = worldY * pitchSine + yawZ * pitchCosine

  return {
    x: metrics.centerX + yawX * metrics.radius,
    y: metrics.centerY - pitchedY * metrics.radius,
    depth,
  }
}

function buildTrajectorySamples(
  trajectory: SolarTrajectoryPoint[],
): Array<{ azimuth: number; altitude: number }> {
  const validPoints = trajectory.filter(
    (point) =>
      Number.isFinite(point.azimuth) && Number.isFinite(point.altitude),
  )
  if (validPoints.length < 2) return validPoints

  const samples: Array<{ azimuth: number; altitude: number }> = []
  validPoints.forEach((point, index) => {
    if (index === validPoints.length - 1) {
      samples.push(point)
      return
    }

    const nextPoint = validPoints[index + 1]
    if (!nextPoint) return
    const azimuthDelta =
      ((nextPoint.azimuth - point.azimuth + 540) % 360) - 180
    const altitudeDelta = nextPoint.altitude - point.altitude
    const steps = Math.max(
      2,
      Math.ceil(Math.max(Math.abs(azimuthDelta), Math.abs(altitudeDelta)) / 4),
    )

    for (let step = 0; step < steps; step += 1) {
      const ratio = step / steps
      samples.push({
        azimuth: point.azimuth + azimuthDelta * ratio,
        altitude: point.altitude + altitudeDelta * ratio,
      })
    }
  })
  return samples
}

function strokeProjectedCurve(
  context: CanvasRenderingContext2D,
  points: ProjectedPoint[],
  front: boolean,
  color: string,
  lineWidth: number,
): void {
  context.save()
  context.strokeStyle = color
  context.lineWidth = lineWidth
  context.lineCap = 'round'
  context.lineJoin = 'round'
  context.globalAlpha = front ? 1 : 0.48
  context.setLineDash(front ? [] : [3, 5])

  for (let index = 1; index < points.length; index += 1) {
    const previous = points[index - 1]
    const current = points[index]
    if (!previous || !current) continue
    const segmentIsFront = previous.depth + current.depth >= 0
    if (segmentIsFront !== front) continue
    context.beginPath()
    context.moveTo(previous.x, previous.y)
    context.lineTo(current.x, current.y)
    context.stroke()
  }
  context.restore()
}

function drawMarker(
  context: CanvasRenderingContext2D,
  point: ProjectedPoint,
  kind: 'target' | 'actual',
): void {
  context.save()
  context.globalAlpha = point.depth >= 0 ? 1 : 0.42
  context.setLineDash(point.depth >= 0 ? [] : [3, 3])

  if (kind === 'target') {
    context.shadowColor = '#f2b84b'
    context.shadowBlur = point.depth >= 0 ? 14 : 0
    context.beginPath()
    context.fillStyle = '#ffd477'
    context.arc(point.x, point.y, 6.5, 0, Math.PI * 2)
    context.fill()
    context.shadowBlur = 0
    context.strokeStyle = '#0a121b'
    context.lineWidth = 2
    context.stroke()
  } else {
    context.strokeStyle = '#51d6c6'
    context.lineWidth = 2.2
    context.strokeRect(point.x - 6, point.y - 6, 12, 12)
  }
  context.restore()
}

function draw(): void {
  const element = canvas.value
  const container = wrapper.value
  if (!element || !container) return
  const context = element.getContext('2d')
  if (!context) return

  const rect = container.getBoundingClientRect()
  const cssWidth = Math.max(320, Math.floor(rect.width || 760))
  const cssHeight = Math.max(260, Math.floor(rect.height || 340))
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  element.width = Math.floor(cssWidth * dpr)
  element.height = Math.floor(cssHeight * dpr)
  element.style.width = `${cssWidth}px`
  element.style.height = `${cssHeight}px`
  context.setTransform(dpr, 0, 0, dpr, 0, 0)
  context.clearRect(0, 0, cssWidth, cssHeight)

  const metrics: CanvasMetrics = {
    width: cssWidth,
    height: cssHeight,
    centerX: cssWidth / 2,
    centerY: cssHeight / 2 + 4,
    radius:
      Math.max(100, Math.min(cssWidth * 0.39, cssHeight * 0.41)) *
      (viewZoom.value / 100),
  }
  viewMetrics.value = metrics

  context.fillStyle = '#0a121b'
  context.fillRect(0, 0, cssWidth, cssHeight)

  const atmosphere = context.createRadialGradient(
    metrics.centerX - metrics.radius * 0.32,
    metrics.centerY - metrics.radius * 0.38,
    metrics.radius * 0.05,
    metrics.centerX,
    metrics.centerY,
    metrics.radius,
  )
  atmosphere.addColorStop(0, '#1a3444')
  atmosphere.addColorStop(0.62, '#102432')
  atmosphere.addColorStop(1, '#08121b')

  context.save()
  context.beginPath()
  context.arc(
    metrics.centerX,
    metrics.centerY,
    metrics.radius,
    0,
    Math.PI * 2,
  )
  context.fillStyle = atmosphere
  context.fill()
  context.clip()

  const latitudeCurves = [-60, -30, 0, 30, 60].map((altitude) =>
    Array.from({ length: 73 }, (_, index) =>
      projectSolarPoint(index * 5, altitude, metrics),
    ),
  )
  const longitudeCurves = Array.from({ length: 12 }, (_, index) =>
    Array.from({ length: 37 }, (_, altitudeIndex) =>
      projectSolarPoint(index * 30, -90 + altitudeIndex * 5, metrics),
    ),
  )

  for (const curve of [...latitudeCurves, ...longitudeCurves]) {
    strokeProjectedCurve(context, curve, false, '#345063', 0.8)
  }
  for (const curve of [...latitudeCurves, ...longitudeCurves]) {
    strokeProjectedCurve(context, curve, true, '#38566a', 0.9)
  }

  const horizon = latitudeCurves[2] ?? []
  strokeProjectedCurve(context, horizon, false, '#536f82', 1.2)
  strokeProjectedCurve(context, horizon, true, '#6e8b9d', 1.45)

  const trajectory = buildTrajectorySamples(props.solar.trajectory || []).map(
    (point) =>
      projectSolarPoint(point.azimuth, point.altitude, metrics),
  )
  if (trajectory.length > 1) {
    strokeProjectedCurve(context, trajectory, false, '#a17b32', 1.8)
    strokeProjectedCurve(context, trajectory, true, '#f2b84b', 2.6)
  }

  if (props.solar.target_valid) {
    drawMarker(
      context,
      projectSolarPoint(targetAzimuth.value, targetAltitude.value, metrics),
      'target',
    )
  }

  if (
    props.azimuth.position_valid &&
    props.elevation.position_valid &&
    Number.isFinite(props.azimuth.actual_angle) &&
    Number.isFinite(props.elevation.actual_angle)
  ) {
    drawMarker(
      context,
      projectSolarPoint(
        Number(props.azimuth.actual_angle),
        Number(props.elevation.actual_angle),
        metrics,
      ),
      'actual',
    )
  }
  context.restore()

  context.save()
  context.beginPath()
  context.arc(
    metrics.centerX,
    metrics.centerY,
    metrics.radius,
    0,
    Math.PI * 2,
  )
  context.strokeStyle = '#4a6577'
  context.lineWidth = 1.5
  context.shadowColor = '#51d6c6'
  context.shadowBlur = 10
  context.stroke()
  context.restore()
}

function onPointerDown(event: PointerEvent): void {
  if (event.isPrimary === false) return
  if (event.pointerType === 'mouse' && event.button !== 0) return
  activePointer = {
    id: event.pointerId,
    startX: event.clientX,
    startY: event.clientY,
    startYaw: viewYaw.value,
    startPitch: viewPitch.value,
  }
  dragging.value = true
  wrapper.value?.focus({ preventScroll: true })
  wrapper.value?.setPointerCapture?.(event.pointerId)
  event.preventDefault()
}

function onPointerMove(event: PointerEvent): void {
  if (!activePointer || event.pointerId !== activePointer.id) return
  viewYaw.value = normalizeYaw(
    activePointer.startYaw +
      (event.clientX - activePointer.startX) * POINTER_YAW_FACTOR,
  )
  viewPitch.value = clamp(
    activePointer.startPitch -
      (event.clientY - activePointer.startY) * POINTER_PITCH_FACTOR,
    MIN_PITCH,
    MAX_PITCH,
  )
  event.preventDefault()
}

function finishPointer(event: PointerEvent): void {
  if (!activePointer || event.pointerId !== activePointer.id) return
  if (wrapper.value?.hasPointerCapture?.(event.pointerId)) {
    wrapper.value.releasePointerCapture(event.pointerId)
  }
  activePointer = null
  dragging.value = false
}

function onLostPointerCapture(event: PointerEvent): void {
  if (activePointer?.id !== event.pointerId) return
  activePointer = null
  dragging.value = false
}

function setZoom(value: number): void {
  viewZoom.value = clamp(
    Math.round(value / ZOOM_STEP) * ZOOM_STEP,
    MIN_ZOOM,
    MAX_ZOOM,
  )
}

function changeZoom(delta: number): void {
  setZoom(viewZoom.value + delta)
}

function onWheel(event: WheelEvent): void {
  if (event.deltaY === 0) return
  changeZoom(event.deltaY < 0 ? ZOOM_STEP : -ZOOM_STEP)
  event.preventDefault()
}

function onKeydown(event: KeyboardEvent): void {
  if (event.target !== event.currentTarget) return
  const step = event.shiftKey ? 3 : 10
  switch (event.key) {
    case 'ArrowLeft':
      viewYaw.value = normalizeYaw(viewYaw.value - step)
      break
    case 'ArrowRight':
      viewYaw.value = normalizeYaw(viewYaw.value + step)
      break
    case 'ArrowUp':
      viewPitch.value = clamp(viewPitch.value + step, MIN_PITCH, MAX_PITCH)
      break
    case 'ArrowDown':
      viewPitch.value = clamp(viewPitch.value - step, MIN_PITCH, MAX_PITCH)
      break
    case '+':
    case '=':
    case 'Add':
    case 'PageUp':
      changeZoom(ZOOM_STEP)
      break
    case '-':
    case '_':
    case 'Subtract':
    case 'PageDown':
      changeZoom(-ZOOM_STEP)
      break
    case 'Home':
      resetView()
      break
    default:
      return
  }
  event.preventDefault()
}

function resetView(): void {
  viewYaw.value = DEFAULT_YAW
  viewPitch.value = DEFAULT_PITCH
  viewZoom.value = DEFAULT_ZOOM
}

watch(
  () => [props.solar, props.azimuth, props.elevation],
  () => nextTick(draw),
  { deep: true },
)
watch([viewYaw, viewPitch, viewZoom], () => nextTick(draw))

onMounted(() => {
  resizeObserver = new ResizeObserver(draw)
  if (wrapper.value) resizeObserver.observe(wrapper.value)
  draw()
})

onBeforeUnmount(() => {
  resizeObserver?.disconnect()
  activePointer = null
})
</script>

<template>
  <figure class="trajectory" aria-labelledby="trajectory-title">
    <header class="visual-header">
      <div>
        <p class="eyebrow">SOLAR GEOMETRY</p>
        <h2 id="trajectory-title">太阳轨迹与双轴位置 · 本地天空方位图</h2>
      </div>
      <div class="visual-legend" aria-label="图例">
        <span><i class="legend-dot legend-dot--target"></i>太阳位置 / 目标</span>
        <span><i class="legend-dot legend-dot--actual"></i>PLC 实际</span>
      </div>
    </header>

    <div
      ref="wrapper"
      class="trajectory__canvas-wrap"
      :class="{ 'trajectory__canvas-wrap--dragging': dragging }"
      role="group"
      tabindex="0"
      data-test="trajectory-globe"
      :data-view-yaw="Math.round(viewYaw)"
      :data-view-pitch="Math.round(viewPitch)"
      :data-view-zoom="viewZoom"
      :aria-label="`以当前坐标 ${coordinateDescription} 为原点的本地天空方位图，默认北上南下、东右西左。${
        usingTargetPositionFallback ? '太阳位置不可用，显示目标参考位置' : '当前太阳计算位置'
      }方位 ${formatAngle(
        displayedSunAzimuth,
      )}，高度 ${formatAngle(displayedSunAltitude)}；PLC 控制目标${
        solar.target_valid ? '有效' : '无效，不得据此执行运动'
      }；PLC 实际方位 ${formatAngle(
        azimuth.actual_angle,
      )}，高度 ${formatAngle(elevation.actual_angle)}。当前${viewDescription}`"
      aria-describedby="trajectory-interaction-hint"
      @pointerdown="onPointerDown"
      @pointermove="onPointerMove"
      @pointerup="finishPointer"
      @pointercancel="finishPointer"
      @lostpointercapture="onLostPointerCapture"
      @keydown="onKeydown"
      @wheel="onWheel"
      @dblclick="resetView"
    >
      <canvas ref="canvas" aria-hidden="true"></canvas>

      <div class="trajectory__directions" aria-hidden="true">
        <span
          v-for="direction in directionMarkers"
          :key="direction.key"
          class="trajectory__direction"
          :data-direction="direction.key"
          :style="direction.style"
        >
          <b>{{ direction.label }}</b>
          <small>{{ direction.abbreviation }}</small>
        </span>
      </div>

      <div
        class="trajectory__local-origin"
        :class="{
          'trajectory__local-origin--rear': localOriginMarker.point.depth < 0,
        }"
        :style="localOriginMarker.style"
        :data-origin-x="localOriginMarker.point.x.toFixed(1)"
        :data-origin-y="localOriginMarker.point.y.toFixed(1)"
        :data-origin-depth="localOriginMarker.point.depth.toFixed(3)"
        aria-hidden="true"
      >
        <i></i>
        <span>
          当前坐标 · 本地原点
          <strong>{{ coordinateDescription }}</strong>
        </span>
      </div>

      <div
        v-if="sunMarker"
        class="trajectory__sun-position"
        :class="{
          'trajectory__sun-position--below-horizon': displayedSunAltitude < 0,
          'trajectory__sun-position--rear': sunMarker.point.depth < 0,
        }"
        :style="sunMarker.style"
        :data-sun-azimuth="displayedSunAzimuth.toFixed(1)"
        :data-sun-altitude="displayedSunAltitude.toFixed(1)"
        aria-hidden="true"
      >
        <i></i>
        <span>
          <strong>
            {{ usingTargetPositionFallback ? '太阳目标参考位置' : '当前太阳位置' }}
          </strong>
          <small>
            方位 {{ formatAngle(displayedSunAzimuth) }} · 高度
            {{ formatAngle(displayedSunAltitude) }}
          </small>
        </span>
      </div>

      <p id="trajectory-interaction-hint" class="trajectory__interaction-hint">
        当前坐标为原点 · 拖动旋转 · 滚轮或 +/- 缩放
      </p>

      <div
        class="trajectory__controls"
        role="group"
        aria-label="天空方位图缩放与视角控制"
        @pointerdown.stop
      >
        <button
          type="button"
          class="trajectory__zoom"
          data-test="zoom-out"
          aria-label="缩小天空方位图"
          :disabled="viewZoom <= MIN_ZOOM"
          @click.stop="changeZoom(-ZOOM_STEP)"
        >
          −
        </button>
        <output
          class="trajectory__zoom-value"
          data-test="zoom-level"
          aria-live="polite"
        >
          {{ viewZoom }}%
        </output>
        <button
          type="button"
          class="trajectory__zoom"
          data-test="zoom-in"
          aria-label="放大天空方位图"
          :disabled="viewZoom >= MAX_ZOOM"
          @click.stop="changeZoom(ZOOM_STEP)"
        >
          +
        </button>
        <button
          type="button"
          class="trajectory__reset"
          aria-label="重置天空方位图视角和缩放"
          title="重置视角与缩放（Home）"
          @click.stop="resetView"
        >
          重置
        </button>
      </div>

      <output class="trajectory__orientation" aria-live="polite">
        当前坐标 {{ coordinateDescription }} · 视角 {{ viewDescription }}
      </output>

      <p v-if="!solar.trajectory?.length" class="trajectory__notice">
        暂无全天轨迹序列；当前目标与 PLC 实际位置仍按实时数据绘制。
      </p>
    </div>

    <figcaption class="visual-footer">
      <span>
        计算时间
        <strong>{{ formatTimestamp(solar.calculation_time, timezone) }}</strong>
      </span>
      <span>
        日出 <strong>{{ formatTimestamp(solar.sunrise, timezone) }}</strong>
      </span>
      <span>
        日落 <strong>{{ formatTimestamp(solar.sunset, timezone) }}</strong>
      </span>
      <span :class="solar.is_day ? 'text-ok' : 'text-muted'">
        {{ solar.is_day ? '白天 · 允许日间策略' : '夜间 · PLC 执行安全停放' }}
      </span>
    </figcaption>
  </figure>
</template>

<style scoped>
.trajectory__controls {
  position: absolute;
  z-index: 8;
  top: 10px;
  right: 12px;
  display: flex;
  align-items: stretch;
  overflow: hidden;
  border: 1px solid var(--line);
  border-radius: 3px;
  background: rgb(7 11 16 / 88%);
  box-shadow: 0 4px 16px rgb(0 0 0 / 28%);
}

.trajectory__zoom,
.trajectory__zoom-value,
.trajectory__controls > .trajectory__reset {
  position: static;
  min-width: 30px;
  min-height: 30px;
  margin: 0;
  border: 0;
  border-right: 1px solid var(--line);
  border-radius: 0;
  color: var(--text-2);
  background: transparent;
  font-family: var(--mono);
  font-size: 0.7rem;
}

.trajectory__zoom {
  cursor: pointer;
  font-size: 1rem;
}

.trajectory__zoom:hover:not(:disabled),
.trajectory__zoom:focus-visible,
.trajectory__controls > .trajectory__reset:hover,
.trajectory__controls > .trajectory__reset:focus-visible {
  color: var(--cyan);
  background: rgb(16 36 50 / 92%);
  outline: none;
}

.trajectory__zoom:disabled {
  color: var(--text-3);
  cursor: not-allowed;
  opacity: 0.42;
}

.trajectory__zoom-value {
  display: grid;
  min-width: 48px;
  place-items: center;
  color: var(--amber);
}

.trajectory__controls > .trajectory__reset {
  min-width: 46px;
  padding: 4px 8px;
  border-right: 0;
  cursor: pointer;
}

.trajectory__local-origin {
  position: absolute;
  width: 0;
  height: 0;
  color: var(--text-3);
  font-family: var(--mono);
  pointer-events: none;
  transform: translate(-50%, -50%);
  transition:
    left 100ms linear,
    top 100ms linear,
    opacity 100ms linear;
  will-change: left, top, opacity;
}

.trajectory__canvas-wrap--dragging .trajectory__local-origin {
  transition: none;
}

.trajectory__local-origin > i,
.trajectory__local-origin > i::before,
.trajectory__local-origin > i::after {
  position: absolute;
  content: '';
}

.trajectory__local-origin > i {
  left: -4px;
  top: -4px;
  width: 8px;
  height: 8px;
  border: 1px solid rgb(255 255 255 / 72%);
  border-radius: 50%;
  background: rgb(8 18 27 / 84%);
  box-shadow: 0 0 0 3px rgb(81 214 198 / 12%);
}

.trajectory__local-origin > i::before {
  left: -9px;
  top: 3px;
  width: 24px;
  border-top: 1px solid rgb(81 214 198 / 52%);
}

.trajectory__local-origin > i::after {
  left: 3px;
  top: -9px;
  height: 24px;
  border-left: 1px solid rgb(81 214 198 / 52%);
}

.trajectory__local-origin > span {
  position: absolute;
  top: 14px;
  left: 50%;
  width: max-content;
  max-width: 250px;
  padding: 3px 6px;
  border-radius: 2px;
  background: rgb(7 11 16 / 62%);
  font-size: 0.56rem;
  line-height: 1.45;
  text-align: center;
  transform: translateX(-50%);
}

.trajectory__local-origin strong {
  display: block;
  color: var(--text-2);
  font-size: 0.62rem;
  font-weight: 600;
}

.trajectory__local-origin--rear > i {
  border-style: dashed;
}

.trajectory__sun-position {
  position: absolute;
  z-index: 7;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  pointer-events: none;
  transition:
    left 100ms linear,
    top 100ms linear,
    opacity 100ms linear,
    transform 100ms linear;
  will-change: left, top, transform;
}

.trajectory__canvas-wrap--dragging .trajectory__sun-position {
  transition: none;
}

.trajectory__sun-position > i {
  position: absolute;
  inset: 0;
  border: 2px solid #0a121b;
  border-radius: 50%;
  background: #ffd477;
  box-shadow:
    0 0 0 2px rgb(242 184 75 / 32%),
    0 0 18px rgb(242 184 75 / 88%);
}

.trajectory__sun-position > span {
  position: absolute;
  left: 20px;
  top: -13px;
  width: max-content;
  max-width: 210px;
  padding: 4px 7px;
  border: 1px solid rgb(242 184 75 / 46%);
  border-radius: 3px;
  color: var(--text-2);
  background: rgb(7 11 16 / 86%);
  box-shadow: 0 4px 14px rgb(0 0 0 / 32%);
  font-family: var(--mono);
  line-height: 1.4;
}

.trajectory__sun-position strong,
.trajectory__sun-position small {
  display: block;
}

.trajectory__sun-position strong {
  color: var(--amber);
  font-size: 0.65rem;
}

.trajectory__sun-position small {
  color: var(--text-3);
  font-size: 0.56rem;
}

.trajectory__sun-position--below-horizon > i {
  border-style: dashed;
  background: rgb(242 184 75 / 36%);
  box-shadow: 0 0 10px rgb(242 184 75 / 30%);
}

.trajectory__sun-position--below-horizon > span {
  border-style: dashed;
}

.trajectory__sun-position--rear > span::after {
  content: ' · 球面背侧';
  color: var(--text-3);
}

@media (max-width: 720px) {
  .trajectory__interaction-hint {
    max-width: calc(100% - 190px);
  }

  .trajectory__sun-position > span {
    max-width: 150px;
  }

  .trajectory__orientation {
    max-width: calc(100% - 24px);
  }
}
</style>
