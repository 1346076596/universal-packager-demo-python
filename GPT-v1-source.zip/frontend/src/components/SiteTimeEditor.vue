<script setup lang="ts">
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onMounted,
  reactive,
  ref,
  watch,
} from 'vue'
import type { SiteConfig } from '../api/contracts'
import { formatTimestamp } from '../utils/format'

const props = defineProps<{
  open: boolean
  config: SiteConfig
  saving: boolean
  error?: string | null
  notice?: string | null
}>()

const emit = defineEmits<{
  close: []
  save: [config: SiteConfig]
}>()

const closeButton = ref<HTMLButtonElement | null>(null)
const locating = ref(false)
const locationError = ref<string | null>(null)
const timeMode = ref<'automatic' | 'override'>('automatic')
const draft = reactive({
  latitude: props.config.latitude,
  longitude: props.config.longitude,
  timezone: props.config.timezone,
  localTime: '',
})

const timezones = [
  'Asia/Shanghai',
  'Asia/Hong_Kong',
  'Asia/Tokyo',
  'Europe/London',
  'America/New_York',
  'UTC',
]

const latitudeError = computed(() =>
  Number.isFinite(draft.latitude) &&
  draft.latitude >= -90 &&
  draft.latitude <= 90
    ? ''
    : '纬度必须在 -90° 到 90° 之间',
)
const longitudeError = computed(() =>
  Number.isFinite(draft.longitude) &&
  draft.longitude >= -180 &&
  draft.longitude <= 180
    ? ''
    : '经度必须在 -180° 到 180° 之间',
)
const timezoneError = computed(() => {
  try {
    new Intl.DateTimeFormat('zh-CN', { timeZone: draft.timezone }).format()
    return ''
  } catch {
    return '请输入有效的 IANA 时区，例如 Asia/Shanghai'
  }
})
const timeError = computed(() => {
  if (timeMode.value !== 'override') return ''
  if (!draft.localTime) return '手动覆盖时必须填写计算时间'
  return zonedLocalToIso(draft.localTime, draft.timezone)
    ? ''
    : '所选当地时间不存在或无效，请避开夏令时跳变时段'
})
const valid = computed(
  () =>
    !latitudeError.value &&
    !longitudeError.value &&
    !timezoneError.value &&
    !timeError.value,
)

function isoToZonedLocal(value: string, timezone: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    }).formatToParts(date)
    const part = (type: Intl.DateTimeFormatPartTypes) =>
      parts.find((item) => item.type === type)?.value || ''
    return `${part('year')}-${part('month')}-${part('day')}T${part('hour')}:${part(
      'minute',
    )}`
  } catch {
    return ''
  }
}

function zonedLocalToIso(value: string, timezone: string): string | null {
  const match = value.match(
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/,
  )
  if (!match) return null
  const numbers = match.slice(1).map(Number)
  const [year, month, day, hour, minute] = numbers
  if (
    year === undefined ||
    month === undefined ||
    day === undefined ||
    hour === undefined ||
    minute === undefined
  ) {
    return null
  }
  const desiredUtc = Date.UTC(year, month - 1, day, hour, minute)
  let instant = desiredUtc
  for (let iteration = 0; iteration < 2; iteration += 1) {
    const formatted = isoToZonedLocal(new Date(instant).toISOString(), timezone)
    const parsed = formatted.match(
      /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/,
    )
    if (!parsed) return null
    const values = parsed.slice(1).map(Number)
    const [fy, fm, fd, fh, fmin] = values
    if (
      fy === undefined ||
      fm === undefined ||
      fd === undefined ||
      fh === undefined ||
      fmin === undefined
    ) {
      return null
    }
    const formattedUtc = Date.UTC(fy, fm - 1, fd, fh, fmin)
    instant += desiredUtc - formattedUtc
  }
  const iso = new Date(instant).toISOString()
  return isoToZonedLocal(iso, timezone) === value ? iso : null
}

function resetDraft(): void {
  draft.latitude = props.config.latitude
  draft.longitude = props.config.longitude
  draft.timezone = props.config.timezone
  timeMode.value = props.config.calculation_time_override
    ? 'override'
    : 'automatic'
  draft.localTime = props.config.calculation_time_override
    ? isoToZonedLocal(
        props.config.calculation_time_override,
        props.config.timezone,
      )
    : ''
  locationError.value = null
}

watch(
  () => props.open,
  (open, wasOpen) => {
    if (open && !wasOpen) {
      resetDraft()
      nextTick(() => closeButton.value?.focus())
    }
  },
  { immediate: true },
)

function save(): void {
  if (!valid.value) return
  let override: string | null = null
  if (timeMode.value === 'override') {
    override = zonedLocalToIso(draft.localTime, draft.timezone)
    if (!override) return
  }
  emit('save', {
    latitude: Number(draft.latitude),
    longitude: Number(draft.longitude),
    timezone: draft.timezone.trim(),
    calculation_time_override: override,
  })
}

function useBrowserLocation(): void {
  locationError.value = null
  if (!navigator.geolocation) {
    locationError.value = '当前浏览器不支持定位'
    return
  }
  locating.value = true
  navigator.geolocation.getCurrentPosition(
    (position) => {
      draft.latitude = Number(position.coords.latitude.toFixed(6))
      draft.longitude = Number(position.coords.longitude.toFixed(6))
      locating.value = false
    },
    (reason) => {
      locationError.value =
        reason.code === reason.PERMISSION_DENIED
          ? '未获得浏览器定位授权'
          : '无法读取当前位置，请手动输入'
      locating.value = false
    },
    { enableHighAccuracy: true, timeout: 10_000, maximumAge: 60_000 },
  )
}

function onKeydown(event: KeyboardEvent): void {
  if (props.open && event.key === 'Escape' && !props.saving) emit('close')
}

onMounted(() => window.addEventListener('keydown', onKeydown))
onBeforeUnmount(() => window.removeEventListener('keydown', onKeydown))
</script>

<template>
  <Teleport to="body">
    <div v-if="open" class="modal-backdrop" @mousedown.self="emit('close')">
      <section
        class="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="site-editor-title"
      >
        <header class="modal__header">
          <div>
            <p class="eyebrow">SITE & CALCULATION TIME</p>
            <h2 id="site-editor-title">现场坐标与计算时间</h2>
          </div>
          <button
            ref="closeButton"
            type="button"
            class="icon-button"
            aria-label="关闭设置"
            :disabled="saving"
            @click="emit('close')"
          >
            ×
          </button>
        </header>

        <form class="settings-form" @submit.prevent="save">
          <fieldset>
            <legend>现场坐标</legend>
            <div class="field-grid">
              <label>
                <span>纬度（-90°～90°）</span>
                <input
                  v-model.number="draft.latitude"
                  name="latitude"
                  type="number"
                  min="-90"
                  max="90"
                  step="0.000001"
                  inputmode="decimal"
                  :aria-invalid="Boolean(latitudeError)"
                />
                <small :class="{ 'field-error': latitudeError }">
                  {{ latitudeError || `旧值 ${config.latitude.toFixed(6)}°` }}
                </small>
              </label>
              <label>
                <span>经度（-180°～180°）</span>
                <input
                  v-model.number="draft.longitude"
                  name="longitude"
                  type="number"
                  min="-180"
                  max="180"
                  step="0.000001"
                  inputmode="decimal"
                  :aria-invalid="Boolean(longitudeError)"
                />
                <small :class="{ 'field-error': longitudeError }">
                  {{ longitudeError || `旧值 ${config.longitude.toFixed(6)}°` }}
                </small>
              </label>
            </div>
            <button
              type="button"
              class="secondary-button"
              :disabled="locating"
              @click="useBrowserLocation"
            >
              {{ locating ? '正在读取位置…' : '读取浏览器定位' }}
            </button>
            <p v-if="locationError" class="form-message form-message--error">
              {{ locationError }}
            </p>
          </fieldset>

          <fieldset>
            <legend>时区与太阳计算时间</legend>
            <label>
              <span>IANA 时区</span>
              <input
                v-model.trim="draft.timezone"
                name="timezone"
                type="text"
                list="timezone-options"
                autocomplete="off"
                :aria-invalid="Boolean(timezoneError)"
              />
              <datalist id="timezone-options">
                <option v-for="zone in timezones" :key="zone" :value="zone" />
              </datalist>
              <small :class="{ 'field-error': timezoneError }">
                {{ timezoneError || `当前配置 ${config.timezone}` }}
              </small>
            </label>

            <div class="radio-group" role="radiogroup" aria-label="计算时间模式">
              <label>
                <input v-model="timeMode" type="radio" value="automatic" />
                <span>
                  <strong>自动时间</strong>
                  <small>跟随服务器当前时间，不修改系统或 PLC 时钟</small>
                </span>
              </label>
              <label>
                <input v-model="timeMode" type="radio" value="override" />
                <span>
                  <strong>临时计算时间</strong>
                  <small>仅覆盖太阳与天气计算</small>
                </span>
              </label>
            </div>

            <label v-if="timeMode === 'override'">
              <span>手动计算时间（{{ draft.timezone }}）</span>
              <input
                v-model="draft.localTime"
                name="calculation-time"
                type="datetime-local"
                :aria-invalid="Boolean(timeError)"
              />
              <small :class="{ 'field-error': timeError }">
                {{
                  timeError ||
                  `旧值 ${formatTimestamp(
                    config.calculation_time_override,
                    config.timezone,
                  )}`
                }}
              </small>
            </label>
          </fieldset>

          <div class="change-summary">
            <strong>保存后将执行</strong>
            <p>
              写入站点配置、立即重算太阳轨迹、按所选时间刷新天气数据并记录审计日志。真实
              PLC 控制仍按其安全状态独立裁决。
            </p>
          </div>

          <p v-if="error" class="form-message form-message--error" role="alert">
            {{ error }}
          </p>
          <p v-if="notice" class="form-message form-message--success" role="status">
            {{ notice }}
          </p>

          <footer class="modal__actions">
            <button
              type="button"
              class="secondary-button"
              :disabled="saving"
              @click="emit('close')"
            >
              取消
            </button>
            <button
              type="submit"
              class="primary-button"
              :disabled="!valid || saving"
            >
              {{ saving ? '正在保存…' : '保存并重新计算' }}
            </button>
          </footer>
        </form>
      </section>
    </div>
  </Teleport>
</template>
