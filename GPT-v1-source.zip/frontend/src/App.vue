<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import type {
  AxisName,
  ControlMode,
  ManualDirection,
  ServiceHealth,
  SiteConfig,
} from './api/contracts'
import AlarmBanner from './components/AlarmBanner.vue'
import AxisCard from './components/AxisCard.vue'
import ModeSelector from './components/ModeSelector.vue'
import ReappearanceCard from './components/ReappearanceCard.vue'
import SiteTimeEditor from './components/SiteTimeEditor.vue'
import SolarTrajectory from './components/SolarTrajectory.vue'
import ThermalLiveView from './components/ThermalLiveView.vue'
import { useControlStore } from './stores/control'
import { useSettingsStore } from './stores/settings'
import { useSystemStore } from './stores/system'
import {
  formatAge,
  formatAngle,
  formatTimestamp,
} from './utils/format'

const system = useSystemStore()
const control = useControlStore()
const settings = useSettingsStore()
const settingsOpen = ref(false)
let clockTimer: number | null = null

const snapshot = computed(() => system.snapshot)
const siteConfig = computed<SiteConfig | null>(
  () => settings.site || snapshot.value?.site || null,
)
const confirmedMode = computed(
  () => snapshot.value?.confirmed_mode || control.confirmedMode,
)
const displayMode = ref<ControlMode>(control.confirmedMode)
const previewingMode = computed(
  () => displayMode.value !== confirmedMode.value,
)
const targetVisible = computed(() => displayMode.value === 'solar')
const thermalModeAvailable = computed(() => {
  const state = snapshot.value
  if (!state) return false
  return (
    state.connections.thermal_algorithm !== 'disabled' &&
    state.thermal.camera_status !== 'unconfigured'
  )
})
const calculatedTime = computed(
  () => snapshot.value?.solar.calculation_time || snapshot.value?.generated_at,
)
const calculationPreviewKind = computed<
  'historical' | 'future' | 'preview' | null
>(() => {
  const state = snapshot.value
  if (!state?.site.calculation_time_override) return null
  const selected = Date.parse(state.solar.calculation_time)
  const live = Date.parse(state.generated_at)
  if (!Number.isFinite(selected) || !Number.isFinite(live)) return 'preview'
  if (selected < live - 60_000) return 'historical'
  if (selected > live + 60_000) return 'future'
  return 'preview'
})

const azLeft = computed(() =>
  control.jogAvailability('azimuth', 'az_left'),
)
const azRight = computed(() =>
  control.jogAvailability('azimuth', 'az_right'),
)
const altDown = computed(() =>
  control.jogAvailability('elevation', 'alt_down'),
)
const altUp = computed(() =>
  control.jogAvailability('elevation', 'alt_up'),
)

watch(
  () => system.snapshot,
  (next) => {
    if (!next) return
    control.syncFromSnapshot(next)
    settings.hydrate(next.site)
  },
  { immediate: true },
)

watch(
  confirmedMode,
  (next) => {
    displayMode.value = next
  },
  { immediate: true },
)

onMounted(async () => {
  await system.initialize()
  clockTimer = window.setInterval(() => {
    const now = Date.now()
    system.tick(now)
    control.reconcilePending(now)
  }, 1_000)
})

onBeforeUnmount(() => {
  if (clockTimer !== null) window.clearInterval(clockTimer)
  system.shutdown()
})

function healthLabel(health: ServiceHealth): string {
  const labels: Record<ServiceHealth, string> = {
    online: '在线',
    degraded: '降级',
    offline: '离线',
    disabled: '禁用',
  }
  return labels[health]
}

function modeLabel(mode: ControlMode): string {
  return {
    manual: '手动微调',
    solar: '太阳轨迹',
    thermal: '热成像追踪',
  }[mode]
}

async function handleModeRequest(mode: ControlMode): Promise<void> {
  if (mode === 'manual') {
    const confirmed = window.confirm(
      '切换到手动微调模式后，只有白天、安全链正常且 PLC 在线时按钮才可用。确认提交模式请求？',
    )
    if (!confirmed) return
  }
  if (mode === 'thermal') {
    const confirmed = window.confirm(
      '确认现场热成像相机及滤光组件已获准观测太阳，并完成光轴和方向标定？',
    )
    if (!confirmed) return
  }
  try {
    await control.requestMode(mode)
    displayMode.value = mode
  } catch {
    // Store surfaces the actionable rejection without changing the displayed mode.
  }
}

function handleModeBrowse(mode: ControlMode): void {
  displayMode.value = mode
}

async function handleJog(
  axis: AxisName,
  direction: ManualDirection,
): Promise<void> {
  await control.jog(axis, direction).catch(() => undefined)
}

async function saveSite(config: SiteConfig): Promise<void> {
  await settings.save(config).catch(() => undefined)
}
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand">
        <div class="brand__mark" aria-hidden="true">ST</div>
        <div>
          <p>INDUSTRIAL SOLAR TRACKING</p>
          <h1>逐日追踪系统</h1>
        </div>
        <span class="version-tag">v1.2</span>
      </div>

      <div v-if="snapshot" class="topbar__facts">
        <button
          type="button"
          class="fact-button"
          aria-label="编辑现场坐标和计算时间"
          @click="settingsOpen = true"
        >
          <span>现场坐标</span>
          <strong>
            {{ snapshot.site.latitude.toFixed(4) }}°,
            {{ snapshot.site.longitude.toFixed(4) }}°
          </strong>
        </button>
        <button
          type="button"
          class="fact-button"
          aria-label="编辑太阳计算时间"
          @click="settingsOpen = true"
        >
          <span>
            计算时间
            <b v-if="snapshot.site.calculation_time_override">手动覆盖</b>
          </span>
          <strong>{{ formatTimestamp(calculatedTime, snapshot.site.timezone) }}</strong>
        </button>
      </div>

      <button
        type="button"
        class="settings-button"
        aria-label="打开系统设置"
        @click="settingsOpen = true"
      >
        <span aria-hidden="true">SET</span>
        系统设置
      </button>
    </header>

    <main class="workspace">
      <div v-if="snapshot?.simulation.active" class="simulation-banner" role="status">
        <strong>模拟运行环境</strong>
        <span>
          {{
            snapshot.simulation.label ||
            '当前包含模拟数据，不能作为现场设备状态或动作依据。'
          }}
        </span>
      </div>

      <AlarmBanner
        :alarms="system.displayAlarms"
        :timezone="snapshot?.site.timezone"
      />

      <section v-if="system.initialLoading && !snapshot" class="loading-panel" aria-live="polite">
        <span class="loading-indicator" aria-hidden="true"></span>
        <div>
          <strong>正在建立系统状态链路</strong>
          <p>加载完整快照并连接 Python WebSocket…</p>
        </div>
      </section>

      <section v-else-if="system.initialError && !snapshot" class="fatal-panel" role="alert">
        <strong>无法连接 Python 服务</strong>
        <p>{{ system.initialError }}</p>
        <button type="button" class="primary-button" @click="system.initialize">
          重新连接
        </button>
      </section>

      <template v-if="snapshot">
        <section class="status-rail" aria-label="系统连接和安全状态">
          <div class="status-rail__item">
            <span
              class="status-dot"
              :class="`status-dot--${snapshot.connections.plc}`"
              aria-hidden="true"
            ></span>
            <div>
              <span>PLC 通信</span>
              <strong>{{ healthLabel(snapshot.connections.plc) }} · {{ snapshot.plc.running_state }}</strong>
            </div>
          </div>
          <div class="status-rail__item">
            <span
              class="status-dot"
              :class="`status-dot--${snapshot.connections.camera}`"
              aria-hidden="true"
            ></span>
            <div>
              <span>固定热像仪</span>
              <strong>{{ healthLabel(snapshot.connections.camera) }} · {{ snapshot.thermal.camera_status }}</strong>
            </div>
          </div>
          <div class="status-rail__item">
            <span
              class="status-dot"
              :class="snapshot.solar.is_day ? 'status-dot--online' : 'status-dot--disabled'"
              aria-hidden="true"
            ></span>
            <div>
              <span>昼夜策略</span>
              <strong>
                {{
                  snapshot.site.calculation_time_override
                    ? '时间预览 · 真实运动已锁定'
                    : snapshot.solar.is_day
                      ? '白天 · 实时控制时间有效'
                      : '夜间 · 自动安全停放'
                }}
              </strong>
            </div>
          </div>
          <div class="status-rail__item">
            <span
              class="status-dot"
              :class="snapshot.plc.safety.safety_ok ? 'status-dot--online' : 'status-dot--offline'"
              aria-hidden="true"
            ></span>
            <div>
              <span>安全链</span>
              <strong>
                {{
                  snapshot.plc.safety.safety_ok
                    ? '正常 · 位置反馈有效'
                    : `未就绪 · ${snapshot.plc.safety.fault_code || '检查急停与驱动'}`
                }}
              </strong>
            </div>
          </div>
          <div class="status-rail__item">
            <span
              class="status-dot"
              :class="system.dataStale ? 'status-dot--offline' : 'status-dot--online'"
              aria-hidden="true"
            ></span>
            <div>
              <span>实时状态流</span>
              <strong>
                {{
                  system.dataStale
                    ? `数据可能过期 · ${formatAge(system.snapshotAgeSeconds)}`
                    : `在线 · 序列 ${snapshot.sequence}`
                }}
              </strong>
            </div>
          </div>
        </section>

        <section class="panel mode-panel" aria-labelledby="tracking-title">
          <div class="mode-panel__title">
            <div>
              <p class="eyebrow">CONTROL AUTHORITY</p>
              <h2 id="tracking-title">追踪模式与 PLC 确认</h2>
            </div>
            <div class="mode-summary">
              <span>当前生效</span>
              <strong>{{ modeLabel(control.confirmedMode) }}</strong>
            </div>
          </div>
          <ModeSelector
            :requested-mode="control.requestedMode"
            :confirmed-mode="control.confirmedMode"
            :view-mode="displayMode"
            :pending="control.modeSwitchPending"
            :disabled="!system.plcOnline || system.dataStale"
            :thermal-available="thermalModeAvailable"
            @browse="handleModeBrowse"
            @request="handleModeRequest"
          />
          <p
            v-if="previewingMode"
            class="mode-preview-notice"
            role="status"
          >
            正在查看 <strong>{{ modeLabel(displayMode) }}</strong> 界面；PLC 实际仍为
            <strong>{{ modeLabel(confirmedMode) }}</strong>，未向设备发送切换命令。
          </p>
          <div
            v-if="control.modeError || control.jogError || control.jogNotice"
            class="command-message"
            :class="{ 'command-message--error': control.modeError || control.jogError }"
            role="status"
          >
            {{ control.modeError || control.jogError || control.jogNotice }}
            <button type="button" aria-label="关闭消息" @click="control.clearMessages">×</button>
          </div>
        </section>

        <section class="dashboard-grid">
          <div class="panel primary-visual">
            <ThermalLiveView
              v-if="displayMode === 'thermal'"
              :thermal="snapshot.thermal"
              :variant="settings.thermalVariant"
              :timezone="snapshot.site.timezone"
              @update:variant="settings.setThermalVariant"
            />
            <SolarTrajectory
              v-else
              :solar="snapshot.solar"
              :azimuth="snapshot.plc.azimuth"
              :elevation="snapshot.plc.elevation"
              :timezone="snapshot.site.timezone"
              :latitude="snapshot.site.latitude"
              :longitude="snapshot.site.longitude"
            />
          </div>

          <ReappearanceCard
            :prediction="snapshot.prediction"
            :weather="snapshot.weather"
            :timezone="snapshot.site.timezone"
            :now="
              snapshot.site.calculation_time_override
                ? Date.parse(snapshot.solar.calculation_time)
                : system.nowMs
            "
            :preview-kind="calculationPreviewKind"
          />
        </section>

        <section class="axis-grid" aria-label="两轴遥测与手动微调">
          <AxisCard
            axis="azimuth"
            title="方位轴"
            :telemetry="snapshot.plc.azimuth"
            :target-angle="snapshot.solar.target_azimuth ?? snapshot.solar.azimuth"
            :target-visible="targetVisible"
            :control-mode="displayMode"
            :confirmed-mode="confirmedMode"
            :target-valid="snapshot.solar.target_valid"
            negative-label="左"
            positive-label="右"
            negative-direction="az_left"
            positive-direction="az_right"
            :negative-availability="azLeft"
            :positive-availability="azRight"
            :command-pending="Boolean(control.pendingJog)"
            @jog="handleJog"
          />
          <AxisCard
            axis="elevation"
            title="高度轴"
            :telemetry="snapshot.plc.elevation"
            :target-angle="snapshot.solar.target_altitude ?? snapshot.solar.altitude"
            :target-visible="targetVisible"
            :control-mode="displayMode"
            :confirmed-mode="confirmedMode"
            :target-valid="snapshot.solar.target_valid"
            negative-label="下"
            positive-label="上"
            negative-direction="alt_down"
            positive-direction="alt_up"
            :negative-availability="altDown"
            :positive-availability="altUp"
            :command-pending="Boolean(control.pendingJog)"
            @jog="handleJog"
          />
        </section>

        <section class="diagnostics" aria-label="运行诊断">
          <div>
            <span>Python 太阳角 / 控制有效性</span>
            <strong>
              {{
                `方位 ${formatAngle(snapshot.solar.azimuth)} / 高度 ${formatAngle(
                  snapshot.solar.altitude,
                )} · ${
                  snapshot.solar.target_valid
                    ? '实时控制目标有效'
                    : `仅供显示：${snapshot.solar.target_invalid_reason || '当前不可控制'}`
                }`
              }}
            </strong>
          </div>
          <div>
            <span>PLC 心跳 / 数据版本</span>
            <strong>{{ snapshot.plc.heartbeat }} / v{{ snapshot.plc.data_version }}</strong>
          </div>
          <div>
            <span>最后遥测</span>
            <strong>{{ formatTimestamp(snapshot.plc.sampled_at, snapshot.site.timezone) }}</strong>
          </div>
          <div>
            <span>最后命令确认</span>
            <strong>
              {{
                snapshot.plc.last_ack
                  ? `${snapshot.plc.last_ack.result} · ${
                      snapshot.plc.last_ack.completed ? '已完成' : '处理中'
                    }`
                  : '暂无确认'
              }}
            </strong>
          </div>
        </section>
      </template>
    </main>

    <footer class="app-footer">
      <span>UI 仅提交操作意图；PLC 与硬件安全链拥有最终控制权。</span>
      <span v-if="snapshot">快照 #{{ snapshot.sequence }} · {{ formatTimestamp(snapshot.generated_at, snapshot.site.timezone) }}</span>
    </footer>

    <SiteTimeEditor
      v-if="siteConfig"
      :open="settingsOpen"
      :config="siteConfig"
      :saving="settings.saving"
      :error="settings.error"
      :notice="settings.savedNotice"
      @close="settingsOpen = false"
      @save="saveSite"
    />
  </div>
</template>
