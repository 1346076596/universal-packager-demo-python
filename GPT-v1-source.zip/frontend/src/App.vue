<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import type {
  AxisName,
  ControlMode,
  ManualDirection,
  ServiceHealth,
  SiteConfig,
} from './api/contracts'
import AlarmSummaryBar from './components/AlarmSummaryBar.vue'
import AxisCard from './components/AxisCard.vue'
import CloudDistribution from './components/CloudDistribution.vue'
import EnvironmentOverview from './components/EnvironmentOverview.vue'
import HistoryChart from './components/HistoryChart.vue'
import ModeSelector from './components/ModeSelector.vue'
import ReappearanceCard from './components/ReappearanceCard.vue'
import SiteTimeEditor from './components/SiteTimeEditor.vue'
import SatelliteCloudMap from './components/SatelliteCloudMap.vue'
import SolarTrajectory from './components/SolarTrajectory.vue'
import ThermalLiveView from './components/ThermalLiveView.vue'
import { useControlStore } from './stores/control'
import { useSettingsStore } from './stores/settings'
import { useSystemStore } from './stores/system'
import {
  formatAngle,
  formatTimestamp,
} from './utils/format'

const system = useSystemStore()
const control = useControlStore()
const settings = useSettingsStore()
const settingsOpen = ref(false)
let clockTimer: number | null = null

const snapshot = computed(() => system.snapshot)
const siteConfig = computed<SiteConfig | null>(
  () => settings.site || snapshot.value?.site || null,
)
const confirmedMode = computed(
  () => snapshot.value?.confirmed_mode || control.confirmedMode,
)
const displayMode = ref<ControlMode>(control.confirmedMode)
const previewingMode = computed(
  () => displayMode.value !== confirmedMode.value,
)
const targetVisible = computed(() => displayMode.value === 'solar')
const thermalModeAvailable = computed(() => {
  const state = snapshot.value
  if (!state) return false
  return (
    state.connections.thermal_algorithm !== 'disabled' &&
    state.thermal.camera_status !== 'unconfigured'
  )
})
const calculatedTime = computed(
  () => snapshot.value?.solar.calculation_time || snapshot.value?.generated_at,
)
const calculationPreviewKind = computed<
  'historical' | 'future' | 'preview' | null
>(() => {
  const state = snapshot.value
  if (!state?.site.calculation_time_override) return null
  const selected = Date.parse(state.solar.calculation_time)
  const live = Date.parse(state.generated_at)
  if (!Number.isFinite(selected) || !Number.isFinite(live)) return 'preview'
  if (selected < live - 60_000) return 'historical'
  if (selected > live + 60_000) return 'future'
  return 'preview'
})

const connectionSummary = computed(() => {
  const state = snapshot.value
  if (!state) return '正在建立 Python 状态链路'
  if (state.simulation.active) return state.simulation.label || '模拟运行环境'
  return `PLC ${healthLabel(state.connections.plc)} · 摄像头 ${healthLabel(
    state.connections.camera,
  )} · 实时流${system.dataStale ? '已中断' : '在线'}`
})

const azLeft = computed(() =>
  control.jogAvailability('azimuth', 'az_left'),
)
const azRight = computed(() =>
  control.jogAvailability('azimuth', 'az_right'),
)
const altDown = computed(() =>
  control.jogAvailability('elevation', 'alt_down'),
)
const altUp = computed(() =>
  control.jogAvailability('elevation', 'alt_up'),
)

watch(
  () => system.snapshot,
  (next) => {
    if (!next) return
    control.syncFromSnapshot(next)
    settings.hydrate(next.site)
  },
  { immediate: true },
)

watch(
  confirmedMode,
  (next) => {
    displayMode.value = next
  },
  { immediate: true },
)

onMounted(async () => {
  await system.initialize()
  clockTimer = window.setInterval(() => {
    const now = Date.now()
    system.tick(now)
    control.reconcilePending(now)
  }, 1_000)
})

onBeforeUnmount(() => {
  if (clockTimer !== null) window.clearInterval(clockTimer)
  system.shutdown()
})

function healthLabel(health: ServiceHealth): string {
  const labels: Record<ServiceHealth, string> = {
    online: '在线',
    degraded: '降级',
    offline: '离线',
    disabled: '禁用',
  }
  return labels[health]
}

function modeLabel(mode: ControlMode): string {
  return {
    manual: '手动微调',
    solar: '太阳轨迹',
    thermal: '热成像追踪',
  }[mode]
}

async function handleModeRequest(mode: ControlMode): Promise<void> {
  if (mode === 'manual') {
    const confirmed = window.confirm(
      '切换到手动微调模式后，只有白天、安全链正常且 PLC 在线时按钮才可用。确认提交模式请求？',
    )
    if (!confirmed) return
  }
  if (mode === 'thermal') {
    const confirmed = window.confirm(
      '确认现场热成像相机及滤光组件已获准观测太阳，并完成光轴和方向标定？',
    )
    if (!confirmed) return
  }
  try {
    await control.requestMode(mode)
    displayMode.value = mode
  } catch {
    // Store surfaces the actionable rejection without changing the displayed mode.
  }
}

function handleModeBrowse(mode: ControlMode): void {
  displayMode.value = mode
}

async function handleJog(
  axis: AxisName,
  direction: ManualDirection,
): Promise<void> {
  await control.jog(axis, direction).catch(() => undefined)
}

async function saveSite(config: SiteConfig): Promise<void> {
  await settings.save(config).catch(() => undefined)
}
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <div class="brand">
        <div class="brand__mark brand__mark--sun" aria-hidden="true">☀</div>
        <div>
          <p>INDUSTRIAL SOLAR TRACKING CONSOLE</p>
          <h1>逐日 · 双轴跟踪控制台</h1>
        </div>
      </div>

      <div v-if="snapshot" class="topbar__facts">
        <button
          type="button"
          class="fact-button"
          aria-label="编辑现场坐标和计算时间"
          @click="settingsOpen = true"
        >
          <span>现场坐标</span>
          <strong>
            {{ snapshot.site.latitude.toFixed(4) }}°,
            {{ snapshot.site.longitude.toFixed(4) }}°
          </strong>
        </button>
        <button
          type="button"
          class="fact-button"
          aria-label="编辑太阳计算时间"
          @click="settingsOpen = true"
        >
          <span>
            UI 截止时间
            <b v-if="snapshot.site.calculation_time_override">手动覆盖</b>
          </span>
          <strong>{{ formatTimestamp(calculatedTime, snapshot.site.timezone) }}</strong>
        </button>
      </div>

      <span
        class="connection-pill"
        :class="snapshot && !system.dataStale && snapshot.plc.online ? 'connection-pill--online' : 'connection-pill--offline'"
      >
        <i aria-hidden="true"></i>{{ connectionSummary }}
      </span>

      <button
        type="button"
        class="settings-button"
        aria-label="打开系统设置"
        @click="settingsOpen = true"
      >
        <span aria-hidden="true">⚙</span>
        系统设置
      </button>
    </header>

    <div class="alarm-slot">
      <AlarmSummaryBar
        :alarms="system.displayAlarms"
        :status-text="connectionSummary"
      />
    </div>

    <main class="workspace">
      <section v-if="system.initialLoading && !snapshot" class="loading-panel" aria-live="polite">
        <span class="loading-indicator" aria-hidden="true"></span>
        <div>
          <strong>正在建立系统状态链路</strong>
          <p>加载完整快照并连接 Python WebSocket…</p>
        </div>
      </section>

      <section v-else-if="system.initialError && !snapshot" class="fatal-panel" role="alert">
        <strong>无法连接 Python 服务</strong>
        <p>{{ system.initialError }}</p>
        <button type="button" class="primary-button" @click="system.initialize">
          重新连接
        </button>
      </section>

      <template v-if="snapshot">
        <section class="console-grid">
          <div class="console-column console-column--left">
            <div class="panel primary-visual console-globe-panel">
            <ThermalLiveView
              v-if="displayMode === 'thermal'"
              :thermal="snapshot.thermal"
              :variant="settings.thermalVariant"
              :timezone="snapshot.site.timezone"
              @update:variant="settings.setThermalVariant"
            />
            <SolarTrajectory
              v-else
              :solar="snapshot.solar"
              :azimuth="snapshot.plc.azimuth"
              :elevation="snapshot.plc.elevation"
              :timezone="snapshot.site.timezone"
              :latitude="snapshot.site.latitude"
              :longitude="snapshot.site.longitude"
            />
            </div>

            <section class="panel mode-dock" aria-labelledby="tracking-title">
              <header>
                <div><h2 id="tracking-title">控制模式</h2><span>当前权限：{{ modeLabel(control.confirmedMode) }}</span></div>
                <strong :class="snapshot.plc.safety.safety_ok ? 'text-normal' : 'text-danger'">
                  {{ snapshot.plc.safety.safety_ok ? 'PLC 已确认 ✓' : '安全链未就绪' }}
                </strong>
              </header>
              <ModeSelector
                :requested-mode="control.requestedMode"
                :confirmed-mode="control.confirmedMode"
                :view-mode="displayMode"
                :pending="control.modeSwitchPending"
                :disabled="!system.plcOnline || system.dataStale"
                :thermal-available="thermalModeAvailable"
                @browse="handleModeBrowse"
                @request="handleModeRequest"
              />
              <p v-if="previewingMode" class="mode-preview-notice" role="status">
                仅查看 {{ modeLabel(displayMode) }}；PLC 仍为 {{ modeLabel(confirmedMode) }}
              </p>
              <div
                v-if="control.modeError || control.jogError || control.jogNotice"
                class="command-message"
                :class="{ 'command-message--error': control.modeError || control.jogError }"
                role="status"
              >
                {{ control.modeError || control.jogError || control.jogNotice }}
                <button type="button" aria-label="关闭消息" @click="control.clearMessages">×</button>
              </div>
            </section>
          </div>

          <div class="console-column console-column--center">
            <section class="panel tracking-panel" aria-labelledby="axis-control-title">
              <header class="tracking-panel__header">
                <div><p class="eyebrow">TRACKING CONTROL</p><h2 id="axis-control-title">追踪控制</h2></div>
                <span>PLC 实际角 · Python 目标角 · 插值偏差</span>
              </header>
              <div class="tracking-axes" aria-label="两轴遥测与手动微调">
                <AxisCard
                  compact
                  axis="azimuth"
                  title="方位轴"
                  :telemetry="snapshot.plc.azimuth"
                  :target-angle="snapshot.solar.target_azimuth ?? snapshot.solar.azimuth"
                  :target-visible="targetVisible"
                  :control-mode="displayMode"
                  :confirmed-mode="confirmedMode"
                  :target-valid="snapshot.solar.target_valid"
                  negative-label="左"
                  positive-label="右"
                  negative-direction="az_left"
                  positive-direction="az_right"
                  :negative-availability="azLeft"
                  :positive-availability="azRight"
                  :command-pending="Boolean(control.pendingJog)"
                  @jog="handleJog"
                />
                <AxisCard
                  compact
                  axis="elevation"
                  title="高度轴"
                  :telemetry="snapshot.plc.elevation"
                  :target-angle="snapshot.solar.target_altitude ?? snapshot.solar.altitude"
                  :target-visible="targetVisible"
                  :control-mode="displayMode"
                  :confirmed-mode="confirmedMode"
                  :target-valid="snapshot.solar.target_valid"
                  negative-label="下"
                  positive-label="上"
                  negative-direction="alt_down"
                  positive-direction="alt_up"
                  :negative-availability="altDown"
                  :positive-availability="altUp"
                  :command-pending="Boolean(control.pendingJog)"
                  @jog="handleJog"
                />
              </div>
            </section>

            <SatelliteCloudMap
              :latitude="snapshot.site.latitude"
              :longitude="snapshot.site.longitude"
              :timezone="snapshot.site.timezone"
              :as-of="calculatedTime || snapshot.generated_at"
            />
          </div>

          <div class="console-column console-column--right">
            <EnvironmentOverview
              :weather="snapshot.weather"
              :calculation-time="calculatedTime || snapshot.generated_at"
              :timezone="snapshot.site.timezone"
            />
            <CloudDistribution :weather="snapshot.weather" />
            <ReappearanceCard
              compact
              :prediction="snapshot.prediction"
              :weather="snapshot.weather"
              :timezone="snapshot.site.timezone"
              :now="snapshot.site.calculation_time_override ? Date.parse(snapshot.solar.calculation_time) : system.nowMs"
              :preview-kind="calculationPreviewKind"
            />
            <HistoryChart
              :latitude="snapshot.site.latitude"
              :longitude="snapshot.site.longitude"
              :timezone="snapshot.site.timezone"
              :as-of="calculatedTime || snapshot.generated_at"
            />
          </div>
        </section>
      </template>
    </main>

    <footer class="console-footer">
      <template v-if="snapshot">
        <span title="Python 太阳角与控制有效性">
          Python 太阳角：方位 {{ formatAngle(snapshot.solar.azimuth) }} / 高度 {{ formatAngle(snapshot.solar.altitude) }} ·
          {{ snapshot.solar.target_valid ? '控制目标有效' : `仅显示：${snapshot.solar.target_invalid_reason || '不可控制'}` }}
        </span>
        <span>PLC 心跳 {{ snapshot.plc.heartbeat }} / v{{ snapshot.plc.data_version }}</span>
        <span>遥测 {{ formatTimestamp(snapshot.plc.sampled_at, snapshot.site.timezone) }}</span>
        <span>指令确认 {{ snapshot.plc.last_ack ? `${snapshot.plc.last_ack.result} · ${snapshot.plc.last_ack.completed ? '完成' : '处理中'}` : '暂无' }}</span>
      </template>
      <span v-else>UI 仅提交操作意图；PLC 与硬件安全链拥有最终控制权。</span>
    </footer>

    <SiteTimeEditor
      v-if="siteConfig"
      :open="settingsOpen"
      :config="siteConfig"
      :saving="settings.saving"
      :error="settings.error"
      :notice="settings.savedNotice"
      @close="settingsOpen = false"
      @save="saveSite"
    />
  </div>
</template>
